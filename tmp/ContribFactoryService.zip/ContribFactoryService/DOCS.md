# Product Creation API - User Manual

## Table of Contents
- [Overview](#overview)
- [What Does This API Do?](#what-does-this-api-do)
- [High-Level Architecture](#high-level-architecture)
- [Key Features](#key-features)
- [System Dependencies](#system-dependencies)
- [Getting Started](#getting-started)
- [Authentication](#authentication)
- [API Endpoints](#api-endpoints)
- [Health Monitoring](#health-monitoring)
- [Error Handling](#error-handling)
- [Configuration](#configuration)
- [Monitoring and Logging](#monitoring-and-logging)

---

## Overview

The **Product Creation API** is a production-grade RESTful web service built with .NET 8 that orchestrates product creation requests across multiple financial data providers (Bloomberg, Refinitiv, and Six). It provides a unified interface for submitting product creation requests, tracking their status, and managing the asynchronous workflow.

### Target Audience
- **API Consumers**: Applications and services that need to create products in financial data provider systems
- **System Administrators**: Teams responsible for deploying and monitoring the API
- **Developers**: Teams integrating with or extending the API

---

## What Does This API Do?

The Product Creation API serves as a **centralized gateway** for managing product creation workflows across multiple financial data providers. Here's what it accomplishes:

### Primary Functions

1. **Unified Product Creation Interface**
   - Accept product creation requests through a single, standardized REST API
   - Support batch processing of multiple products in a single request
   - Validate requests before submission to providers

2. **Multi-Provider Support**
   - **Bloomberg**: Financial data and analytics provider
   - **Refinitiv**: Market data and infrastructure services
   - **Six**: Swiss financial information services
   
3. **Asynchronous Processing**
   - Queue requests for reliable, ordered processing
   - Process requests asynchronously via background jobs
   - Maintain request state throughout the lifecycle

4. **Status Tracking**
   - Track each request through multiple workflow stages
   - Provide real-time status updates
   - Store historical data for auditing and troubleshooting

### Workflow Stages

**Status Definitions:**
  - **Requested**: Initial product submission
  - **Validated**: Product has passed validation
  - **ProviderSent**: Product information sent to provider
  - **ProviderAck**: Provider acknowledgment received
  - **ProviderCreated**: Product successfully created (final state)
  - **ProviderRejected**: Product rejected due to functional errors (final state)
  - **Failed**: Technical error occurred (can happen at any time, final state)

---

## High-Level Architecture

The system follows **Clean Architecture** principles with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────────────┐
│                         Presentation Layer                       │
│                    (WebApi - REST Endpoints)                     │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                       Application Layer                          │
│              (Business Logic, Services, Validation)              │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                      Infrastructure Layer                        │
│         (Database, Hangfire, Repositories, External APIs)         │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                         Domain Layer                             │
│              (Entities, Value Objects, Enums)                    │
└──────────────────────────────────────────────────────────────────┘
```

### Component Breakdown

#### 1. **WebApi Layer** (Entry Point)
- **Location**: `src/ContribFactoryService.WebApi/`
- **Purpose**: HTTP request handling, routing, middleware
- **Key Files**:
  - `Program.cs`: Application entry point, service configuration
  - `Endpoints/`: Minimal API endpoint definitions
  - `Middleware/`: Global exception handler
  - `Configuration/`: Authentication setup

#### 2. **Application Layer**
- **Location**: `src/ContribFactoryService.Application/`
- **Purpose**: Business logic orchestration
- **Key Components**:
  - `Services/`: Core business services (ProductCreationService)
  - `Interfaces/`: Contracts for repositories and services
  - `DataValidation/`: FluentValidation validators

#### 3. **Infrastructure Layer**
- **Location**: `src/ContribFactoryService.Infrastructure/`
- **Purpose**: External system integration
- **Key Components**:
  - `Persistence/`: Entity Framework Core DbContext
  - `Repositories/`: Data access implementations
  - `Hangfire/`: Hangfire background job implementation

#### 4. **Domain Layer**
- **Location**: `src/ContribFactoryService.Domain/`
- **Purpose**: Core business entities and rules
- **Key Components**:
  - `Models/`: Domain entities (Provider, ProductCreationStatus)
  - `ProductCreationRequestResponse/`: DTOs for API contracts

---

## Key Features

### 🔐 Security Features

#### JWT Authentication
- **Standard**: Bearer token authentication (RFC 6750)
- **Algorithm**: HMAC-SHA256
- **Token Lifetime**: 1 hour (configurable)
- **Claims**: User identity, roles, correlation tracking

#### Authorization
- All product endpoints require authentication
- Health check endpoints are publicly accessible

### 📊 Observability Features

#### Structured Logging (Serilog)
- **Console Output**: Real-time development logging
- **File Logging**: Daily rolling log files
- **Enrichment**: Machine name, thread ID, correlation IDs

#### Health Checks
- **Liveness Probe**: Application is running
- **Readiness Probe**: Database connectivity, dependencies ready
- **Comprehensive Check**: All components status

#### Request Logging
- HTTP request/response logging via Serilog
- Performance metrics (duration, status codes)
- Correlation ID tracking across services

### 🛡️ Resilience Features

#### Polly Integration
- **Retry Policies**: Automatic retry on transient failures
- **Circuit Breaker**: Prevent cascading failures
- **Timeout Policies**: Prevent hanging requests
- **Standard Resilience Handler**: Pre-configured best practices

#### Global Exception Handling
- **RFC 7807 Problem Details**: Standardized error responses
- **Automatic Error Logging**: All exceptions logged
- **User-Friendly Messages**: No sensitive data exposure

### 🔄 API Features

#### API Versioning
- **Version 1.0**: Current stable version
- **URL Versioning**: `/api/v1/products`
- **Header Versioning**: `X-Api-Version: 1.0`
- **Version Reporting**: Response headers indicate supported versions

#### OpenAPI/Swagger
- **Interactive Documentation**: Swagger UI in development mode
- **API Discovery**: Auto-generated from code
- **Try It Out**: Test endpoints directly from browser
- **Multiple Documents**: Separate docs for production and development endpoints

#### CORS Support
- **Configurable**: Allow any origin in development
- **Production-Ready**: Restrict to specific domains in production

### 🚀 Performance Features

#### HybridCache Optimization
- **Dual-Layer Caching**: Combines L1 (In-memory) and L2 (Distributed) caching.
- **Smart Polling**: Caches product status only once it reaches the `Succeed` (ProviderCreated) state.
- **Reduced Latency**: High-frequency status checks for completed creations are served from cache, bypassing the database.
- **Cache Invalidation**: Leverages HybridCache's built-in expiration and invalidation mechanisms.

### ✅ Validation

#### FluentValidation
- **Request Validation**: Automatic validation before processing
- **Rich Error Messages**: Detailed validation feedback
- **Business Rules**: Complex validation logic support

---

## System Dependencies

### Required Infrastructure

#### 1. **Database - SQL Server**
- **Purpose**: Persistent storage for product creation messages
- **Configuration**: Connection string in `appsettings.json`
- **Development**: LocalDB or SQL Server Express
- **Production**: Azure SQL Database or SQL Server
- **Schema**: Managed by Entity Framework Core migrations

#### 2. **Hangfire**
- **Purpose**: Reliable job processing and message queuing
- **Storage**: SQL Server (using `ProductCreation` connection string)
- **Message Flow**: API → Hangfire → Provider Dispatcher

#### 4. **Hangfire Scheduler**
- **Purpose**: Orchestrate scheduled background tasks
- **Role**: Triggers status synchronization at a regular interval (e.g., every 5 minutes)
- **Benefit**: Ensures eventual consistency for product statuses

- **Benefits**:
  - Searchable logs
  - Metrics and alarms
  - Long-term log retention

### External Dependencies

#### NuGet Packages
- **ASP.NET Core 8.0**: Web framework
- **Entity Framework Core**: ORM for database access
- **Serilog**: Structured logging
- **FluentValidation**: Request validation
- **Polly**: Resilience and transient fault handling
- **Hangfire**: Job processing and scheduling
- **Microsoft.AspNetCore.Authentication.JwtBearer**: JWT authentication

---

## Getting Started

### Prerequisites

1.  **.NET 8.0 SDK** - [Download](https://dotnet.microsoft.com/download/dotnet/8.0)
2.  **SQL Server** - LocalDB, Express, or full version
3.  **SQL Server** - For data and job persistence
4.  **IDE** - Visual Studio 2022, VS Code, or Rider

### Installation Steps

#### 1. Clone the Repository
```bash
git clone <repository-url>
cd ContribFactoryService
```

#### 2. Configure Settings

Edit `src/ContribFactoryService.WebApi/appsettings.Development.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ProductCreationDb;Trusted_Connection=True;"
  },
  "Jwt": {
    "SecretKey": "YourSuperSecretKeyThatIsAtLeast32CharactersLong!"
  }
}
```

#### 3. Setup Database

```bash
cd src/ContribFactoryService.WebApi

# Create migration (if not exists)
dotnet ef migrations add InitialCreate --project ../ContribFactoryService.Infrastructure

# Apply migration
dotnet ef database update --project ../ContribFactoryService.Infrastructure
```

#### 4. Run the Application

```bash
dotnet run
```

The API will start at:
- **HTTPS**: `https://localhost:5001`
- **HTTP**: `http://localhost:5000`
- **Swagger UI**: `https://localhost:5001/swagger`

---

## Authentication

### Overview
The API uses **JWT (JSON Web Token)** Bearer authentication for securing endpoints.

### Getting a Token (Development Only)

In development mode, a token generation endpoint is available:

**Endpoint**: `POST /api/auth/token`
**Authentication**: None required
**Swagger Group**: "Development Only"

#### Request
```http
POST https://localhost:5001/api/auth/token
Content-Type: application/json
```

#### Response
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### Using the Token

Include the token in the `Authorization` header for all protected endpoints:

```http
GET https://localhost:5001/api/v1/products/{requestId}
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Token Details
- **Algorithm**: HS256 (HMAC-SHA256)
- **Expiration**: 1 hour
- **Claims**:
  - `sub`: Subject (user identifier)
  - `jti`: JWT ID (unique token identifier)
  - `name`: User name
  - `role`: User role

### Production Authentication

⚠️ **Important**: The `/api/auth/token` endpoint is **only available in development mode**.

In production, integrate with your organization's identity provider:
- Azure AD / Entra ID
- Auth0
- IdentityServer
- Okta
- Custom OAuth 2.0 / OpenID Connect provider

---

## API Endpoints

### Base URL
- **Development**: `https://localhost:5001`
- **Production**: `https://your-domain.com`

### API Version
All product endpoints are versioned: `/api/v1/`

---

### 1. Create Product Request

Submit one or more product creation requests to specified providers.

**Endpoint**: `POST /api/v1/products`
**Authentication**: Required (Bearer token)
**Content-Type**: `application/json`

#### Request Body

```json
{
  "requestType": "ProductCreation",
  "version": "1.0",
  "timestamp": "2026-02-10T08:00:00Z",
  "requestId": "REQ-2026-001",
  "priority": "Normal",
  "technicalInfo": {
    "apiVersion": "v1",
    "sourceSystem": "TradingPlatform",
    "correlationId": "corr-12345"
  },
  "payload": [
    {
      "type": "Equity",
      "providers": ["Bloomberg", "Refinitiv"],
      "identifier": "AAPL",
      "name": "Apple Inc.",
      "description": "Technology company",
      "fields": {
        "exchange": "NASDAQ",
        "currency": "USD",
        "country": "US"
      }
    }
  ]
}
```

#### Request Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `requestType` | string | No | Type of request (default: "ProductCreation") |
| `version` | string | No | Request schema version (default: "1.0") |
| `timestamp` | datetime | No | Request timestamp (default: current UTC time) |
| `requestId` | string | Yes | Unique identifier for this request |
| `priority` | string | No | Priority level: "Normal", "High", "Low" |
| `technicalInfo` | object | No | Technical metadata |
| `payload` | array | Yes | Array of products to create |

**Payload Item Fields:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | Yes | Product type (e.g., "Equity", "Bond", "Derivative") |
| `providers` | array | Yes | List of providers: "Bloomberg", "Refinitiv", "Six" |
| `identifier` | string | Yes | Product identifier/symbol |
| `name` | string | Yes | Product name |
| `description` | string | No | Product description |
| `fields` | object | No | Additional provider-specific fields |

#### Response

**Status**: `201 Created`

```json
[
  {
    "requestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "provider": "Bloomberg",
    "productSymbol": "AAPL",
    "status": "Requested",
    "productCode": null,
    "errorMessage": null,
    "createdAt": "2026-02-10T08:00:00Z",
    "updatedAt": "2026-02-10T08:00:00Z"
  },
  {
    "requestId": "4fb96f75-6828-5673-c4gd-3d074g77bgb7",
    "provider": "Refinitiv",
    "productSymbol": "AAPL",
    "status": "Requested",
    "productCode": null,
    "errorMessage": null,
    "createdAt": "2026-02-10T08:00:00Z",
    "updatedAt": "2026-02-10T08:00:00Z"
  }
]
```

#### Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `requestId` | guid | Unique identifier for tracking this request |
| `provider` | string | Provider name (Bloomberg, Refinitiv, Six) |
| `productSymbol` | string | Product identifier |
| `status` | string | Current status (Requested, Acknowledged, Succeed, Failed) |
| `productCode` | string | Provider-assigned product code (null until Succeed) |
| `errorMessage` | string | Error details (null unless Failed) |
| `createdAt` | datetime | When the request was created |
| `updatedAt` | datetime | When the request was last updated |

#### Error Responses

**400 Bad Request** - Validation failure
```json
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "errors": {
    "Payload": ["The Payload field is required."],
    "RequestId": ["The RequestId field is required."]
  }
}
```

**401 Unauthorized** - Missing or invalid token
```json
{
  "type": "https://tools.ietf.org/html/rfc7235#section-3.1",
  "title": "Unauthorized",
  "status": 401
}
```

**500 Internal Server Error** - Server error
```json
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.6.1",
  "title": "An error occurred while processing your request.",
  "status": 500
}
```

---

### 2. Get Product Request Status

Retrieve the current status of a product creation request.

**Endpoint**: `GET /api/v1/products/{requestId}`
**Authentication**: Required (Bearer token)

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `requestId` | guid | The unique identifier returned when creating the request |

#### Request Example

```http
GET https://localhost:5001/api/v1/products/3fa85f64-5717-4562-b3fc-2c963f66afa6
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

#### Response

**Status**: `200 OK`

```json
{
  "requestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "provider": "Bloomberg",
  "productSymbol": "AAPL",
  "status": "Succeed",
  "productCode": "BBG000B9XRY4",
  "errorMessage": null,
  "createdAt": "2026-02-10T08:00:00Z",
  "updatedAt": "2026-02-10T08:05:23Z"
}
```

#### Status Values

| Status | Description |
|--------|-------------|
| `Requested` | Request received and enqueued to Hangfire |
| `Acknowledged` | Provider confirmed receipt |
| `Succeed` | Product created successfully, `productCode` available (ProviderCreated) |
| `Failed` | Creation failed, `errorMessage` contains details (ProviderRejected or Failed) |

#### Error Responses

**404 Not Found** - Request ID doesn't exist
```json
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Product creation message not found",
  "status": 404,
  "detail": "No product creation message found with ID 3fa85f64-5717-4562-b3fc-2c963f66afa6"
}
```

---

## Health Monitoring

The API provides three health check endpoints for monitoring and orchestration.

### 1. Overall Health Check

**Endpoint**: `GET /health`  
**Authentication**: None (public)

Returns comprehensive health status of all components.

#### Response Example

```json
{
  "status": "Healthy",
  "timestamp": "2026-02-10T08:30:00Z",
  "duration": "00:00:00.0234567",
  "checks": [
    {
      "name": "database",
      "status": "Healthy",
      "description": null,
      "duration": "00:00:00.0123456",
      "exception": null,
      "data": {}
    },
    {
      "name": "self",
      "status": "Healthy",
      "description": null,
      "duration": "00:00:00.0001234",
      "exception": null,
      "data": {}
    }
  ]
}
```

### 2. Liveness Probe

**Endpoint**: `GET /health/live`  
**Authentication**: None (public)

Indicates if the application is running. Used by orchestrators (Kubernetes, Docker) to determine if the container should be restarted.

#### Response
```json
{
  "status": "Healthy",
  "timestamp": "2026-02-10T08:30:00Z",
  "duration": "00:00:00.0001234",
  "checks": [
    {
      "name": "self",
      "status": "Healthy",
      "description": null,
      "duration": "00:00:00.0001234",
      "exception": null,
      "data": {}
    }
  ]
}
```

### 3. Readiness Probe

**Endpoint**: `GET /health/ready`  
**Authentication**: None (public)

Indicates if the application is ready to accept traffic. Checks database connectivity and other dependencies.

#### Response
```json
{
  "status": "Healthy",
  "timestamp": "2026-02-10T08:30:00Z",
  "duration": "00:00:00.0123456",
  "checks": [
    {
      "name": "database",
      "status": "Healthy",
      "description": null,
      "duration": "00:00:00.0123456",
      "exception": null,
      "data": {}
    }
  ]
}
```

### Health Status Values

| Status | HTTP Code | Description |
|--------|-----------|-------------|
| `Healthy` | 200 | All checks passed |
| `Degraded` | 200 | Some non-critical checks failed |
| `Unhealthy` | 503 | Critical checks failed |

---

## Error Handling

The API uses **RFC 7807 Problem Details** for standardized error responses.

### Error Response Structure

All errors follow this format:

```json
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "detail": "Additional details about the error",
  "errors": {
    "FieldName": ["Error message 1", "Error message 2"]
  }
}
```

### Common HTTP Status Codes

| Code | Meaning | When It Occurs |
|------|---------|----------------|
| 200 | OK | Successful GET request |
| 201 | Created | Successful POST request |
| 400 | Bad Request | Validation failure, malformed request |
| 401 | Unauthorized | Missing or invalid authentication token |
| 404 | Not Found | Resource doesn't exist |
| 500 | Internal Server Error | Unexpected server error |
| 503 | Service Unavailable | Health check failed, service not ready |

### Error Logging

All errors are automatically logged with:
- **Timestamp**: When the error occurred
- **Request Details**: HTTP method, path, headers
- **Exception Details**: Stack trace, inner exceptions
- **Correlation ID**: For tracing across services

---

## Configuration

### Configuration Files

#### Development
`appsettings.Development.json` - Used when `ASPNETCORE_ENVIRONMENT=Development`

#### Production
`appsettings.json` - Base configuration  
Environment variables - Override sensitive settings

### Key Configuration Sections

#### 1. Connection Strings
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ProductCreationDb;Trusted_Connection=True;"
  }
}
```


#### 3. JWT Configuration
```json
{
  "Jwt": {
    "Issuer": "https://product-creation-api.example.com",
    "Audience": "https://product-creation-api.example.com",
    "SecretKey": "YourSuperSecretKeyThatIsAtLeast32CharactersLong!"
  }
}
```

#### 4. Logging Configuration
```json
{
  "Serilog": {
    "MinimumLevel": {
      "Default": "Information",
      "Override": {
        "Microsoft": "Warning",
        "System": "Warning"
      }
    },
    "WriteTo": [
      {
        "Name": "Console"
      },
      {
        "Name": "File",
        "Args": {
          "path": "logs/log-.txt",
          "rollingInterval": "Day"
        }
      }
    ]
  }
}
```

### Environment Variables

Override configuration using environment variables:

```bash
# Connection String
ConnectionStrings__DefaultConnection="Server=prod-server;Database=ProductCreationDb;..."

# AWS Settings
AWS__SQS__QueueUrl="https://sqs.eu-west-3.amazonaws.com/..."
AWS__SQS__AccessKey="PROD_ACCESS_KEY"
AWS__SQS__SecretKey="PROD_SECRET_KEY"

# JWT Settings
Jwt__SecretKey="ProductionSecretKey..."
```

---

## Monitoring and Logging

### Log Locations

#### Development
- **Console**: Real-time output in terminal
- **Files**: `logs/log-YYYY-MM-DD.txt` (daily rotation)

#### Production
- **AWS CloudWatch**: Centralized log aggregation
- **Log Group**: `/aws/product-creation-api`

### Log Levels

| Level | Usage |
|-------|-------|
| **Verbose** | Detailed diagnostic information |
| **Debug** | Internal system events for debugging |
| **Information** | General informational messages |
| **Warning** | Unexpected but handled situations |
| **Error** | Errors and exceptions |
| **Fatal** | Critical failures requiring immediate attention |

### Structured Logging

Logs include structured data for easy querying:

```json
{
  "Timestamp": "2026-02-10T08:30:00.123Z",
  "Level": "Information",
  "MessageTemplate": "Product creation request {RequestId} created for provider {Provider}",
  "Properties": {
    "RequestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "Provider": "Bloomberg",
    "MachineName": "api-server-01",
    "ThreadId": 42
  }
}
```

### Correlation Tracking

Each request is assigned a correlation ID that flows through:
- API request/response
- Database operations
- SQS messages
- Background processing
- Provider API calls

This enables end-to-end tracing of requests across all components.

---

## Support and Troubleshooting

### Common Issues

#### 1. Database Connection Failures
**Symptom**: Health check shows database unhealthy  
**Solution**: Verify connection string, ensure SQL Server is running

#### 2. SQS Access Denied
**Symptom**: 500 error when creating products  
**Solution**: Verify AWS credentials and IAM permissions

#### 3. JWT Token Invalid
**Symptom**: 401 Unauthorized responses  
**Solution**: Ensure token hasn't expired, verify secret key matches

#### 4. Swagger Not Available
**Symptom**: 404 on `/swagger`  
**Solution**: Swagger only available in Development mode

### Getting Help

For issues or questions:
1. Check application logs in `logs/` directory
2. Review CloudWatch logs for production issues
3. Verify configuration in `appsettings.json`
4. Contact the development team

---

## Appendix

### Supported Providers

| Provider | Description | Status |
|----------|-------------|--------|
| **Bloomberg** | Financial data and analytics | ✅ Active |
| **Refinitiv** | Market data and infrastructure | ✅ Active |
| **Six** | Swiss financial information services | ✅ Active |

### API Versioning Strategy

- **Current Version**: v1
- **Versioning Method**: URL segment (`/api/v1/`) and header (`X-Api-Version`)
- **Backward Compatibility**: Maintained for at least 2 major versions
- **Deprecation Notice**: Minimum 6 months before removal

### Performance Characteristics

- **Average Response Time**: < 100ms (excluding provider processing)
- **Throughput**: 1000+ requests/second (with proper scaling)
- **SQS Processing**: Near real-time (< 5 seconds)

---

**Document Version**: 1.0  
**Last Updated**: February 10, 2026  
**API Version**: v1  

© ContribFactory 2026
