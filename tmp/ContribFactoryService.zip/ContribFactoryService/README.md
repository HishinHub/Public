# Product Creation API

A .NET Core 8 WebAPI for managing product creation requests to Bloomberg, Refinitiv, and Six providers.

## Architecture

This solution follows **Clean Architecture** principles with **Domain-Driven Design (DDD)**:

```
├── src/
│   ├── ContribFactoryService.Domain/          # Domain entities and models
│   ├── ContribFactoryService.Application/     # Business logic and DTOs
│   ├── ContribFactoryService.Infrastructure/  # Data access and AWS services
│   └── ContribFactoryService.WebApi/          # REST API endpoints
└── tests/
    └── ContribFactoryService.Tests/           # Unit and integration tests
```

## Features

### Core Features
- ✅ **Clean Architecture** with clear separation of concerns
- ✅ **Domain-Driven Design** with rich domain models
- ✅ **RESTful API** with proper HTTP semantics
- ✅ **Minimal API** for lightweight endpoints
- ✅ **API Versioning** (v1) with header and URL support

### Technical Features
- ✅ **Serilog Logging**
- ✅ **JWT Authentication** with Bearer tokens
- ✅ **FluentValidation** for request validation
- ✅ **Global Exception Handler** with ProblemDetails (RFC 7807)
- ✅ **Health Checks** with liveness and readiness probes
- ✅ **Resilience** with Polly retry policies
- ✅ **Swagger/OpenAPI** documentation
- ✅ **Entity Framework Core** with SQL Server
- ✅ **Hangfire** for background job processing
- ✅ **SQL Server** for persistent message storage
- ✅ **HybridCache** for optimized status retrieval

### Testing
- ✅ **xUnit** test framework
- ✅ **Moq** for mocking
- ✅ **AutoBogus** for test data generation
- ✅ **FluentAssertions** for readable assertions
- ✅ **Integration tests** with WebApplicationFactory

## Workflow

### Product Creation Flow

1. **API receives request** → Initial submission (status: `Requested`)
2. **Validation** → API validates the product (if success, status: `Validated`)
3. **Persist & Queue** → Saves to database and enqueues Hangfire job
4. **Background Job** → Background job picks up the message (status: `ProviderSent`)
5. **Provider Dispatch** → Request sent to specific providers (status: `ProviderAck`)
6. **Final Update** → Transitions to `ProviderCreated`, `ProviderRejected`, or `Failed`
7. **Scheduled Synchronization** → Hangfire Recurring Job triggers `ProviderStatusSync`
8. **Optimized Polling** → Final statuses are cached via **HybridCache** to reduce DB load

### Status Workflow

```
Requested → Validated → ProviderSent → ProviderAck → ProviderCreated
```

## Getting Started

### Prerequisites

- .NET 8.0 SDK
- SQL Server (LocalDB for development)
- Persistence storage (SQL Server)
- Docker (optional)

### Configuration

Update `appsettings.json` with your settings:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Your SQL Server connection string"
  },
  "ConnectionStrings": {
    "ProductCreation": "Your SQL Server connection string"
  }
  "Jwt": {
    "SecretKey": "YourSecretKey (min 32 characters)"
  }
}
```

### Database Setup

```bash
# Navigate to WebApi project
cd src/ContribFactoryService.WebApi

# Create migration
dotnet ef migrations add InitialCreate --project ../ContribFactoryService.Infrastructure

# Update database
dotnet ef database update --project ../ContribFactoryService.Infrastructure
```

### Running the Application

```bash
# Restore dependencies
dotnet restore

# Run the WebApi
cd src/ContribFactoryService.WebApi
dotnet run

# API will be available at https://localhost:5001
# Swagger UI at https://localhost:5001/swagger
```

### Running Tests

```bash
# Run all tests
dotnet test

# Run with coverage
dotnet test --collect:"XPlat Code Coverage"
```

### Docker

```bash
# Build image
docker build -t product-creation-api .

# Run container
docker run -p 8080:8080 -e ASPNETCORE_ENVIRONMENT=Development product-creation-api
```

## API Endpoints

### Product Creation

#### Create Product Request
```http
POST /api/v1/products
Authorization: Bearer {token}
Content-Type: application/json

{
  "provider": "Bloomberg",
  "productSymbol": "AAPL",
  "productName": "Apple Inc.",
  "productDetails": "{\"exchange\":\"NASDAQ\"}"
}
```

**Response:** `201 Created`
```json
{
  "requestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "provider": "Bloomberg",
  "productSymbol": "AAPL",
  "status": "Requested",
  "createdAt": "2026-02-07T16:37:21Z",
  "updatedAt": "2026-02-07T16:37:21Z"
}
```

#### Get Product Request Status
```http
GET /api/v1/products/{requestId}
Authorization: Bearer {token}
```

**Response:** `200 OK`
```json
{
  "requestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "provider": "Bloomberg",
  "productSymbol": "AAPL",
  "status": "ProviderCreated",
  "productCode": "BLOOMBERG-AAPL-a1b2c3d4",
  "createdAt": "2026-02-07T16:37:21Z",
  "updatedAt": "2026-02-07T16:37:45Z"
}
```

### Health Checks

```http
GET /health          # Overall health
GET /health/live     # Liveness probe
GET /health/ready    # Readiness probe
```

## Providers

- **Bloomberg** - Financial data provider
- **Refinitiv** - Market data and infrastructure
- **Six** - Swiss financial services

## Deployment

### GitLab CI/CD

The project includes a complete `.gitlab-ci.yml` with:
- Build and test automation
- Docker image creation
- Multi-environment deployment (dev, integration, preprod, prod)

## Project Structure

### Domain Layer
- `Models/` - Domain entities (ProductRequest, Provider, ProductRequestStatus)

### Application Layer
- `Interfaces/` - Repository and service interfaces
- `Services/` - Business logic services
- `DataValidation/` - FluentValidation validators

### Infrastructure Layer
- `Persistence/` - EF Core DbContext and configurations
- `Repositories/` - Repository implementations
- `AWS/` - AWS SQS service implementations

### WebApi Layer
- `Endpoints/` - Minimal API endpoint definitions
- `Middleware/` - Global exception handler
- `Configuration/` - Authentication and other configurations

## Contributing

1. Create a feature branch
2. Make your changes
3. Add/update tests
4. Ensure all tests pass
5. Submit a merge request

## License

Copyright © ContribFactory 2026
