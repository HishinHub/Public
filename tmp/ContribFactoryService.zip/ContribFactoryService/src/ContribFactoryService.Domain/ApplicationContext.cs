namespace ContribFactoryService.Domain;

/// <summary>
/// Application-wide constants and contextual identifiers.
/// </summary>
public static class ApplicationContext
{
    public static class Resilience
    {
        public const string RetryPipelineName = "retry";
        public const string FixedRateLimitingPolicy = "fixed";
    }

}
