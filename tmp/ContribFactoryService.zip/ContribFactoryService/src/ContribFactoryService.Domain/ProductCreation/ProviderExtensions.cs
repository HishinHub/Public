using System.Collections.Generic;

namespace ContribFactoryService.Domain.ProductCreation;

/// <summary>
/// Extensions for Provider enum
/// </summary>
public static class ProviderExtensions
{
    private static readonly Dictionary<ProviderName, string> Trigrams = new()
    {
        { ProviderName.Bloomberg, "BLO" },
        { ProviderName.Refinitiv, "REF" },
        { ProviderName.Six, "SIX" }
    };

    /// <summary>
    /// Gets the unique trigram for the given provider (first 3 letters of the provider name)
    /// </summary>
    public static string GetTrigram(this ProviderName provider)
    {
        if (Trigrams.TryGetValue(provider, out var trigram))
        {
            return trigram;
        }

        // Fallback to first 3 letters if not in dictionary
        var name = provider.ToString();
        return name.Length >= 3 ? name[..3].ToUpperInvariant() : name.ToUpperInvariant();
    }
}
