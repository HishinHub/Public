using ContribFactoryService.Domain.ProductCreation;

namespace ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;

/// <summary>
/// Response from a provider after sending a request
/// </summary>
public record SendRequestResponse
{
    public bool Success { get; init; }
    public string? ExternalRequestId { get; init; }
    public string? ExternalProductCode { get; init; }
    public string? ErrorMessage { get; init; }
    public ProductCreationProviderStatus? Status { get; init; }
}
