using ContribFactoryService.Domain.ProductCreation;

namespace ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;

/// <summary>
/// API response DTO that formats Provider and Status as human-readable "Name (id)" strings.
/// </summary>
public record ProductCreationApiResponse
{
    /// <summary>The parent request ID</summary>
    public string RequestId { get; init; } = string.Empty;

    /// <summary>The product identifier (ISIN/Code)</summary>
    public string ProductCode { get; init; } = string.Empty;

    /// <summary>The internal unique tracking ID for this provider request</summary>
    public string ProviderRequestId { get; init; } = string.Empty;

    /// <summary>Provider formatted as "Bloomberg (1)"</summary>
    public string Provider { get; init; } = string.Empty;

    /// <summary>Raw integer value of the provider enum</summary>
    public int ProviderId { get; init; }

    /// <summary>Status formatted as "Received (1)"</summary>
    public string Status { get; init; } = string.Empty;

    /// <summary>Raw integer value of the status enum</summary>
    public int StatusId { get; init; }

    /// <summary>Detailed error message if the status is Rejected or Failed</summary>
    public string? ErrorMessage { get; init; }

    /// <summary>Creation timestamp of this provider request entry</summary>
    public DateTime CreatedAt { get; init; }

}
