using System.Text.Json.Serialization;

namespace ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;

/// <summary>
/// Root request for product creation, consolidated from previous batch wrappers.
/// </summary>
public record ProductCreationRequest
{
    /// <summary>Type of request, defaulted to 'ProductCreation'</summary>
    [JsonPropertyName("requestType")]
    public string RequestType { get; init; } = "ProductCreation";

    /// <summary>Timestamp when the request was initiated</summary>
    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; init; } = DateTime.UtcNow;

    /// <summary>List of default providers to use if not specified at payload level (e.g., 'Bloomberg', 'Refinitiv')</summary>
    [JsonPropertyName("defaultProviders")]
    public List<string> DefaultProviders { get; init; } = new();

    /// <summary>Batch of products to be created</summary>
    [JsonPropertyName("payload")]
    public List<ProductPayload> Payload { get; init; } = new();
}

public record ProductPayload
{
    /// <summary>Type of product (e.g., 'FinancialProduct')</summary>
    [JsonPropertyName("productType")]
    public string ProductType { get; init; } = string.Empty;

    /// <summary>Specific providers for this product. Overrides request-level DefaultProviders if specified.</summary>
    [JsonPropertyName("providers")]
    public List<string> Providers { get; init; } = new();

    /// <summary>
    /// Effective provider list: uses this payload's own Providers when specified,
    /// otherwise falls back to the parent request's DefaultProviders.
    /// </summary>
    public IEnumerable<string> GetEffectiveProviders(ProductCreationRequest parent) =>
        Providers.Any() ? Providers : (parent?.DefaultProviders ?? []);

    /// <summary>ISIN or equivalent product identifier.</summary>
    [JsonPropertyName("productCode")]
    public string ProductCode { get; init; } = string.Empty;

    /// <summary>Common name of the product.</summary>
    [JsonPropertyName("productName")]
    public string ProductName { get; init; } = string.Empty;

    /// <summary>Optional long description of the product.</summary>
    [JsonPropertyName("description")]
    public string Description { get; init; } = string.Empty;

    // ── Refinitiv-specific typed fields ──────────────────────────────────────

    /// <summary>
    /// ISO 4217 currency code (e.g. "EUR").
    /// Maps to Refinitiv field <c>InsCurrency</c>.
    /// </summary>
    [JsonPropertyName("currency")]
    public string? Currency { get; init; }

    /// <summary>
    /// Annual coupon rate as a percentage (e.g. 0.5 for 0.5 %).
    /// Maps to Refinitiv field <c>InsCouponRate</c>.
    /// </summary>
    [JsonPropertyName("coupon")]
    public double? Coupon { get; init; }

    /// <summary>
    /// Bond maturity date.
    /// Maps to Refinitiv field <c>InsDtMaturity</c>.
    /// </summary>
    [JsonPropertyName("maturityDate")]
    public DateTime? MaturityDate { get; init; }

    // ── Bloomberg-specific typed fields ──────────────────────────────────────

    /// <summary>Bloomberg Instrument ID</summary>
    [JsonPropertyName("insId")]
    public string? InsId { get; init; }

    /// <summary>ISIN Code</summary>
    [JsonPropertyName("isinCode")]
    public string? IsinCode { get; init; }

    /// <summary>Infinity SP ID</summary>
    [JsonPropertyName("infinitySpId")]
    public string? InfinitySpId { get; init; }

    // ── Generic extension bag ─────────────────────────────────────────────────

    /// <summary>
    /// Arbitrary provider-specific or future fields not yet promoted to typed properties.
    /// </summary>
    [JsonPropertyName("fields")]
    public Dictionary<string, object> Fields { get; init; } = new();
}
