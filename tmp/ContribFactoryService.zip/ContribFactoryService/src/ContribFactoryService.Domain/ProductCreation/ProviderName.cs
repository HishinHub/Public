namespace ContribFactoryService.Domain.ProductCreation;

/// <summary>
/// Supported product creation providers
/// </summary>
public enum ProviderName
{
    /// <summary>
    /// Unknown provider
    /// </summary>
    Unknown = 0,

    /// <summary>
    /// Bloomberg provider
    /// </summary>
    Bloomberg = 1,
    
    /// <summary>
    /// Refinitiv provider
    /// </summary>
    Refinitiv = 2,
    
    /// <summary>
    /// Six provider
    /// </summary>
    Six = 3
}
