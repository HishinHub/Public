using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;


namespace ContribFactoryService.Domain.ProductCreation;

/// <summary>
/// Represents a product creation message entity stored in the database
/// </summary>
public class ProductCreationTrace
{
    /// <summary>
    /// Database primary key (autoincrement)
    /// </summary>
    public int Id { get; set; }
    /// <summary>
    /// Unique request identifier generated at reception and returned in the response
    /// </summary>
    public string RequestId { get; set; } = string.Empty;
    
    /// <summary>
    /// The original product creation request as received from the API
    /// </summary>
    public ProductCreationRequest OriginalRequest { get; set; } = new();
    
    /// <summary>
    /// List of providers and their statuses for this message
    /// </summary>
    public List<ProductCreationProvider> ProviderRequests { get; set; } = new();

    /// <summary>
    /// Summary status of the request
    /// </summary>
    public ProductCreationTraceStatus Status { get; set; }
    
    /// <summary>
    /// When the message was created
    /// </summary>
    public DateTime CreatedAt { get; set; }

    /// <summary>
    /// When the message was last updated
    /// </summary>
    public DateTime UpdatedAt { get; set; }
}
