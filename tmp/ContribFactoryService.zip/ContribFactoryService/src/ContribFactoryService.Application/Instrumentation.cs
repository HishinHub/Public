using System.Diagnostics;

namespace ContribFactoryService.Application;

public static class Instrumentation
{
    public const string ServiceName = "ContribFactory.ProductCreation";
    public const string WebApiServiceName = "ContribFactory.WebApi";
    public static readonly ActivitySource ActivitySource = new(ServiceName);

    public static class Activities
    {
        public const string SendProductCreationRequest = "SendProductCreationRequest";
        public const string ProcessProductCreationBackgroundJob = "ProcessProductCreationBackgroundJob";
        public const string DispatchAllProviders = "DispatchAllProviders";
        public const string DispatchToSingleProvider = "DispatchToSingleProvider";
    }

    public static class Tags
    {
        public const string CorrelationId = "prodcrea.correlation_id";
        public const string Provider = "prodcrea.provider";
        public const string OtelStatusCode = "otel.status_code";
        public const string OtelStatusDescription = "otel.status_description";
    }
}
