using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;

namespace ContribFactoryService.Application.ProductCreationRules;

/// <summary>
/// Business rules that apply to the incoming <see cref="ProductCreationRequest"/> before any entity is created.
/// </summary>
public static class ProductCreationRequestRules
{
    /// <summary>
    /// Returns duplicate <c>(ProductCode, ProviderName)</c> pairs found in the request payload.
    /// A pair is a duplicate when the same ProductCode is listed more than once for the same provider
    /// (taking effective providers into account, i.e. falling back to DefaultProviders when
    /// a payload has no explicit providers).
    /// </summary>
    public static IEnumerable<(string ProductCode, string Provider)> FindDuplicateProductCodePerProvider(
        ProductCreationRequest request)
    {
        return request.Payload
            .SelectMany(payload =>
                payload.GetEffectiveProviders(request)
                    .Select(provider => (payload.ProductCode, Provider: provider)))
            .GroupBy(x => x)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key);
    }

    /// <summary>
    /// Returns <c>true</c> when all <c>(ProductCode, Provider)</c> pairs in the request are unique.
    /// </summary>
    public static bool HasUniqueProductCodePerProvider(ProductCreationRequest request)
        => !FindDuplicateProductCodePerProvider(request).Any();
}
