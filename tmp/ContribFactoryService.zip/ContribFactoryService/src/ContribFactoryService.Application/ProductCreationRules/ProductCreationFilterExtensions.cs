using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using Microsoft.Extensions.Logging;

namespace ContribFactoryService.Application.ProductCreationRules;

/// <summary>
/// Provides extension methods for filtering ProductCreationProvider lists
/// </summary>
public static class ProductCreationFilterExtensions
{
    /// <summary>
    /// Filters provider requests to only include those with Received status
    /// </summary>
    public static List<ProductCreationProvider> FilterByReceivedStatus(
        this List<ProductCreationProvider> providerRequests,
        string requestId,
        ILogger logger)
    {
        var filtered = new List<ProductCreationProvider>();

        foreach (var provider in providerRequests)
        {
            if (provider.Status == ProductCreationProviderStatus.Received)
            {
                filtered.Add(provider);
            }
            else
            {
                logger.LogInformation(
                    "[REQ:{RequestId}][Filter] Excluding provider {Provider} - status is {Status}, not Received",
                    requestId,
                    provider.ProviderName,
                    provider.Status);
            }
        }

        return filtered;
    }

    /// <summary>
    /// Filters the collection to include only providers that are enabled.
    /// </summary>
    public static IEnumerable<ProductCreationProvider> FilterByEnabledProviders(
        this IEnumerable<ProductCreationProvider> providers,
        string requestId,
        List<ProviderName> enabledProviders,
        ILogger logger,
        out List<ProductCreationProvider> disabledProviders)
    {
        var providersList = providers.ToList();
        disabledProviders = providersList.Where(p => p.IsDisabled(enabledProviders)).ToList();

        foreach (var provider in disabledProviders)
        {
            string errorMessage = $"Skipping provider {provider.ProviderName} for payload {provider.ProductPayload.ProductCode} because it is not enabled";
            logger.LogInformation(
                "[REQ:{RequestId}][Filter] " + errorMessage,
                requestId);
        }

        return providersList.Where(p => !p.IsDisabled(enabledProviders));
    }

    /// <summary>
    /// Filters provider requests to only include those that are enabled in configuration.
    /// Handles side effects for disabled providers.
    /// </summary>
    public static List<ProductCreationProvider> FilterByEnabledProvidersAndUpdateStatus(
        this List<ProductCreationProvider> providerRequests,
        string requestId,
        List<ProviderName> enabledProviders,
        StatsContext statsContext,
        ILogger logger)
    {
        var enabled = providerRequests.FilterByEnabledProviders(requestId, enabledProviders, logger, out var disabled).ToList();

        foreach (var provider in disabled)
        {
            provider.Status = ProductCreationProviderStatus.DisabledProvider;
            provider.ErrorMessage = $"Skipping provider {provider.ProviderName} for payload {provider.ProductPayload.ProductCode} because it is not enabled";
            statsContext.FailedCount++;
        }

        return enabled;
    }
}
