using System.ComponentModel.DataAnnotations;

namespace ContribFactoryService.Application.ProviderSynchronizer;

/// <summary>
/// Options for the Provider Synchronizer
/// </summary>
public class ProviderSynchronizerOptions
{
    public const string SectionName = "ProviderSynchronizer";

    /// <summary>
    /// Interval in minutes for the periodic synchronization job
    /// </summary>
    [Range(1, 1440)]
    public int IntervalMinutes { get; set; } = 5;

    /// <summary>
    /// Name of the recurring job
    /// </summary>
    public string JobName { get; set; } = "ProviderSynchronizer";

    /// <summary>
    /// List of providers that should be synchronized
    /// </summary>
    public List<ContribFactoryService.Domain.ProductCreation.ProviderName> EnabledProviders { get; set; } = new();
}
