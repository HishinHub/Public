using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using ContribFactoryService.Application.Interfaces;

namespace ContribFactoryService.Application.ProviderSynchronizer;

public static class DependencyInjection
{
    public static IServiceCollection AddProviderSynchronizer(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<ProviderSynchronizerOptions>()
            .Bind(configuration.GetSection(ProviderSynchronizerOptions.SectionName))
            .ValidateDataAnnotations()
            .ValidateOnStart();
        
        services.AddScoped<IProviderSynchronizerService, ProviderSynchronizerService>();

        services.AddHostedService<SynchronizationBackgroundService>();
        
        return services;
    }

}
