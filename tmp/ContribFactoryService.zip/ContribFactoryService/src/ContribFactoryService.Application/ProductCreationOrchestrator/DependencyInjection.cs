using ContribFactoryService.Application.ProductCreationOrchestrator;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryService.Application.ProductCreationOrchestrator;

/// <summary>
/// Dependency injection configuration for ProductCreationOrchestrator
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddProductCreationOrchestrator(this IServiceCollection services)
    {
        services.AddScoped<ProductCreationService>();
        services.AddSingleton<IProductCreationFactory, ProductCreationFactory>();
        
        return services;
    }
}
