using ContribFactoryService.Application.Validators;
using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Application.ProviderSynchronizer;
using ContribFactoryService.Application.ProviderDispatcher;
using ContribFactoryService.Application.ProductCreationOrchestrator;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;

using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

namespace ContribFactoryService.Application;

/// <summary>
/// Dependency injection configuration for Application layer
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
    {
        // Register the generic validator explicitly for ProductCreationRequest
        services.AddScoped<IValidator<ProductCreationRequest>, GenericRequestValidator>();

        // Register provider-specific validators as IProviderRequestValidator
        // Add one line per new provider validator as they are introduced.
        services.AddScoped<IProviderRequestValidator, RefinitivRequestValidator>();

        // Register the orchestration validation service
        services.AddScoped<ProductCreationRequestValidationService>();

        // Register services in sub-modules
        services.AddProviderSynchronizer(configuration);
        services.AddProviderDispatcher(configuration);
        services.AddProductCreationOrchestrator();
        
        return services;
    }
}
