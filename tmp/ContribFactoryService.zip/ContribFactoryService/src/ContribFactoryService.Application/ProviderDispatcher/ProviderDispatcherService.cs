using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Application.ProductCreationRules;
using System.Diagnostics;
using ContribFactoryService.Domain.ProductCreation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ContribFactoryService.Application.ProviderDispatcher;

/// <summary>
/// Orchestrates product creation dispatching to multiple provider services
/// </summary>
public class ProviderDispatcherService : IProviderDispatcherService
{
    private readonly IEnumerable<IProviderAgent> _providerAgents;
    private readonly ProviderDispatcherOptions _options;
    private readonly IProductCreationTraceRepository _repository;
    private readonly IProviderDispatcherMapper _mapper;
    private readonly ILogger<ProviderDispatcherService> _logger;

    public ProviderDispatcherService(
        IEnumerable<IProviderAgent> providerAgents,
        IOptions<ProviderDispatcherOptions> options,
        IProductCreationTraceRepository repository,
        IProviderDispatcherMapper mapper,
        ILogger<ProviderDispatcherService> logger)
    {
        _providerAgents = providerAgents;
        _options = options.Value;
        _repository = repository;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task DispatchAsync(
        ProductCreationMessage message,
        CancellationToken cancellationToken = default)
    {
        using var dispatchActivity = Instrumentation.ActivitySource.StartActivity(Instrumentation.Activities.DispatchAllProviders);
        dispatchActivity?.SetTag(Instrumentation.Tags.CorrelationId, message.RequestId);

        _logger.LogInformation(
            "[REQ:{RequestId}][ProviderDispatcher] Start dispatching message: {Message}",
            message.RequestId,
            message);

        var runContext = new RunContext
        {
            RunId = message.RequestId,
            RequestId = message.RequestId
        };

        var enabledProviders = _options.EnabledProviders;
        var statsContext = new StatsContext();

        // Fetch the trace from database
        var trace = await _repository.GetByRequestIdAsync(message.RequestId, cancellationToken);
        if (trace == null)
        {
            _logger.LogError("[REQ:{RequestId}][ProviderDispatcher] Trace not found for dispatch", message.RequestId);
            return;
        }

        _logger.LogInformation(
            "[REQ:{RequestId}][ProviderDispatcher] Found trace with {Count} total provider requests ({ProviderRequestIds})",
            trace.RequestId,
            trace.ProviderRequests.Count,
            string.Join(", ", trace.ProviderRequests.Select(p => p.ProviderRequestId)));

        // Filter to only process providers with Received status and that are enabled
        var eligibleProviders = trace.ProviderRequests
            .FilterByReceivedStatus(trace.RequestId, _logger)
            .FilterByEnabledProvidersAndUpdateStatus(
                trace.RequestId,
                enabledProviders,
                statsContext,
                _logger);

        _logger.LogInformation(
            "[REQ:{RequestId}][ProviderDispatcher] Found {Count} eligible provider requests for processing",
            trace.RequestId,
            eligibleProviders.Count());

        foreach (var providerRequest in eligibleProviders)
        {
            var providerRunContext = runContext with { ProviderRequestId = providerRequest.ProviderRequestId };

            var agent = GetProviderAgent(providerRequest, trace.RequestId, statsContext);
            if (agent == null) continue;

            try
            {
                using var providerActivity = Instrumentation.ActivitySource.StartActivity(Instrumentation.Activities.DispatchToSingleProvider);
                providerActivity?.SetTag(Instrumentation.Tags.Provider, providerRequest.ProviderName);
                providerActivity?.SetTag(Instrumentation.Tags.CorrelationId, trace.RequestId);

                _logger.LogInformation(
                    "[REQ:{RequestId}/{ProviderRequestId}][ProviderDispatcher] Dispatching payload {ProductCode} to {Provider}",
                    trace.RequestId,
                    providerRequest.ProviderRequestId,
                    providerRequest.ProductPayload.ProductCode,
                    providerRequest.ProviderName);

                // Call the agent with the message and specific payload
                var response = await agent.SendRequestAsync(providerRequest.ProductPayload, providerRunContext, cancellationToken);

                _mapper.MapToProductCreationProvider(trace.RequestId, providerRequest, response, statsContext);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Error dispatching payload {providerRequest.ProductPayload.ProductCode} to {providerRequest.ProviderName}";
                _logger.LogError(
                    ex,
                    "[REQ:{RequestId}/{ProviderRequestId}][ProviderDispatcher] " + errorMessage,
                    trace.RequestId,
                    providerRequest.ProviderRequestId);

                providerRequest.Status = ProductCreationProviderStatus.Failed;
                providerRequest.ErrorMessage = errorMessage;
                statsContext.FailedCount++;
            }
        }

        // Update the trace status based on provider statuses
        trace.ReviewTraceStatus();

        // Persist updated trace to database
        await _repository.UpdateAsync(trace);
        _logger.LogInformation(
            "[REQ:{RequestId}][ProviderDispatcher] Persisted trace with status {Status}",
            trace.RequestId,
            trace.Status);

        _logger.LogInformation(
            "[REQ:{RequestId}][ProviderDispatcher] Finished dispatch cycle. Dispatch result: {SentCount} sent, {FailedCount} failed",
            trace.RequestId,
            statsContext.SentCount,
            statsContext.FailedCount);
    }

    private IProviderAgent? GetProviderAgent(
        ProductCreationProvider providerRequest,
        string requestId,
        StatsContext statsContext)
    {
        var agent = _providerAgents.FirstOrDefault(a => a.Provider == providerRequest.ProviderName);

        if (agent != null)
        {
            return agent;
        }

        var errorMessage = $"No agent registered for provider {providerRequest.ProviderName}";
        _logger.LogError(
            "[REQ:{RequestId}][ProviderDispatcher] " + errorMessage,
            requestId);

        providerRequest.Status = ProductCreationProviderStatus.UnsupportedProvider;
        providerRequest.ErrorMessage = errorMessage;
        statsContext.FailedCount++;

        return null;
    }
}
