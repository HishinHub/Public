using System.ComponentModel.DataAnnotations;
using ContribFactoryService.Domain.ProductCreation;

namespace ContribFactoryService.Application.ProviderDispatcher;

/// <summary>
/// Options for the Provider Dispatcher
/// </summary>
public class ProviderDispatcherOptions
{
    public const string SectionName = "ProviderDispatcher";

    /// <summary>
    /// List of providers that are enabled for dispatching
    /// </summary>
    public List<ProviderName> EnabledProviders { get; set; } = new();
}
