using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Application.ProductCreationRules;
using FluentValidation;

namespace ContribFactoryService.Application.Validators;

/// <summary>
/// Validator for ProductCreationRequest
/// </summary>
public class GenericRequestValidator : AbstractValidator<ProductCreationRequest>
{
    public GenericRequestValidator()
    {
        RuleFor(x => x.RequestType)
            .NotEmpty()
            .Equal("ProductCreation");



        RuleFor(x => x.Payload)
            .NotEmpty()
            .WithMessage("Payload must not be empty");

        // Validate root providers if any
        RuleForEach(x => x.DefaultProviders)
            .Must(p => Enum.TryParse<Domain.ProductCreation.ProviderName>(p, true, out _))
            .WithMessage("Invalid provider in root. Supported values are: Bloomberg, Refinitiv, Six");
        
        // Ensure each payload has at least one provider (either at payload level or root level)
        RuleForEach(x => x.Payload)
            .Must((root, payload) => payload.Providers.Any() || root.DefaultProviders.Any())
            .WithMessage("Each payload must have at least one provider specified (either in the payload or at the root level)");

        // Validate payload-specific providers if any
        RuleForEach(x => x.Payload)
            .ChildRules(payloadRule => {
                payloadRule.RuleForEach(p => p.Providers)
                    .Must(pName => Enum.TryParse<Domain.ProductCreation.ProviderName>(pName, true, out _))
                    .WithMessage("Invalid provider in payload. Supported values are: Bloomberg, Refinitiv, Six");
            });

        RuleForEach(x => x.Payload).SetValidator(new ProductPayloadValidator());

        // Ensure no (ProductCode, Provider) pair appears more than once
        RuleFor(x => x)
            .Must(ProductCreationRequestRules.HasUniqueProductCodePerProvider)
            .WithMessage(request =>
            {
                var duplicates = ProductCreationRequestRules
                    .FindDuplicateProductCodePerProvider(request)
                    .Select(d => $"'{d.ProductCode}' for provider '{d.Provider}'")
                    .ToList();
                return $"Duplicate (ProductCode, Provider) pairs detected: {string.Join(", ", duplicates)}. Each product code must be unique per provider."; 
            });
    }
}

public class ProductPayloadValidator : AbstractValidator<ProductPayload>
{
    public ProductPayloadValidator()
    {
        RuleFor(x => x.ProductCode).NotEmpty();
    }
}
