using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using FluentValidation.Results;

namespace ContribFactoryService.Application.Validators;

/// <summary>
/// Contract for a provider-specific request validator.
/// </summary>
public interface IProviderRequestValidator
{
    /// <summary>The provider this validator is responsible for.</summary>
    ProviderName Provider { get; }

    /// <summary>
    /// Validates the request against provider-specific rules.
    /// </summary>
    Task<ValidationResult> ValidateAsync(
        ProductCreationRequest request,
        CancellationToken cancellationToken = default);
}
