using System.Threading;
using System.Threading.Tasks;

namespace ContribFactoryService.Application.Interfaces;

/// <summary>
/// Interface for synchronizing product creation status from providers
/// </summary>
public interface IProviderSynchronizerService
{
    /// <summary>
    /// Synchronizes the status of pending product creation requests
    /// </summary>
    Task SynchronizeAsync(CancellationToken cancellationToken = default);
}
