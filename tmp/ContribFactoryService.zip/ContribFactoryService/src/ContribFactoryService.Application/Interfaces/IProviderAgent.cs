using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Domain.ProductCreation;

namespace ContribFactoryService.Application.Interfaces;

/// <summary>
/// Interface for provider-specific product creation agents
/// </summary>
public interface IProviderAgent
{
    /// <summary>
    /// The provider this service handles
    /// </summary>
    ProviderName Provider { get; }

    Task<SendRequestResponse> SendRequestAsync(
        ProductPayload payload,
        RunContext runContext,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Checks the status of a product creation request from the provider
    /// </summary>
    Task<GetStatusResponse> GetStatusAsync(
        RunContext runContext,
        string productCode,
        string? externalRequestId,
        CancellationToken cancellationToken = default);
}
