using ContribFactoryService.Domain.ProductCreation;

namespace ContribFactoryService.Application.Interfaces;

/// <summary>
/// Repository interface for ProductCreationTrace entities
/// </summary>
public interface IProductCreationTraceRepository
{
    /// <summary>
    /// Creates a new product creation message
    /// </summary>
    Task<ProductCreationTrace> CreateAsync(ProductCreationTrace request, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Gets a product creation message by request ID (NanoID)
    /// </summary>
    Task<ProductCreationTrace?> GetByRequestIdAsync(string requestId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets a product creation provider by its specific provider request ID
    /// </summary>
    Task<ProductCreationProvider?> GetByProviderRequestIdAsync(string providerRequestId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Gets a trace with its filtered provider requests by requestId and provider name.
    /// </summary>
    Task<ProductCreationTrace?> GetByRequestIdAndProviderNameAsync(string requestId, ProviderName providerName, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Gets all product creation providers that have not yet reached a terminal state
    /// (i.e. not <see cref="ProductCreationProviderStatus.Created"/> or <see cref="ProductCreationProviderStatus.Rejected"/>)
    /// whose parent message is also incomplete.
    /// Used by the ProviderSynchronizer to poll for in-progress work.
    /// </summary>
    Task<IReadOnlyList<ProductCreationProvider>> GetAllReadyToSync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates an existing product creation message
    /// </summary>
    Task<ProductCreationTrace> UpdateAsync(ProductCreationTrace request, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the database engine version
    /// </summary>
    Task<string> GetDatabaseVersionAsync(CancellationToken cancellationToken = default);
}
