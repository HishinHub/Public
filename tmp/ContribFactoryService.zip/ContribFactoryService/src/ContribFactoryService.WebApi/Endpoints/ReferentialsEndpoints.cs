using ContribFactoryService.Domain.ProductCreation;
using Asp.Versioning;
using ContribFactoryService.Infrastructure.Authentication;

namespace ContribFactoryService.WebApi.Endpoints;

/// <summary>
/// A single item in a referential list, representing a standardized system value or code.
/// </summary>
/// <param name="Id">The unique numeric identifier used to reference this specific referential item in API requests and database records.</param>
/// <param name="Name">The human-readable label or short code representing the item (e.g., 'Completed', 'Bloomberg', 'Six').</param>
/// <param name="Description">A detailed technical or functional explanation providing context on how this item affects the system's behavior or business logic.</param>
public record ReferentialItem(int Id, string Name, string Description);

public static class ReferentialsEndpoints
{
    public static IEndpointRouteBuilder MapReferentialsEndpoints(this IEndpointRouteBuilder app)
    {
        var versionSet = app.NewApiVersionSet()
            .HasApiVersion(new ApiVersion(1, 0))
            .ReportApiVersions()
            .Build();

        var group = app.MapGroup("api/v{version:apiVersion}/referentials")
            .WithApiVersionSet(versionSet)
            .WithTags("Referentials Data")
            .AddEndpointFilter<JwtEndpointFilter>();

        group.MapGet("/trace-statuses", GetTraceStatuses)
            .WithName("GetTraceStatuses")
            .WithOpenApi(operation =>
            {
                operation.Summary = "Get all trace statuses";
                operation.Description = "Returns a list of all possible statuses for a product creation trace/batch.";
                return operation;
            })
            .Produces<List<ReferentialItem>>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapGet("/provider-statuses", GetProviderStatuses)
            .WithName("GetProviderStatuses")
            .WithOpenApi(operation =>
            {
                operation.Summary = "Get all provider statuses";
                operation.Description = "Returns a list of all possible statuses for individual provider requests.";
                return operation;
            })
            .Produces<List<ReferentialItem>>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status404NotFound);

        return app;
    }

    private static IResult GetTraceStatuses()
    {
        var statuses = Enum.GetValues<ProductCreationTraceStatus>()
            .Select(s => new ReferentialItem((int)s, s.ToString(), GetTraceStatusDescription(s)))
            .ToList();

        return Results.Ok(statuses);
    }

    private static IResult GetProviderStatuses()
    {
        var statuses = Enum.GetValues<ProductCreationProviderStatus>()
            .Select(s => new ReferentialItem((int)s, s.ToString(), GetProviderStatusDescription(s)))
            .ToList();

        return Results.Ok(statuses);
    }

    private static string GetTraceStatusDescription(ProductCreationTraceStatus status) => status switch
    {
        ProductCreationTraceStatus.None => "No status assigned yet",
        ProductCreationTraceStatus.Received => "Product request received by the system",
        ProductCreationTraceStatus.OnGoing => "Product has passed validation",
        ProductCreationTraceStatus.ProviderInCharge => "Product is being processed by providers",
        ProductCreationTraceStatus.Completed => "All product creation steps completed successfully",
        ProductCreationTraceStatus.ProviderFailed => "One or more provider tasks failed",
        ProductCreationTraceStatus.TechnicalFailed => "A technical error occurred during processing",
        _ => string.Empty
    };

    private static string GetProviderStatusDescription(ProductCreationProviderStatus status) => status switch
    {
        ProductCreationProviderStatus.None => "No status assigned yet",
        ProductCreationProviderStatus.Received => "Request received for this provider",
        ProductCreationProviderStatus.Sent => "Product information sent to provider",
        ProductCreationProviderStatus.Ack => "Provider acknowledgment received",
        ProductCreationProviderStatus.Created => "Product successfully created",
        ProductCreationProviderStatus.Canceled => "Product creation canceled",
        ProductCreationProviderStatus.Rejected => "Product rejected due to functional errors",
        ProductCreationProviderStatus.Failed => "A technical error occurred",
        ProductCreationProviderStatus.ProviderFailed => "The external provider returned a failure",
        ProductCreationProviderStatus.UnsupportedProvider => "Provider is not supported for this product",
        ProductCreationProviderStatus.DisabledProvider => "Provider is currently disabled",
        _ => string.Empty
    };
}
