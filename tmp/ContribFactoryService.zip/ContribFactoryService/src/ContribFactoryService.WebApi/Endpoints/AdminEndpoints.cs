using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using ContribFactoryService.Infrastructure.Admin;
using ContribFactoryService.Application.ProductCreationOrchestrator;
using ContribFactoryService.Infrastructure.Authentication;

namespace ContribFactoryService.WebApi.Endpoints;

public static class AdminEndpoints
{
    public static void MapAdminEndpoints(this IEndpointRouteBuilder app)
    {
        // ── Protected admin endpoints ──────────────────────────────────────────
        var adminGroup = app.MapGroup("/api/admin")
            .WithTags("Admin")
            .WithOpenApi()
            .AddEndpointFilter<JwtEndpointFilter>();

        adminGroup.MapGet("/test/db-connection", async (AdminService adminService) =>
        {
            try
            {
                var version = await adminService.GetDatabaseVersionAsync();
                return Results.Ok(new 
                { 
                    status = "Success", 
                    message = "Successfully connected to the ProductCreation database.",
                    databaseVersion = version
                });
            }
            catch (Exception ex)
            {
                return Results.Problem($"Database connection failed: {ex.Message}", statusCode: 500);
            }
        })
        .WithName("TestDatabaseConnection")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Check database connectivity";
            operation.Description = "Performs a diagnostic check to verify if the API can reach the SQL Server and retrieves the database engine version.";
            return operation;
        })
        .Produces(StatusCodes.Status200OK)
        .ProducesProblem(StatusCodes.Status401Unauthorized)
        .ProducesProblem(StatusCodes.Status500InternalServerError);

        adminGroup.MapPost("/cancel-provider/{providerRequestId}", async (string providerRequestId, ProductCreationService productCreationService) =>
        {
            var success = await productCreationService.CancelProviderRequestIdAsync(providerRequestId);
            return success 
                ? Results.Ok(new { message = $"Provider request {providerRequestId} has been canceled." })
                : Results.Problem(new ProblemDetails
                {
                    Status = StatusCodes.Status404NotFound,
                    Title = "Provider Request Not Found",
                    Detail = $"Provider request {providerRequestId} not found."
                });
        })
        .WithName("CancelProviderRequest")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Cancel specific provider task";
            operation.Description = "Directly cancels an individual provider request within a batch.";
            var idParam = operation.Parameters.FirstOrDefault(p => p.Name == "providerRequestId");
            if (idParam != null) idParam.Description = "The unique tracking ID for the individual provider task to be terminated.";
            return operation;
        })
        .Produces(StatusCodes.Status200OK)
        .ProducesProblem(StatusCodes.Status401Unauthorized)
        .ProducesProblem(StatusCodes.Status404NotFound);

        adminGroup.MapPost("/cancel-failed-providers/{requestId}", async (string requestId, ProductCreationService productCreationService) =>
        {
            var canceledCount = await productCreationService.CancelFailedProvidersByRequestIdAsync(requestId);
            return Results.Ok(new { message = $"Canceled {canceledCount} failed provider requests for RequestId REQ:{requestId}." });
        })
        .WithName("CancelFailedProvidersByRequestId")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Purge failed tasks in a batch";
            operation.Description = "Cancels all provider requests in 'Rejected' or 'Failed' state for the specified RequestId.";
            var idParam = operation.Parameters.FirstOrDefault(p => p.Name == "requestId");
            if (idParam != null) idParam.Description = "The unique tracking ID of the batch where failed tasks should be purged.";
            return operation;
        })
        .Produces(StatusCodes.Status200OK)
        .ProducesProblem(StatusCodes.Status401Unauthorized)
        .ProducesProblem(StatusCodes.Status404NotFound);

        adminGroup.MapGet("/test/bloomberg-sftp-connection", async (AdminService adminService) =>
        {
            try
            {
                var success = await adminService.TestBloombergSftpConnectionAsync();
                return success
                    ? Results.Ok(new { status = "Success", message = "Bloomberg SFTP connection established successfully." })
                    : Results.Problem("Bloomberg SFTP session could not be opened.", statusCode: 500);
            }
            catch (Exception ex)
            {
                return Results.Problem($"Bloomberg SFTP connection test failed: {ex.Message}", statusCode: 500);
            }
        })
        .WithName("TestBloombergSftpConnection")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Test Bloomberg SFTP connectivity";
            operation.Description = "Performs a diagnostic check to verify that the API can establish an SFTP session with the Bloomberg server.";
            return operation;
        })
        .Produces(StatusCodes.Status200OK)
        .ProducesProblem(StatusCodes.Status401Unauthorized)
        .ProducesProblem(StatusCodes.Status500InternalServerError);
    }
}
