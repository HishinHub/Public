using Asp.Versioning;
using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Infrastructure.Authentication;
using ContribFactoryService.Application.ProductCreationOrchestrator;
using ContribFactoryService.Domain;
using ContribFactoryService.Domain.ProductCreation;

using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using Microsoft.AspNetCore.Mvc;

namespace ContribFactoryService.WebApi.Endpoints;

/// <summary>
/// Product creation endpoints
/// </summary>
public static class ProductCreationEndpoints
{
    public static IEndpointRouteBuilder MapProductCreationEndpoints(this IEndpointRouteBuilder app)
    {
        var versionSet = app.NewApiVersionSet()
            .HasApiVersion(new ApiVersion(1, 0))
            .ReportApiVersions()
            .Build();

        var group = app.MapGroup("api/v{version:apiVersion}/products")
            .WithApiVersionSet(versionSet)
            .WithTags("Product Creation")
            .AddEndpointFilter<JwtEndpointFilter>()
            .RequireRateLimiting(ApplicationContext.Resilience.FixedRateLimitingPolicy);



        // Authentication removed

        group.MapPost("/", CreateProductRequest)
            .WithName("CreateProductRequest")
            .WithOpenApi(operation =>
            {
                operation.Summary = "Request product creation";
                operation.Description = "Submits a product creation request to the specified provider (Bloomberg, Refinitiv, or Six)";
                return operation;
            })
            .Produces<ProductCreationApiGroupResponse>(StatusCodes.Status201Created)
            .ProducesProblem(StatusCodes.Status400BadRequest)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status500InternalServerError);

        group.MapGet("/{requestId}", GetProductCreationStatus)
            .WithName("GetProductCreationStatus")
            .WithOpenApi(operation =>
            {
                operation.Summary = "Get product creation status";
                operation.Description = "Retrieves the current status and details of a product creation message";
                var idParam = operation.Parameters.FirstOrDefault(p => p.Name == "requestId");
                if (idParam != null) idParam.Description = "The unique tracking ID assigned to the product creation batch.";
                return operation;
            })
            .Produces<ProductCreationApiGroupResponse>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapGet("/{requestId}/providers/{providerName}", GetProviderStatus)
            .WithName("GetProviderStatus")
            .WithOpenApi(operation =>
            {
                operation.Summary = "Get status for a specific provider";
                operation.Description = "Retrieves the status and details for a specific provider within a product creation request";
                
                var idParam = operation.Parameters.FirstOrDefault(p => p.Name == "requestId");
                if (idParam != null) idParam.Description = "The unique tracking ID assigned to the product creation batch.";
                
                var provParam = operation.Parameters.FirstOrDefault(p => p.Name == "providerName");
                if (provParam != null) provParam.Description = "The name of the external provider (Bloomberg, Refinitiv, or Six).";
                
                return operation;
            })
            .Produces<ProductCreationApiGroupResponse>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapGet("/providers/{providerRequestId}", GetProviderStatusByProviderRequestId)
            .WithName("GetProviderStatusByProviderRequestId")
            .WithOpenApi(operation =>
            {
                operation.Summary = "Get status by provider request ID";
                operation.Description = "Retrieves the status for a specific provider using its unique ProviderRequestId";
                
                var idParam = operation.Parameters.FirstOrDefault(p => p.Name == "providerRequestId");
                if (idParam != null) idParam.Description = "The unique tracking ID for the individual provider task.";
                
                return operation;
            })
            .Produces<ProductCreationApiResponse>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapGet("/{requestId}/realtime", GetProductCreationStatusRealtime)
            .WithName("GetProductCreationStatusRealtime")
            .WithOpenApi(operation =>
            {
                operation.Summary = "Get product creation status in real-time";
                operation.Description = "Returns a Server-Sent Events (SSE) stream for real-time status updates";
                
                var idParam = operation.Parameters.FirstOrDefault(p => p.Name == "requestId");
                if (idParam != null) idParam.Description = "The unique tracking ID assigned to the product creation batch.";
                
                return operation;
            })
            .Produces(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status401Unauthorized)
            .ProducesProblem(StatusCodes.Status404NotFound);

        return app;
    }

    private static async Task<IResult> CreateProductRequest(
        [FromBody] ProductCreationRequest request,
        ProductCreationService service,
        IIdGenerator idGenerator,
        ILoggerFactory loggerFactory,
        CancellationToken cancellationToken)
    {
        var logger = loggerFactory.CreateLogger("ProductCreationEndpoints");
        var requestId = idGenerator.NewId();
        
        logger.LogInformation(
            "[REQ:{requestId}][Api] Received product creation request: {@Request}", 
            requestId,
            request);

        var response = await service.SendProductCreationRequestAsync(request, requestId, cancellationToken);

        return Results.Created($"/api/v1/products/{requestId}", response);
    }

    private static async Task<IResult> GetProductCreationStatus(
        string requestId,
        ProductCreationService service,
        ILoggerFactory loggerFactory,
        CancellationToken cancellationToken)
    {
        var logger = loggerFactory.CreateLogger("ProductCreationEndpoints");
        
        // For logging, we prefer the base GUID if possible
        var logId = requestId.Split('.')[0];
        
        logger.LogInformation(
            "[REQ:{requestId}][Api] Checking status for product creation request REQ:{requestId}", 
            logId,
            requestId);

        var response = await service.GetProductCreationStatusAsync(requestId, cancellationToken);

        if (response == null || !response.ProviderRequests.Any())
        {
            return Results.NotFound(new ProblemDetails
            {
                Status = StatusCodes.Status404NotFound,
                Title = "Product creation message not found",
                Detail = $"No product creation message found with ID REQ:{requestId}"
            });
        }

        return Results.Ok(response);
    }

    private static async Task<IResult> GetProviderStatus(
        string requestId,
        string providerName,
        ProductCreationService service,
        ILoggerFactory loggerFactory,
        CancellationToken cancellationToken)
    {
        var logger = loggerFactory.CreateLogger("ProductCreationEndpoints");
        
        if (!Enum.TryParse<ProviderName>(providerName, true, out var provider))
        {
            return Results.BadRequest(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "Invalid provider name",
                Detail = $"The provider name '{providerName}' is not recognized."
            });
        }

        var response = await service.GetProviderStatusByRequestIdAndProviderNameAsync(requestId, provider, cancellationToken);
 
        if (response == null || !response.ProviderRequests.Any())
        {
            return Results.NotFound(new ProblemDetails
            {
                Status = StatusCodes.Status404NotFound,
                Title = "Provider status not found",
                Detail = $"No status found for provider '{providerName}' in request 'REQ:{requestId}'"
            });
        }

        return Results.Ok(response);
    }

    private static async Task<IResult> GetProviderStatusByProviderRequestId(
        string providerRequestId,
        ProductCreationService service,
        ILoggerFactory loggerFactory,
        CancellationToken cancellationToken)
    {
        var logger = loggerFactory.CreateLogger("ProductCreationEndpoints");
        
        var result = await service.GetProviderStatusByProviderRequestIdAsync(providerRequestId, cancellationToken);
        
        if (result == null)
        {
            return Results.NotFound(new ProblemDetails
            {
                Status = StatusCodes.Status404NotFound,
                Title = "Provider request not found",
                Detail = $"No provider request found with ID '{providerRequestId}'"
            });
        }

        return Results.Ok(result);
    }

    private static async Task GetProductCreationStatusRealtime(
        string requestId,
        HttpContext httpContext,
        CancellationToken cancellationToken)
    {
        httpContext.Response.Headers.Append("Content-Type", "text/event-stream");
        httpContext.Response.Headers.Append("Cache-Control", "no-cache");
        httpContext.Response.Headers.Append("Connection", "keep-alive");

        // Flush headers to start the SSE stream
        await httpContext.Response.Body.FlushAsync(cancellationToken);

        // Keep connection open - Do nothing else as requested
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                await Task.Delay(1000, cancellationToken);
            }
        }
        catch (OperationCanceledException)
        {
            // Connection closed by client
        }
    }
}
