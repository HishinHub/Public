using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using ContribFactoryService.Infrastructure.Authentication;

namespace ContribFactoryService.WebApi.Endpoints;

public static class AuthEndpoints
{
    public static void MapAuthEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/auth")
            .WithTags("Auth");

        group.MapPost("/token", (TokenRequest request, JwtTokenService tokenService) =>
        {
            var result = tokenService.IssueToken(request);

            if (result is null)
            {
                return Results.Problem(new ProblemDetails
                {
                    Status = StatusCodes.Status401Unauthorized,
                    Title = "Invalid client credentials",
                    Detail = "The client_id or client_secret is incorrect."
                });
            }

            return Results.Ok(result);
        })
        .WithName("GetAccessToken")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Obtain an OAuth2 access token";
            operation.Description = "Issues a JWT Bearer token using the client_credentials grant. Pass the returned token in the Authorization header as 'Bearer {token}'.";
            return operation;
        })
        .Produces<TokenResponse>(StatusCodes.Status200OK)
        .ProducesProblem(StatusCodes.Status401Unauthorized);
    }
}
