using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Text.Json;

namespace ContribFactoryService.WebApi.Endpoints;

/// <summary>
/// Health check endpoints
/// </summary>
public static class HealthCheckEndpoints
{
    public static IEndpointRouteBuilder MapHealthCheckEndpoints(this IEndpointRouteBuilder app)
    {
        // Liveness probe - checks if the application is running
        app.MapHealthChecks("/health/live", new HealthCheckOptions
        {
            Predicate = check => check.Tags.Contains("live"),
            ResponseWriter = WriteHealthCheckResponse
        })
        .WithTags("Health")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Liveness health check";
            operation.Description = "Indicates whether the application is running";
            return operation;
        })
        .AllowAnonymous();

        // Readiness probe - checks if the application is ready to accept requests
        app.MapHealthChecks("/health/ready", new HealthCheckOptions
        {
            Predicate = check => check.Tags.Contains("ready"),
            ResponseWriter = WriteHealthCheckResponse
        })
        .WithTags("Health")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Readiness health check";
            operation.Description = "Indicates whether the application is ready to process requests";
            return operation;
        })
        .AllowAnonymous();

        // Combined health check
        app.MapHealthChecks("/health", new HealthCheckOptions
        {
            ResponseWriter = WriteHealthCheckResponse
        })
        .WithTags("Health")
        .WithOpenApi(operation =>
        {
            operation.Summary = "Overall health check";
            operation.Description = "Comprehensive health check of all components";
            return operation;
        })
        .AllowAnonymous();

        return app;
    }

    private static Task WriteHealthCheckResponse(HttpContext context, HealthReport report)
    {
        context.Response.ContentType = "application/json";

        var result = JsonSerializer.Serialize(new
        {
            status = report.Status.ToString(),
            timestamp = DateTime.UtcNow,
            duration = report.TotalDuration,
            checks = report.Entries.Select(entry => new
            {
                name = entry.Key,
                status = entry.Value.Status.ToString(),
                description = entry.Value.Description,
                duration = entry.Value.Duration,
                exception = entry.Value.Exception?.Message,
                data = entry.Value.Data
            })
        }, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true
        });

        return context.Response.WriteAsync(result);
    }
}
