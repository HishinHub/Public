using Microsoft.Extensions.Logging;
using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Infrastructure.Sftp;

namespace ContribFactoryService.Infrastructure.Admin;

/// <summary>
/// Service for running administration tools and diagnostics
/// </summary>
public class AdminService
{
    private readonly ILogger<AdminService> _logger;
    private readonly IProductCreationTraceRepository _repository;
    private readonly ISftpProxy _sftpProxy;

    public AdminService(ILogger<AdminService> logger, IProductCreationTraceRepository repository, ISftpProxy sftpProxy)
    {
        _logger = logger;
        _repository = repository;
        _sftpProxy = sftpProxy;
    }


    /// <summary>
    /// Checks database connection and returns SQL version
    /// </summary>
    public async Task<string> GetDatabaseVersionAsync()
    {
        try
        {
            return await _repository.GetDatabaseVersionAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Database connection test failed via repository");
            throw;
        }
    }

    /// <summary>
    /// Tests connectivity to the Bloomberg SFTP server
    /// </summary>
    public Task<bool> TestBloombergSftpConnectionAsync()
    {
        try
        {
            var success = _sftpProxy.OpenSession();
            _logger.LogInformation("Bloomberg SFTP connection test {Result}", success ? "succeeded" : "failed");
            return Task.FromResult(success);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Bloomberg SFTP connection test threw an exception");
            throw;
        }
    }
}
