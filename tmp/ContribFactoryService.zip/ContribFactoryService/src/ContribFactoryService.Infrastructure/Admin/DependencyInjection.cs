using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryService.Infrastructure.Admin;

/// <summary>
/// Dependency injection configuration for Admin tools in Infrastructure
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddAdmin(this IServiceCollection services)
    {
        services.AddScoped<AdminService>();
        
        return services;
    }
}
