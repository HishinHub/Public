using System;
using System.IO;
using System.Linq;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using Renci.SshNet;
using Renci.SshNet.Common;
using Polly.Registry;
using ContribFactoryService.Domain;
using ContribFactoryService.Infrastructure.Authentication;


namespace ContribFactoryService.Infrastructure.Sftp
{
    public interface ISftpProxy : IDisposable
    {
        bool OpenSession();

        bool Upload(string localPath, string remotePath, bool remove = false);

        bool Download(string remotePath, string localPath, bool remove = false);
    }

    public class SftpProxy : ISftpProxy
    {
        private const string TrailingSlash = "/";
        private readonly ILogger<SftpProxy> _logger;
        private SftpClient? _sftpClient;
        private readonly SftpOptions _sftpOptions;
        private readonly ResiliencePipeline _resiliencePipeline;



        public SftpProxy(
            ILogger<SftpProxy> logger, 
            IOptions<SftpOptions> sftpOptions, 
            ResiliencePipelineProvider<string> pipelineProvider)
        {
            _logger = logger;
            _sftpOptions = sftpOptions.Value;
            _resiliencePipeline = pipelineProvider.GetPipeline(ApplicationContext.Resilience.RetryPipelineName);
        }


        public bool IsDisposed { get; private set; }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private SftpClient CreateClient()
        {
            var methods = new System.Collections.Generic.List<AuthenticationMethod>();
            if (!string.IsNullOrEmpty(_sftpOptions.Password))
            {
                methods.Add(new PasswordAuthenticationMethod(_sftpOptions.User, _sftpOptions.Password));
            }

            ConnectionInfo connectionInfo;

            if (!string.IsNullOrEmpty(_sftpOptions.Proxy.Host))
            {
                connectionInfo = new ConnectionInfo(
                    _sftpOptions.Host,
                    _sftpOptions.Port,
                    _sftpOptions.User,
                    ProxyTypes.Http,
                    _sftpOptions.Proxy.Host,
                    _sftpOptions.Proxy.Port,
                    _sftpOptions.Proxy.User,
                    _sftpOptions.Proxy.Password,
                    methods.ToArray());
            }



            else
            {
                connectionInfo = new ConnectionInfo(
                    _sftpOptions.Host,
                    _sftpOptions.Port,
                    _sftpOptions.User,
                    methods.ToArray());
            }

            var client = new SftpClient(connectionInfo);

            if (!string.IsNullOrEmpty(_sftpOptions.SshHostKey))
            {
                client.HostKeyReceived += (sender, e) =>
                {
                    if (string.Equals(e.FingerPrintMD5.Replace(":", ""), _sftpOptions.SshHostKey.Replace(":", ""), StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(e.FingerPrintSHA256, _sftpOptions.SshHostKey, StringComparison.OrdinalIgnoreCase))
                    {
                        e.CanTrust = true;
                    }
                    else
                    {
                        _logger.LogWarning("Host key fingerprint does not match");
                        e.CanTrust = false;
                    }
                };
            }
            else
            {
                client.HostKeyReceived += (sender, e) =>
                {
                    e.CanTrust = true;
                };
            }

            return client;
        }

        public virtual bool Download(string remotePath, string localPath, bool remove = false)
        {
            ArgumentNullException.ThrowIfNullOrEmpty(remotePath);
            ArgumentNullException.ThrowIfNullOrEmpty(localPath);

            try
            {

                return _resiliencePipeline.Execute(() =>
                {
                    _logger.LogInformation("Trying to download files from {RemotePath} to {LocalPath}", remotePath, localPath);

                    if (_sftpClient == null || !_sftpClient.IsConnected)
                    {
                        OpenSession();
                    }

                    if (_sftpClient!.Exists(remotePath) && _sftpClient.Get(remotePath).IsDirectory)
                    {
                        var files = _sftpClient.ListDirectory(remotePath).Where(f => f.IsRegularFile);
                        foreach (var file in files)
                        {
                            var singleLocalPath = Path.Combine(localPath, file.Name);
                            using (var stream = File.OpenWrite(singleLocalPath))
                            {
                                _sftpClient.DownloadFile(file.FullName, stream);
                            }

                            _logger.LogInformation("Download of file {FileName} succeeded", file.Name);

                            if (remove)
                            {
                                _sftpClient.DeleteFile(file.FullName);
                            }
                        }
                    }
                    else
                    {
                        using (var stream = File.OpenWrite(localPath))
                        {
                            _sftpClient.DownloadFile(remotePath, stream);
                        }

                        _logger.LogInformation("Download of file {RemotePath} succeeded", Path.GetFileName(remotePath));

                        if (remove)
                        {
                            _sftpClient.DeleteFile(remotePath);
                        }
                    }

                    return true;
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to download file from remote path {RemotePath} after retries", remotePath);
                return false;
            }
        }

        public virtual bool OpenSession()
        {
            if (_sftpClient == null)
            {
                _sftpClient = CreateClient();
            }

            bool sessionOpened = _sftpClient.IsConnected;

            if (!sessionOpened)
            {
                _logger.LogInformation("Opening sFTP session...");
                try
                {
                    _sftpClient.Connect();
                    sessionOpened = true;
                }
                catch (SshConnectionException sshEx)
                {
                    _logger.LogError(sshEx, "Connection has failed");
                    throw;
                }
                catch (SshAuthenticationException authEx)
                {
                    _logger.LogError(authEx, "Authentication has failed");
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Unknown exception occured while opening sFTP session");
                    throw;
                }
            }
            else
            {
                _logger.LogDebug("Sftp session already open");
            }

            return sessionOpened;
        }

        public virtual bool Upload(string localPath, string remotePath, bool remove = false)
        {
            ArgumentNullException.ThrowIfNullOrEmpty(localPath);
            ArgumentNullException.ThrowIfNullOrEmpty(remotePath);


            if (!remotePath.EndsWith(TrailingSlash))
            {
                remotePath += TrailingSlash;
            }

            string finalRemotePath = remotePath + Path.GetFileName(localPath);

            try
            {
                return _resiliencePipeline.Execute(() =>
                {
                    _logger.LogInformation("Trying to upload file {LocalPath} to {RemotePath}", localPath, finalRemotePath);

                    if (_sftpClient == null || !_sftpClient.IsConnected)
                    {
                        OpenSession();
                    }

                    using (var stream = File.OpenRead(localPath))
                    {
                        _sftpClient!.UploadFile(stream, finalRemotePath);
                    }

                    _logger.LogInformation("Upload of file {LocalFileName} succeeded", Path.GetFileName(localPath));

                    if (remove)
                    {
                        File.Delete(localPath);
                    }

                    return true;
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to upload file to remote path {RemotePath} after retries", finalRemotePath);
                return false;
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (IsDisposed)
            {
                return;
            }

            if (disposing && _sftpClient != null)
            {
                if (_sftpClient.IsConnected)
                {
                    _sftpClient.Disconnect();
                }
                _sftpClient.Dispose();
                _sftpClient = null;
            }

            IsDisposed = true;
        }

    }
}

