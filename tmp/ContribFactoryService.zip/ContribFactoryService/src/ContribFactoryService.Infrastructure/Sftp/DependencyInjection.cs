using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ContribFactoryService.Infrastructure.Authentication;

namespace ContribFactoryService.Infrastructure.Sftp;

public static class DependencyInjection
{
    public static IServiceCollection AddSftp(this IServiceCollection services, IConfiguration configuration, string sectionPath)
    {
        services.AddOptions<SftpOptions>()
            .BindConfiguration(sectionPath)
            .PostConfigure<IConfiguration>((options, config) =>
            {
                config.GetSection(ProxyOptions.SectionName).Bind(options.Proxy);
            })
            .ValidateDataAnnotations()
            .ValidateOnStart();
            
        services.AddSingleton<ISftpProxy, SftpProxy>();

        return services;
    }

}
