namespace ContribFactoryService.Infrastructure.ProviderSix.SixConnexor;

/// <summary>
/// Represents the message for Six provider
/// </summary>
public record ProviderSixRequest
{
    public string RequestId { get; init; } = string.Empty;
    public string ProviderRequestId { get; init; } = string.Empty;
    
    public string ProductCode { get; init; } = string.Empty;
    public string ProductName { get; init; } = string.Empty;
    public DateTime? MaturityDate { get; init; }
}
