using System.Net.Http.Json;
using ContribFactoryService.Domain.ProductCreation;

namespace ContribFactoryService.Infrastructure.ProviderSix.SixConnexor;

public interface ISixHttpRequestBuilder
{
    HttpRequestMessage AddAuthenticateContent(HttpRequestMessage request, string clientId, string clientSecret);
    HttpRequestMessage AddRequestHeaders(HttpRequestMessage request, string token);
    HttpRequestMessage AddCreateProductRequest(HttpRequestMessage request, ProviderSixRequest message);
}

public class SixHttpRequestBuilder : ISixHttpRequestBuilder
{
    public HttpRequestMessage AddAuthenticateContent(HttpRequestMessage request, string clientId, string clientSecret)
    {
        var authRequest = new
        {
            client_id = clientId,
            client_secret = clientSecret,
            grant_type = "client_credentials"
        };
        
        request.Content = JsonContent.Create(authRequest);
        return request;
    }

    public HttpRequestMessage AddRequestHeaders(HttpRequestMessage request, string token)
    {
        request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        return request;
    }

    public HttpRequestMessage AddCreateProductRequest(HttpRequestMessage request, ProviderSixRequest message)
    {
        request.Content = JsonContent.Create(message);
        return request;
    }
}
