using System.ComponentModel.DataAnnotations;

namespace ContribFactoryService.Infrastructure.ProviderSix.SixConnexor;

public class SixConnexorOptions
{
    public const string SectionName = "SixConnexor";

    [Required]
    public string ApiUrl { get; set; } = null!;

    [Required]
    public string AuthUrl { get; set; } = null!;

    [Required]
    public string ClientId { get; set; } = null!;

    [Required]
    public string ClientSecret { get; set; } = null!;

}
