using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ContribFactoryService.Infrastructure.AWS.S3;

/// <summary>
/// Interface for AWS S3 file operations
/// </summary>
public interface IAwsS3Service
{
    /// <summary>Uploads a file stream to S3 and returns the object key.</summary>
    Task<string> UploadAsync(string key, Stream content, string contentType = "application/octet-stream", CancellationToken cancellationToken = default);

    /// <summary>Downloads a file from S3 as a stream.</summary>
    Task<Stream> DownloadAsync(string key, CancellationToken cancellationToken = default);

    /// <summary>Checks whether the given key exists in the bucket.</summary>
    Task<bool> ExistsAsync(string key, CancellationToken cancellationToken = default);

    /// <summary>Deletes an object from S3.</summary>
    Task DeleteAsync(string key, CancellationToken cancellationToken = default);
}

/// <summary>
/// AWS S3 service for uploading and downloading files
/// </summary>
public class AwsS3Service : IAwsS3Service
{
    private readonly IAmazonS3 _s3Client;
    private readonly string _bucketName;
    private readonly ILogger<AwsS3Service> _logger;

    public AwsS3Service(IAmazonS3 s3Client, IOptions<AwsS3Options> options, ILogger<AwsS3Service> logger)
    {
        _s3Client = s3Client;
        _bucketName = options.Value.BucketName;
        _logger = logger;
    }

    /// <inheritdoc />
    public async Task<string> UploadAsync(string key, Stream content, string contentType = "application/octet-stream", CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Uploading file to S3. Bucket: {Bucket}, Key: {Key}", _bucketName, key);

        var request = new PutObjectRequest
        {
            BucketName = _bucketName,
            Key = key,
            InputStream = content,
            ContentType = contentType,
            AutoCloseStream = false
        };

        var response = await _s3Client.PutObjectAsync(request, cancellationToken);

        _logger.LogInformation("Successfully uploaded file to S3. Bucket: {Bucket}, Key: {Key}, ETag: {ETag}", _bucketName, key, response.ETag);

        return key;
    }

    /// <inheritdoc />
    public async Task<Stream> DownloadAsync(string key, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Downloading file from S3. Bucket: {Bucket}, Key: {Key}", _bucketName, key);

        var request = new GetObjectRequest
        {
            BucketName = _bucketName,
            Key = key
        };

        var response = await _s3Client.GetObjectAsync(request, cancellationToken);

        _logger.LogInformation("Successfully downloaded file from S3. Bucket: {Bucket}, Key: {Key}, ContentLength: {ContentLength}", _bucketName, key, response.ContentLength);

        // Copy to a MemoryStream so the caller doesn't need to manage the HTTP response lifetime
        var memoryStream = new MemoryStream();
        await response.ResponseStream.CopyToAsync(memoryStream, cancellationToken);
        memoryStream.Position = 0;

        return memoryStream;
    }

    /// <inheritdoc />
    public async Task<bool> ExistsAsync(string key, CancellationToken cancellationToken = default)
    {
        try
        {
            await _s3Client.GetObjectMetadataAsync(_bucketName, key, cancellationToken);
            return true;
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return false;
        }
    }

    /// <inheritdoc />
    public async Task DeleteAsync(string key, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Deleting file from S3. Bucket: {Bucket}, Key: {Key}", _bucketName, key);

        await _s3Client.DeleteObjectAsync(_bucketName, key, cancellationToken);

        _logger.LogInformation("Successfully deleted file from S3. Bucket: {Bucket}, Key: {Key}", _bucketName, key);
    }
}
