using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ContribFactoryService.Infrastructure.AWS.S3;

public static class DependencyInjection
{
    public static IServiceCollection AddAwsS3(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<AwsS3Options>()
            .Bind(configuration.GetSection(AwsS3Options.SectionName))
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddSingleton<IAmazonS3>(provider =>
        {
            var options = provider.GetRequiredService<IOptions<AwsS3Options>>().Value;
            var region = RegionEndpoint.GetBySystemName(options.Region);

            // Use explicit credentials if provided; otherwise fall back to the default credential chain
            // (environment variables, IAM role, ~/.aws/credentials, etc.)
            if (!string.IsNullOrWhiteSpace(options.AccessKeyId) && !string.IsNullOrWhiteSpace(options.SecretAccessKey))
            {
                var credentials = new BasicAWSCredentials(options.AccessKeyId, options.SecretAccessKey);
                return new AmazonS3Client(credentials, region);
            }

            return new AmazonS3Client(region);
        });

        services.AddScoped<IAwsS3Service, AwsS3Service>();

        return services;
    }
}
