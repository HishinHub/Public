namespace ContribFactoryService.Infrastructure.AWS.S3;

/// <summary>
/// Options for AWS S3 configuration
/// </summary>
public class AwsS3Options
{
    public const string SectionName = "Aws:S3";

    /// <summary>The AWS region (e.g. eu-west-1)</summary>
    public string Region { get; set; } = string.Empty;

    /// <summary>The S3 bucket name</summary>
    public string BucketName { get; set; } = string.Empty;

    /// <summary>Optional: AWS Access Key ID (leave empty to use IAM role / environment credentials)</summary>
    public string? AccessKeyId { get; set; }

    /// <summary>Optional: AWS Secret Access Key</summary>
    public string? SecretAccessKey { get; set; }
}
