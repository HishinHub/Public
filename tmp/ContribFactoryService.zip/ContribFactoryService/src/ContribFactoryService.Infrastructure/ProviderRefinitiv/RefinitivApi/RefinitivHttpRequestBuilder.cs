using System.Globalization;
using System.Text;
using System.Text.Json;
using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using Microsoft.Extensions.Options;

namespace ContribFactoryService.Infrastructure.ProviderRefinitiv.RefinitivApi
{
    public class RefinitivHttpRequestBuilder(IOptions<RefinitivApiOptions> options) : IRefinitivHttpRequestBuilder
    {
        public HttpRequestMessage AddAuthorization(HttpRequestMessage request, string username)
        {
            var encodedUsername = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:"));
            request.Headers.Add("Authorization", $"Basic {encodedUsername}");
            return request;
        }

        public HttpRequestMessage AddRequestHeaders(HttpRequestMessage request, string token)
        {
            request.Headers.Add("authorizationToken", token);
            request.Headers.Add("User-Agent", RefinitivContext.UserAgent);
            return request;
        }

        public HttpRequestMessage AddAuthenticateContent(HttpRequestMessage request, string username, string password)
        {
            request.Content = new StringContent(
                $"grant_type=password&username={username}&password={password}&takeExclusiveSignOnControl={true}",
                Encoding.UTF8,
                "application/x-www-form-urlencoded");
            return request;
        }

        public HttpRequestMessage AddSearchRefinitivRequest(HttpRequestMessage request, int jobId)
        {
            var ricRequest = new GetRicStatusRequest();
            ricRequest.MsgType = RefinitivContext.RefinitivRequest.MsgType;
            ricRequest.Action = RefinitivContext.RefinitivRequest.ActionSearch;
            ricRequest.Csln = options.Value.Csln;
            ricRequest.ProfileName = options.Value.ProfileName;
            ricRequest.Uuid = options.Value.Uuid;
            ricRequest.JobId = jobId;

            var jsonData = JsonSerializer.Serialize(ricRequest);
            request.Content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            return request;
        }

        public HttpRequestMessage AddCreateRicRefinitivRequest(HttpRequestMessage request, string ric, SendRicCreationRequest message)
        {
            var ricRequest = new CreateRicRequest();
            ricRequest.MsgType = RefinitivContext.RefinitivRequest.MsgType;
            ricRequest.Action = RefinitivContext.RefinitivRequest.ActionAdd;
            ricRequest.Csln = options.Value.Csln;
            ricRequest.ProfileName = options.Value.ProfileName;
            ricRequest.Uuid = options.Value.Uuid;

            // Pre-Format
            var maturityDateDisplay = FormatMaturityDate(message.MaturityDate);
            var couponDisplay = FormatCoupon(message.Coupon);
            var shortDiplayName = FormatDisplayName(message.ProductName);

            var fids = new HashSet<Fid>()
            {
                new Fid { Id = RefinitivContext.Fids.DiplayName, Value = shortDiplayName },
                new Fid { Id = RefinitivContext.Fids.Currency, Value = message.Currency },
                new Fid { Id = RefinitivContext.Fids.MaturityDate, Value = maturityDateDisplay },
                new Fid { Id = RefinitivContext.Fids.OfficialCode, Value = message.ProductCode }
            };

            if (couponDisplay != null)
            {
                fids.Add(new Fid { Id = RefinitivContext.Fids.CouponRate, Value = couponDisplay });
            }

            ricRequest.Rics = new HashSet<Ric>
            {
                new Ric
                {
                    Name = ric,
                    Fids = fids
                }
            };

            var jsonData = JsonSerializer.Serialize(ricRequest);
            request.Content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            return request;
        }

        private static string FormatMaturityDate(DateTime? maturityDate)
        {
            return (maturityDate ?? DateTime.MaxValue).ToString(RefinitivContext.MaturityDateFormat, CultureInfo.InvariantCulture).ToUpperInvariant();
        }

        private static string FormatCoupon(double? insCoupon)
        {
            if (!insCoupon.HasValue || insCoupon < 0)
            {
                return null;
            }

            var couponDisplay = insCoupon.Value.ToString(RefinitivContext.CouponNumberFormat, CultureInfo.InvariantCulture);
            return couponDisplay;
        }

        private static string FormatDisplayName(string insLabel)
        {
            if (insLabel.Length <= RefinitivContext.DisplayNameMaxSize)
            {
                return insLabel;
            }

            var result = insLabel;
            foreach (var shortName in RefinitivContext.ShortDisplayNames)
            {
                var init = result;
                result = result.Replace(shortName.Key, shortName.Value);

                var isReplaceOccurred = init != result;
                if (isReplaceOccurred)
                {
                    break;
                }
            }

            return result.Length <= RefinitivContext.DisplayNameMaxSize ? result : result.Substring(0, RefinitivContext.DisplayNameMaxSize).Trim();
        }
    }

    public interface IRefinitivHttpRequestBuilder
    {
        HttpRequestMessage AddAuthorization(HttpRequestMessage request, string username);
        HttpRequestMessage AddRequestHeaders(HttpRequestMessage request, string token);
        HttpRequestMessage AddAuthenticateContent(HttpRequestMessage request, string username, string password);
        HttpRequestMessage AddSearchRefinitivRequest(HttpRequestMessage request, int jobId);
        HttpRequestMessage AddCreateRicRefinitivRequest(HttpRequestMessage request, string ric, SendRicCreationRequest message);
    }
}
