using ContribFactoryService.Infrastructure.Database;
using Microsoft.Extensions.Options;
using System.ComponentModel.DataAnnotations;

namespace ContribFactoryService.Infrastructure.ProviderRefinitiv.RefinitivApi
{
    public class RefinitivApiOptions
    {
        public const string SectionName = "RefinitivApi";

        [Required]
        public string Csln { get; set; } = null!;
        [Required]
        public string ProfileName { get; set; } = null!;
        [Required]
        public string Uuid { get; set; } = null!;

        [Required]
        public string AuthUrl { get; set; } = null!;
        [Required]
        public string ApiUrl { get; set; } = null!;
        [Required]
        public string Username { get; set; } = null!;
        [Required]
        public string Password { get; set; } = null!;
        [Required]
        public string RicExtension { get; set; } = null!;

        [Required]
        [ValidateObjectMembers]
        public ProxyOptions Proxy { get; set; } = new();
        [Required]
        [ValidateObjectMembers]
        public SvcAccountOptions SvcAccount { get; set; } = new();
    }
}
