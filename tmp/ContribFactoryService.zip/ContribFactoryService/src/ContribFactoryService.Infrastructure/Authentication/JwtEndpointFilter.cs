using Microsoft.AspNetCore.Http;

namespace ContribFactoryService.Infrastructure.Authentication;

/// <summary>
/// Endpoint filter that enforces JWT Bearer authentication on minimal API endpoints.
/// </summary>
public class JwtEndpointFilter : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var user = context.HttpContext.User;

        if (user.Identity is null || !user.Identity.IsAuthenticated)
        {
            return Results.Problem(new Microsoft.AspNetCore.Mvc.ProblemDetails
            {
                Status = StatusCodes.Status401Unauthorized,
                Title = "Unauthorized",
                Detail = "A valid Bearer token is required.",
                Instance = context.HttpContext.Request.Path
            });
        }

        return await next(context);
    }
}
