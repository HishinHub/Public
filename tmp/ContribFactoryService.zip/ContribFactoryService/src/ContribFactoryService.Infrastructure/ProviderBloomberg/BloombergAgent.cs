using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Infrastructure.Identifiers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ContribFactoryService.Infrastructure.ProviderBloomberg.BloombergSpf;

namespace ContribFactoryService.Infrastructure.ProviderBloomberg;

/// <summary>
/// Bloomberg-specific product creation agent
/// </summary>
public class BloombergAgent : IProviderAgent
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<BloombergAgent> _logger;
    private readonly IIdGenerator _idGenerator;
    private readonly IBloombergMapper _bloombergMapper;
    private readonly IBloombergSpfClient _bloombergSpfClient;

    public BloombergAgent(
        IConfiguration configuration,
        ILogger<BloombergAgent> logger,
        IIdGenerator idGenerator,
        IBloombergMapper bloombergMapper,
        IBloombergSpfClient bloombergSpfClient)
    {
        _configuration = configuration;
        _logger = logger;
        _idGenerator = idGenerator;
        _bloombergMapper = bloombergMapper;
        _bloombergSpfClient = bloombergSpfClient;
    }

    public ProviderName Provider => ProviderName.Bloomberg;

    public async Task<SendRequestResponse> SendRequestAsync(
        ProductPayload payload,
        RunContext runContext,
        CancellationToken cancellationToken = default)
    {
        var bloombergRequest = _bloombergMapper.ToCreateProductRequest(payload, runContext.RequestId, runContext.ProviderRequestId);
        
        if (string.IsNullOrEmpty(bloombergRequest.ProductCode))
        {
            return new SendRequestResponse 
            { 
                Success = false, 
                ErrorMessage = "No Bloomberg payload found in request" 
            };
        }

        _logger.LogInformation(
            "[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Bloomberg] Bloomberg: Sending product {ProductCode}", 
            runContext.RequestId,
            runContext.ProviderRequestId,
            bloombergRequest.ProductCode);
            
         _logger.LogInformation(
            "[REQ:{RequestId}][ProdCrea/Bloomberg] Bloomberg Payload: Name={ProductName}, MaturityDate={MaturityDate}", 
            runContext.RequestId,
            bloombergRequest.ProductName,
            bloombergRequest.MaturityDate);

        // Real Bloomberg-specific logic
        var result = await _bloombergSpfClient.CreateProductAsync(bloombergRequest, runContext, cancellationToken);
        
        return _bloombergMapper.ToProviderResponse(result);
    }

    public async Task<GetStatusResponse> GetStatusAsync(
        RunContext runContext,
        string productCode,
        string? externalRequestId,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[RUN:{RunId}/REQ:{RequestId}][ProdCrea/Bloomberg] Bloomberg: Getting status for {ProductCode} (ExternalRef: {ExternalRequestId})", runContext.RunId, runContext.RequestId, productCode, externalRequestId);
        
        // Empty for now as requested
        return await Task.FromResult(new GetStatusResponse { Success = true, ExternalProductCode = productCode });
    }
}
