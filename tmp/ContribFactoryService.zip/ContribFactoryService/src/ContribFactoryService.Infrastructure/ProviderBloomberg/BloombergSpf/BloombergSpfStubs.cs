using System.Collections.Generic;
using System.Xml.Linq;

namespace ContribFactoryService.Infrastructure.ProviderBloomberg.BloombergSpf
{
    public interface IEspmServiceProxy
    {
        string GetDocumentTypeBySpIdToString(string infinitySpId, string investorTermSheetName);
    }

    public interface IRequestWriter
    {
        void SaveRequestAttachments(Ctborder order, CreateProductRequest instrument, List<Termsheet> termSheets);
        void CreateRequestPackage(Ctborder order, CreateProductRequest instrument, List<Termsheet> termSheets);
        bool SaveRequestFile(Ctborder order, CreateProductRequest instrument, XElement requestDocument);
    }

    public interface IInstrumentServiceProxy { }
    
    public class StubService : IInstrumentServiceProxy, IEspmServiceProxy, IRequestWriter
    {
        public string GetDocumentTypeBySpIdToString(string infinitySpId, string investorTermSheetName) => string.Empty;
        public void SaveRequestAttachments(Ctborder order, CreateProductRequest instrument, List<Termsheet> termSheets) { }
        public void CreateRequestPackage(Ctborder order, CreateProductRequest instrument, List<Termsheet> termSheets) { }
        public bool SaveRequestFile(Ctborder order, CreateProductRequest instrument, XElement requestDocument) => true;
    }

    public class ProductCreatorDbContext
    {
        public List<Ctborder> Ctborders { get; set; } = new();
        public List<CtborderFile> CtborderFiles { get; set; } = new();
        public int SaveChanges() => 1;
    }

    public class CtborderFile
    {
        public int OrderId { get; set; }
        public string FileName { get; set; } = string.Empty;
        public int FileTypeId { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string UpdatedBy { get; set; } = string.Empty;
    }

}
