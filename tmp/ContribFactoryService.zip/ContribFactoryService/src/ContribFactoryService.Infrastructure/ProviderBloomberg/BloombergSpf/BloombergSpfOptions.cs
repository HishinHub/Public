using System.ComponentModel.DataAnnotations;

namespace ContribFactoryService.Infrastructure.ProviderBloomberg.BloombergSpf;

public class BloombergSpfOptions
{
    public const string SectionName = "BloombergSpf";

    public ContribFactoryService.Infrastructure.Sftp.SftpOptions Sftp { get; set; } = new();
}
