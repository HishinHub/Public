using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Microsoft.Extensions.Logging;
using ContribFactoryService.Infrastructure.Sftp;

namespace ContribFactoryService.Infrastructure.ProviderBloomberg.BloombergSpf
{
    public class BloombergSpfBuilder
    {
        private readonly ILogger<BloombergSpfBuilder> _logger;
        protected readonly ProductCreatorDbContext _dbContext;
        protected readonly IInstrumentServiceProxy _instrumentServiceProxy;
        protected readonly IEspmServiceProxy _espmServiceProxy;
        protected readonly IRequestWriter _requestWriter;
        private readonly ISftpProxy _sftpProxy;
        private readonly TimeProvider _timeProvider;

        public BloombergSpfBuilder(
            ILogger<BloombergSpfBuilder> logger,
            ProductCreatorDbContext dbContext,
            IInstrumentServiceProxy instrumentServiceProxy, 
            IEspmServiceProxy espmServiceProxy, 
            IRequestWriter requestWriter,
            ISftpProxy sftpProxy,
            TimeProvider timeProvider)
        {
            _logger = logger;
            _dbContext = dbContext;
            _instrumentServiceProxy = instrumentServiceProxy;
            _espmServiceProxy = espmServiceProxy;
            _requestWriter = requestWriter;
            _sftpProxy = sftpProxy;
            _timeProvider = timeProvider;
        }

        public bool CreateBloombergReference(Ctborder ctbOrder, CreateProductRequest request)
        {
            _logger.LogInformation("Create CtbOrder.BloombergReference for OrderId={OrderId}", ctbOrder.OrderId);
            ctbOrder.BloombergReference = this.CreateBloombergReference(ctbOrder.OrderId, BloombergSpfContext.SftpConfig.SenderCompanyBloombergId);
            
            ctbOrder.Instrument = request;

            _dbContext.Ctborders.Add(ctbOrder);
            int resultUpdateBloomberg = _dbContext.SaveChanges();

            return resultUpdateBloomberg > 0;
        }

        public string CreateBloombergReference(int orderId, string companyId)
        {
            object[] bloombergRefElements =
            {
                companyId,
                orderId.ToString(),
                _timeProvider.GetLocalNow().ToString(BloombergSpfContext.BloombergReferenceDateFormat)
            };

            return string.Join("_", bloombergRefElements);
        }

        public BloombergRequestStatus SendSpfRequest(SpfRequest request, Ctborder order)
        {
            _logger.LogInformation("Send SPF Request");

            BloombergRequestStatus requestStatus = new BloombergRequestStatus()
            {
                IsSent = false,
                BloombergRef = order.BloombergReference,
                IsinCode = order.Instrument.InsCodeIsin
            };

            _logger.LogInformation("Creating Xml RequestDocument File");
            if (RegisterFile(request, order))
            {
                _logger.LogInformation("Creating Attached PDF Termsheets Files");
                List<Termsheet> termSheets = request.TermSheets.Select(x => new Termsheet { Name = x.Name, Content = x.Content }).ToList();
                _requestWriter.SaveRequestAttachments(order, order.Instrument, termSheets);
                _logger.LogInformation("Creating Zip with RequestDocument & Termsheets");
                _requestWriter.CreateRequestPackage(order, order.Instrument, termSheets);

                _logger.LogInformation("Sending ZIP by SFTP");
                if (UploadRequest(order.BloombergReference, order.Instrument.InsCodeIsin))
                {
                    _logger.LogInformation("Order for Instrument.IsinCode({IsinCode}) has been sent to Bloomberg.", order.Instrument.InsCodeIsin);
                    requestStatus.IsSent = true;
                }
                else
                {
                    _logger.LogError("Order for Instrument.IsinCode({IsinCode}) failed to be sent to Bloomberg", order.Instrument.InsCodeIsin);
                    requestStatus.IsSent = false;
                }
            }
            else
            {
                _logger.LogWarning("Bloomberg request for Instrument.IsinCode({IsinCode}) was not saved to directory", order.Instrument.InsCodeIsin);
                requestStatus.IsSent = false;
            }

            return requestStatus;
        }

        public bool RegisterFile(SpfRequest request, Ctborder order)
        {
            bool success = _requestWriter.SaveRequestFile(order, order.Instrument, request.RequestDocument);
            if (success)
            {
                CtborderFile requestOrderFile = new CtborderFile()
                {
                    OrderId = order.OrderId,
                    FileName = order.BloombergReference + BloombergSpfContext.RequestFileExtension,
                    FileTypeId = (int)OrderFileTypeEnum.Request,
                    UpdatedOn = _timeProvider.GetLocalNow().DateTime,
                    UpdatedBy = Environment.UserName
                };
                _dbContext.CtborderFiles.Add(requestOrderFile);
                _dbContext.SaveChanges();
                return true;
            }
            return false;
        }

        public bool UploadRequest(string bloombergReference, string isin)
        {
            _logger.LogInformation("Starting to upload request package for Bloomberg reference: {BloombergReference}", bloombergReference);
            bool packageUploaded = false;

            if (_sftpProxy.OpenSession())
            {
                string packageDir = BloombergSpfContext.SftpConfig.LocalZipDir.Replace("[ISIN_CODE]", isin);
                string packageName = bloombergReference + BloombergSpfContext.RequestPackageExtension;

                string localPath = Path.Combine(packageDir, packageName);
                string remotePath = BloombergSpfContext.SftpConfig.FtpReqDir;

                _logger.LogInformation("Local path: {LocalPath}", localPath);
                _logger.LogInformation("Remote path: {RemotePath}", remotePath);
                _logger.LogInformation("Package path: {PackagePath}", localPath);

                try
                {
                    packageUploaded = _sftpProxy.Upload(localPath, remotePath);

                    if (packageUploaded)
                    {
                        _logger.LogInformation("## UPLOAD SFTP SUCCEED for Order(BloombergReference={BloombergReference})", bloombergReference);
                    }
                    else
                    {
                        _logger.LogInformation("## UPLOAD SFTP FAILED for Order(BloombergReference={BloombergReference})", bloombergReference);
                    }
                }
                catch (System.Exception ex)
                {
                    _logger.LogError(ex, "Unexpected Exception while Uploading");
                    _logger.LogInformation("## UPLOAD SFTP with Exception for Order(BloombergReference={BloombergReference})", bloombergReference);
                }
            }

            return packageUploaded;
        }

        public XDocument? ExtractRequestDocumentTemplate(string spId, string termsheetName)
        {
            string requestDocument = this.GetRequestDocumentTemplate(spId, termsheetName);

            if (string.IsNullOrEmpty(requestDocument))
            {
                _logger.LogWarning("Returned document from ESPM for instrument {SpId} was null", spId);
                return null;
            }

            _logger.LogInformation("Analysing RequestDocument Format");
            XDocument xmlRequest = XDocument.Parse(requestDocument);

            return xmlRequest;
        }

        public string GetRequestDocumentTemplate(string infinitySpId, string investorTermSheetName)
        {
            string requestDocument = string.Empty;

            try
            {
                _logger.LogDebug("Downloading request document from ESPM Web service for instrument {InfinitySpId}", infinitySpId);
                requestDocument = _espmServiceProxy.GetDocumentTypeBySpIdToString(infinitySpId, investorTermSheetName);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "An unknown exception occured while trying to download request document from ESPM Web Service");
            }

            return requestDocument;
        }

        public string GetInvestorTermSheetName(ICollection<Termsheet> termsheets)
        {
            string investorTermSheetName = string.Empty;

            if (termsheets.Count == 1)
            {
                investorTermSheetName = termsheets.First().Name;
                _logger.LogInformation("Identify InvestorTermSheet with termsheetName={TermsheetName}", investorTermSheetName);
            }

            return investorTermSheetName;
        }

        public List<Termsheet> GetTermSheets(CreateProductRequest request) => new();

        public Ctborder? InitializeCtbOrder(CreateProductRequest request, int provider, int type, int status) => new Ctborder 
        { 
            OrderId = 1, 
            Instrument = request 
        };

        public enum OrderProviderEnum { Bloomberg = 1 }
        public enum OrderTypeEnum { Sftp = 2 }
        public enum OrderStatusEnum { Failed = 0 }
        public enum OrderFileTypeEnum { Request = 1 }
    }
}
