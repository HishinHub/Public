using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.Extensions.Logging;
using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Infrastructure.Sftp;

namespace ContribFactoryService.Infrastructure.ProviderBloomberg.BloombergSpf
{
    public class BloombergSpfClient : IBloombergSpfClient
    {
        private readonly ILogger<BloombergSpfClient> _logger;
        private readonly BloombergSpfBuilder _builder;

        public BloombergSpfClient(
            ILogger<BloombergSpfClient> logger,
            BloombergSpfBuilder builder)
        {
            _logger = logger;
            _builder = builder;
        }

        public Task<BloombergRequestStatus> CreateProductAsync(CreateProductRequest request, RunContext runContext, CancellationToken cancellationToken = default)
        {
            try
            {
                _logger.LogInformation("Start Sending Product for Instrument(Id={InsId}, Isin={InsCodeIsin}, PdId={InfinityPdId})", 
                    request.InsId, request.InsCodeIsin, request.InfinityPdId);

                // Get Investor TermSheet
                var termsheets = _builder.GetTermSheets(request);

                if (!termsheets.Any())
                {
                    return Task.FromResult(new BloombergRequestStatus
                    {
                        Success = false,
                        Message = $"SKIP SENDING REQUEST - Investor Termsheet NOT FOUND for Instrument {request.InfinityPdId}"
                    });
                }

                if (termsheets.First().Content == null || termsheets.First().Content.Length == 0)
                {
                    return Task.FromResult(new BloombergRequestStatus
                    {
                        Success = false,
                        Message = $"SKIP SENDING REQUEST - Investor Termsheet is found but EMPTY for Instrument {request.InfinityPdId}"
                    });
                }

                // Get RequestDocument Template
                string investorTermSheetName = _builder.GetInvestorTermSheetName(termsheets.ToList());
                XDocument? xmlRequest = _builder.ExtractRequestDocumentTemplate(request.InfinityPdId, investorTermSheetName);
                if (xmlRequest?.Root is null)
                {
                    return Task.FromResult(new BloombergRequestStatus
                    {
                        Success = false,
                        Message = "## SKIP SENDING REQUEST - Cannot get RequestDocument Template from ESPM."
                    });
                }

                var ctbOrder = _builder.InitializeCtbOrder(
                    request,
                    (int)BloombergSpfBuilder.OrderProviderEnum.Bloomberg,
                    (int)BloombergSpfBuilder.OrderTypeEnum.Sftp,
                    (int)BloombergSpfBuilder.OrderStatusEnum.Failed);
                
                if (ctbOrder is null)
                {
                    return Task.FromResult(new BloombergRequestStatus
                    {
                        Success = false,
                        Message = "Duplicated CtbOrder"
                    });
                }

                // Create External Reference
                bool bloombergRefCreated = _builder.CreateBloombergReference(ctbOrder, request);
                if (!bloombergRefCreated)
                {
                    return Task.FromResult(new BloombergRequestStatus
                    {
                        Success = false,
                        Message = "Failed Creating External Reference for Bloomberg"
                    });
                }
                _logger.LogInformation("BloombergReference Created ({BloombergReference})", ctbOrder.BloombergReference);

                // Create SpfRequest
                SpfRequest spfRequest = new SpfRequest()
                {
                    Instrument = ctbOrder.Instrument,
                    RequestDocument = xmlRequest.Root,
                    TermSheets = termsheets.ToList()
                };

                var bloombergResponse = _builder.SendSpfRequest(spfRequest, ctbOrder);

                return Task.FromResult(new BloombergRequestStatus
                {
                    Success = bloombergResponse.IsSent,
                    IsSent = bloombergResponse.IsSent,
                    BloombergRef = ctbOrder.BloombergReference ?? string.Empty,
                    IsinCode = ctbOrder.Instrument?.InsCodeIsin ?? string.Empty,
                    Message = bloombergResponse.IsSent ? null : "Send SPF Failed.",
                    BloombergId = ctbOrder.BloombergReference
                });
            }
            catch (System.Exception ex)
            {
                string msg = $"Failed sending request for ProductCode={request.ProductCode}";
                _logger.LogError(ex, msg);
                return Task.FromResult(new BloombergRequestStatus
                {
                    Success = false,
                    Message = msg
                });
            }
        }
    }
}
