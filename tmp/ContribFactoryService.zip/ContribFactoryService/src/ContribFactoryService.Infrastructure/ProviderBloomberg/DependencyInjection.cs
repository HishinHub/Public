using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Infrastructure.ProviderBloomberg.BloombergSpf;

namespace ContribFactoryService.Infrastructure.ProviderBloomberg;

public static class DependencyInjection
{
    public static IServiceCollection AddBloomberg(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddBloombergSpf(configuration);

        services.AddSingleton<IBloombergMapper, BloombergMapper>();
        services.AddScoped<IProviderAgent, BloombergAgent>();

        return services;
    }
}
