using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Infrastructure.ProviderBloomberg.BloombergSpf;

namespace ContribFactoryService.Infrastructure.ProviderBloomberg;

/// <summary>
/// Interface for Bloomberg-specific request and response mapping
/// </summary>
public interface IBloombergMapper
{
    /// <summary>
    /// Converts a ProductPayload to a CreateProductRequest
    /// </summary>
    CreateProductRequest ToCreateProductRequest(ProductPayload payload, string requestId, string providerRequestId);

    /// <summary>
    /// Converts a BloombergRequestStatus to a RefinitivSendRequestResponse
    /// </summary>
    SendRequestResponse ToProviderResponse(BloombergRequestStatus status);
}

/// <summary>
/// Mapper for converting a ProductPayload to a CreateProductRequest
/// </summary>
public class BloombergMapper : IBloombergMapper
{
    /// <summary>
    /// Converts a ProductPayload to a CreateProductRequest
    /// </summary>
    /// <param name="payload">The product payload for this provider</param>
    /// <param name="requestId">The request ID</param>
    /// <param name="providerRequestId">The provider request ID</param>
    /// <returns>A CreateProductRequest containing the mapped fields</returns>
    public CreateProductRequest ToCreateProductRequest(ProductPayload payload, string requestId, string providerRequestId)
    {
        return new CreateProductRequest
        {
            RequestId = requestId,
            ProviderRequestId = providerRequestId,
            
            ProductCode = payload.ProductCode,
            ProductName = payload.ProductName,
            MaturityDate = payload.MaturityDate,

            InsId = payload.InsId ?? string.Empty,
            InsCodeIsin = payload.IsinCode ?? payload.ProductCode, 
            InfinityPdId = payload.InfinitySpId ?? string.Empty
        };
    }

    /// <summary>
    /// Converts a BloombergRequestStatus to a RefinitivSendRequestResponse
    /// </summary>
    /// <param name="status">The bloomberg request status</param>
    /// <returns>A RefinitivSendRequestResponse</returns>
    public SendRequestResponse ToProviderResponse(BloombergRequestStatus status)
    {
        return new SendRequestResponse
        {
            Success = status.Success,
            ExternalRequestId = status.BloombergId,
            ExternalProductCode = status.BloombergId,
            ErrorMessage = status.Message
        };
    }
}
