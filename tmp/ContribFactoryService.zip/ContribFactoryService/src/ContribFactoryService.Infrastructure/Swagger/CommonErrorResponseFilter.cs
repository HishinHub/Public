using Microsoft.AspNetCore.Http;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace ContribFactoryService.Infrastructure.Swagger;

/// <summary>
/// A Swagger operation filter that adds common error responses (like 401, 500) to all endpoints.
/// </summary>
public class CommonErrorResponseFilter : IOperationFilter
{
    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        // Check if the endpoint allows anonymous access (i.e. no API key required)
        var allowAnonymous = context.ApiDescription.ActionDescriptor.EndpointMetadata
            .Any(m => m.GetType().Name == "AllowAnonymousAttribute" || m is Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute);

        // 401 Unauthorized - Added to all endpoints unless they allow anonymous access
        if (!allowAnonymous && !operation.Responses.ContainsKey("401"))
        {
            operation.Responses.Add("401", new OpenApiResponse
            {
                Description = "Unauthorized - The request was not authorized. This occurs when the required 'X-API-KEY' header is either missing, empty, or contains an invalid key. Access to this resource is restricted to authorized clients only.",
                Content = new Dictionary<string, OpenApiMediaType>
                {
                    ["application/problem+json"] = new OpenApiMediaType
                    {
                        Schema = context.SchemaGenerator.GenerateSchema(typeof(Microsoft.AspNetCore.Mvc.ProblemDetails), context.SchemaRepository)
                    }
                }
            });
        }

        // 400 Bad Request - Malformed syntax or client error
        if (!operation.Responses.ContainsKey("400"))
        {
            operation.Responses.Add("400", new OpenApiResponse
            {
                Description = "Bad Request - The request could not be understood by the server due to malformed syntax. Ensure the JSON payload and URL parameters follow the expected structure.",
                Content = new Dictionary<string, OpenApiMediaType>
                {
                    ["application/problem+json"] = new OpenApiMediaType
                    {
                        Schema = context.SchemaGenerator.GenerateSchema(typeof(Microsoft.AspNetCore.Mvc.ProblemDetails), context.SchemaRepository)
                    }
                }
            });
        }
        else
        {
            var response = operation.Responses["400"];
            if (string.IsNullOrEmpty(response.Description))
            {
                response.Description = "Bad Request - The request could not be understood by the server due to malformed syntax. Ensure the JSON payload and URL parameters follow the expected structure.";
            }
            EnsureProblemContent(response, context);
        }

        // 422 Unprocessable Entity - Semantic or validation errors
        if (!operation.Responses.ContainsKey("422"))
        {
            operation.Responses.Add("422", new OpenApiResponse
            {
                Description = "Unprocessable Entity - The request was well-formed but was unable to be followed due to semantic errors. This usually indicates validation failures where the data is syntactically correct but fails business logic or referential checks.",
                Content = new Dictionary<string, OpenApiMediaType>
                {
                    ["application/problem+json"] = new OpenApiMediaType
                    {
                        Schema = context.SchemaGenerator.GenerateSchema(typeof(Microsoft.AspNetCore.Mvc.ProblemDetails), context.SchemaRepository)
                    }
                }
            });
        }
        else
        {
            EnsureProblemContent(operation.Responses["422"], context);
        }

        // 404 Not Found - Missing resources
        if (operation.Responses.ContainsKey("404"))
        {
            var response = operation.Responses["404"];
            if (string.IsNullOrEmpty(response.Description))
            {
                response.Description = "Not Found - The requested resource could not be found. This happens if the unique identifier provided (e.g. RequestId or ProviderRequestId) does not exist in the system.";
            }
            EnsureProblemContent(response, context);
        }

        // 500 Internal Server Error - Unexpected server errors
        if (!operation.Responses.ContainsKey("500"))
        {
            operation.Responses.Add("500", new OpenApiResponse
            {
                Description = "Internal Server Error - An unexpected technical error occurred on the server while processing the request. This might be due to database connectivity issues or unexpected exceptions.",
                Content = new Dictionary<string, OpenApiMediaType>
                {
                    ["application/problem+json"] = new OpenApiMediaType
                    {
                        Schema = context.SchemaGenerator.GenerateSchema(typeof(Microsoft.AspNetCore.Mvc.ProblemDetails), context.SchemaRepository)
                    }
                }
            });
        }
        else
        {
            EnsureProblemContent(operation.Responses["500"], context);
        }
    }

    private void EnsureProblemContent(OpenApiResponse response, OperationFilterContext context)
    {
        // Remove standard "application/json" if it contains ProblemDetails results, as RFC 9457 requires "application/problem+json"
        if (response.Content.ContainsKey("application/json"))
        {
            response.Content.Remove("application/json");
        }

        if (!response.Content.ContainsKey("application/problem+json"))
        {
            response.Content["application/problem+json"] = new OpenApiMediaType
            {
                Schema = context.SchemaGenerator.GenerateSchema(typeof(Microsoft.AspNetCore.Mvc.ProblemDetails), context.SchemaRepository)
            };
        }
    }
}
