using System.Threading.Channels;
using System.Runtime.Serialization;
using ContribFactoryService.Application.Interfaces;
using Microsoft.Extensions.Logging;

namespace ContribFactoryService.Infrastructure.Messaging;

/// <summary>
/// Generic in-memory message queue implementation using System.Threading.Channels
/// </summary>
/// <typeparam name="T">The type of message</typeparam>
public class MessageQueue<T> : IMessageQueueService<T> where T : ISerializable
{
    private readonly Channel<T> _channel;
    private readonly ILogger<MessageQueue<T>> _logger;

    public MessageQueue(ILogger<MessageQueue<T>> logger)
    {
        _logger = logger;
        // Creating an unbounded channel for messages
        _channel = Channel.CreateUnbounded<T>(new UnboundedChannelOptions
        {
            SingleReader = true, // Optimization for a single consumer background worker
            SingleWriter = false // Allows multiple producers (API endpoints)
        });
    }

    /// <inheritdoc />
    public async Task<string> SendMessageAsync(T message, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Sending message of type {MessageType} to the queue: {@MessageContent}", typeof(T).Name, message);
        await _channel.Writer.WriteAsync(message, cancellationToken);
        
        var id = Guid.NewGuid().ToString();
        _logger.LogDebug("Message queued with ID {MessageId}.", id);
        return id;
    }

    /// <inheritdoc />
    public async Task<T> ReadMessageAsync(CancellationToken cancellationToken = default)
    {
        var message = await _channel.Reader.ReadAsync(cancellationToken);
        _logger.LogInformation("Read message of type {MessageType} from the queue: {@MessageContent}", typeof(T).Name, message);
        return message;
    }
}
