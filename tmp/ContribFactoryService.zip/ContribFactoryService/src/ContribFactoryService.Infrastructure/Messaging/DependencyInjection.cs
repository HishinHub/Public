using ContribFactoryService.Application.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryService.Infrastructure.Messaging;

public static class DependencyInjection
{
    public static IServiceCollection AddMessaging(this IServiceCollection services)
    {
        // Singleton is essential because it holds the in-memory channel
        services.AddSingleton(typeof(IMessageQueueService<>), typeof(MessageQueue<>));
        
        return services;
    }
}
