using System.ComponentModel.DataAnnotations;

namespace ContribFactoryService.Infrastructure.Database;

public class ProxyOptions
{
    public const string SectionName = "Authentication:Proxy";
    [Required]
    public string Host { get; set; } = null!;
    [Required]
    public int Port { get; set; }
}

public class SvcAccountOptions
{
    public const string SectionName = "Authentication:SvcAccount";
    [Required]
    public string Username { get; set; } = null!;
    [Required]
    public string Password { get; set; } = null!;
}
