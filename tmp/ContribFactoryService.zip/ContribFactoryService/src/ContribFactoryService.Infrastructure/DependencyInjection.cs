using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Infrastructure.Database;
using ContribFactoryService.Infrastructure.ProviderBloomberg;
using ContribFactoryService.Infrastructure.ProviderRefinitiv;
using ContribFactoryService.Infrastructure.ProviderRefinitiv.RefinitivApi;
using ContribFactoryService.Infrastructure.Messaging;
using ContribFactoryService.Infrastructure.ProviderSix;
using ContribFactoryService.Infrastructure.Repositories;
using ContribFactoryService.Infrastructure.Identifiers;
using ContribFactoryService.Infrastructure.Admin;
using ContribFactoryService.Infrastructure.Authentication;
using ContribFactoryService.Infrastructure.Sftp;
using ContribFactoryService.Infrastructure.Resilience;
using ContribFactoryService.Infrastructure.AWS.S3;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryService.Infrastructure;

/// <summary>
/// Dependency injection configuration for Infrastructure layer
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services, 
        IConfiguration configuration)
    {
        services.AddSingleton(TimeProvider.System);
        services.AddIdentifiers();
        
        // Database
        services.AddDbContext<AppDbContext>(options =>
            // options.UseInMemoryDatabase("ProductCreationDb"));
            options.UseSqlServer(
                configuration.GetConnectionString("ProductCreation"),
                sqlOptions => sqlOptions.EnableRetryOnFailure()));

        // Repositories
        services.AddScoped<IProductCreationTraceRepository, ProductCreationTraceRepository>();

        // Provider Services
        services.AddRefinitiv(configuration);
        services.AddSixConnexor(configuration);
        services.AddBloomberg(configuration);

        // Messaging (Channel-based queue + BackgroundWorker)
        services.AddMessaging();

        // Admin
        services.AddAdmin();

        // Authentication
        services.AddJwtAuthentication(configuration);

        // Resilience
        services.AddResilience(configuration);
 
        // AWS
        services.AddAwsS3(configuration);


        return services;
    }
}
