using ContribFactoryService.Application.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryService.Infrastructure.Identifiers;

public static class DependencyInjection
{
    public static IServiceCollection AddIdentifiers(this IServiceCollection services)
    {
        // Register Guid as the default IIdGenerator
        services.AddSingleton<IIdGenerator, GuidGenerator>();
        
        return services;
    }
}
