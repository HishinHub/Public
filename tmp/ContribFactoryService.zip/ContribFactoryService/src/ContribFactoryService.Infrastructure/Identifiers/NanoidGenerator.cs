using System;
using NanoidDotNet;
using ContribFactoryService.Application.Interfaces;

namespace ContribFactoryService.Infrastructure.Identifiers;

/// <summary>
/// Generator for NanoID identifiers
/// </summary>
public class NanoidGenerator : IIdGenerator
{
    public string NewId() => Nanoid.Generate();
}
