using Microsoft.Extensions.Caching.Hybrid;

namespace ContribFactoryService.Tests.Services;

/// <summary>
/// A simple fake implementation of HybridCache for unit testing.
/// Bypasses actual caching and just executes the factory.
/// </summary>
public class FakeHybridCache : HybridCache
{
    public override ValueTask<T> GetOrCreateAsync<TState, T>(
        string key, 
        TState state, 
        Func<TState, CancellationToken, ValueTask<T>> factory, 
        HybridCacheEntryOptions? options = null, 
        IEnumerable<string>? tags = null, 
        CancellationToken cancellationToken = default)
    {
        return factory(state, cancellationToken);
    }

    public override ValueTask SetAsync<T>(
        string key, 
        T value, 
        HybridCacheEntryOptions? options = null, 
        IEnumerable<string>? tags = null, 
        CancellationToken cancellationToken = default)
    {
        return ValueTask.CompletedTask;
    }

    public override ValueTask RemoveAsync(
        string key, 
        CancellationToken cancellationToken = default)
    {
        return ValueTask.CompletedTask;
    }

    public override ValueTask RemoveByTagAsync(
        string tag, 
        CancellationToken cancellationToken = default)
    {
        return ValueTask.CompletedTask;
    }
}
