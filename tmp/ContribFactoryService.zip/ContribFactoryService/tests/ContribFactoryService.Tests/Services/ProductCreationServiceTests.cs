using AutoBogus;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Application.ProductCreationOrchestrator;
using ContribFactoryService.Application.Validators;
using ContribFactoryService.Application.Interfaces;
using ContribFactoryService.Domain.ProductCreation;
using FluentAssertions;
using FluentValidation;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.Extensions.Caching.Hybrid;
using Xunit;
using NanoidDotNet;

namespace ContribFactoryService.Tests.Services;

/// <summary>
/// Unit tests for ProductCreationService
/// </summary>
public class ProductCreationServiceTests
{
    private readonly Mock<IProductCreationTraceRepository> _mockRepository;
    private readonly Mock<IMessageQueueService<ProductCreationMessage>> _mockMessageQueue;
    private readonly Mock<ILogger<ProductCreationService>> _mockLogger;
    private readonly Mock<IIdGenerator> _mockIdGenerator;
    private readonly Mock<IProductCreationFactory> _mockFactory;
    private readonly HybridCache _fakeHybridCache;
    private readonly ProductCreationRequestValidationService _validationService;
    private readonly ProductCreationService _service;

    public ProductCreationServiceTests()
    {
        _mockRepository = new Mock<IProductCreationTraceRepository>();
        _mockMessageQueue = new Mock<IMessageQueueService<ProductCreationMessage>>();
        _mockLogger = new Mock<ILogger<ProductCreationService>>();
        _mockIdGenerator = new Mock<IIdGenerator>();
        _mockIdGenerator.Setup(x => x.NewId()).Returns(() => Nanoid.Generate());
        _mockFactory = new Mock<IProductCreationFactory>();
        _mockFactory.Setup(x => x.CreateProviders(It.IsAny<ProductCreationTrace>()))
            .Returns((ProductCreationTrace t) => t.ProviderRequests.ToList());
        
        _fakeHybridCache = new FakeHybridCache();
        // Build the real validation service: generic validator + no provider-specific validators
        // (tests use Bloomberg which has no dedicated validator registered here)
        _validationService = new ProductCreationRequestValidationService(
            new GenericRequestValidator(),
            providerValidators: [],
            NullLogger<ProductCreationRequestValidationService>.Instance);

        _service = new ProductCreationService(
            _mockRepository.Object,
            _mockMessageQueue.Object,
            _validationService,
            _mockLogger.Object,
            _fakeHybridCache,
            TimeProvider.System,
            _mockIdGenerator.Object,
            _mockFactory.Object);
    }

    [Fact]
    public async Task SendProductCreationRequestAsync_WithValidData_CreatesAndQueuesRequest()
    {
        // Arrange
        var dto = new ProductCreationRequest
        {
            RequestType = "ProductCreation",
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductType = "FinancialProduct",
                    ProductCode = "PROD-001",
                    ProductName = "Test Product",
                    Fields = new Dictionary<string, object>
                    {
                        { "customRiskLevel", "low" }
                    }
                }
            },
            DefaultProviders = new List<string> { "Bloomberg" }
        };
        
        var requestId = Nanoid.Generate();

        var savedRequest = new ProductCreationTrace
        {
            RequestId = requestId,
            OriginalRequest = dto,
            CreatedAt = DateTime.UtcNow
        };

        _mockRepository
            .Setup(x => x.CreateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProductCreationTrace msg, CancellationToken ct) => msg);

        _mockRepository
            .Setup(x => x.UpdateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProductCreationTrace msg, CancellationToken ct) => msg);

        _mockMessageQueue
            .Setup(x => x.SendMessageAsync(It.IsAny<ProductCreationMessage>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync("test-job-id");

        var savedTrace = new ProductCreationTrace
        {
            RequestId = requestId,
            OriginalRequest = dto,
            ProviderRequests = [
                new ProductCreationProvider 
                { 
                    ProductCode = "PROD-001",
                    ProviderRequestId = "prov-req-id", 
                    ProviderName = ProviderName.Bloomberg, 
                    Status = ProductCreationProviderStatus.Received 
                }
            ]
        };

        _mockFactory
            .Setup(x => x.CreateTrace(dto, requestId))
            .Returns(savedTrace);

        _mockFactory
            .Setup(x => x.CreateMessage(It.IsAny<ProductCreationTrace>()))
            .Returns(new ProductCreationMessage { RequestId = requestId });

        // Act
        var results = await _service.SendProductCreationRequestAsync(dto, requestId);

        // Assert
        results.Should().NotBeNull();
        results.ProviderRequests.Should().NotBeEmpty();
        var result = results.ProviderRequests.First();
        result.RequestId.Should().NotBeNullOrEmpty();
        results.ProviderRequests.Any(r => r.Provider == ProviderName.Bloomberg.ToString()).Should().BeTrue();
        result.Status.Should().Be(ProductCreationProviderStatus.Received.ToString());

        _mockRepository.Verify(x => x.CreateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()), Times.Once);
        _mockRepository.Verify(x => x.UpdateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()), Times.Once);
        _mockMessageQueue.Verify(x => x.SendMessageAsync(It.IsAny<ProductCreationMessage>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task SendProductCreationRequestAsync_WithInvalidData_ThrowsValidationException()
    {
        // Arrange
        var dto = new ProductCreationRequest
        {
            RequestType = "WrongType", // Invalid
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductCode = "" // Invalid
                }
            }
        };

        _mockRepository
            .Setup(x => x.CreateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProductCreationTrace m, CancellationToken c) => m);

        _mockFactory
            .Setup(x => x.CreateTrace(It.IsAny<ProductCreationRequest>(), It.IsAny<string>()))
            .Returns((ProductCreationRequest req, string rid) => new ProductCreationTrace { RequestId = rid, OriginalRequest = req });

        // Act & Assert
        var requestId = Nanoid.Generate();
        await Assert.ThrowsAsync<ValidationException>(() => 
            _service.SendProductCreationRequestAsync(dto, requestId));

        _mockRepository.Verify(x => x.CreateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()), Times.Once);
        _mockRepository.Verify(x => x.UpdateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()), Times.Never);
        _mockMessageQueue.Verify(x => x.SendMessageAsync(It.IsAny<ProductCreationMessage>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task GetProductCreationStatusAsync_WithExistingRequest_ReturnsStatus()
    {
        // Arrange
        var requestId = Nanoid.Generate();
        var dto = new ProductCreationRequest 
        { 
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductCode = "PROD-123"
                }
            },
            DefaultProviders = new List<string> { "Bloomberg" }
        };
        var productCreationTrace = new ProductCreationTrace
        {
            RequestId = requestId,
            OriginalRequest = dto,
            Status = ProductCreationTraceStatus.Received,
            CreatedAt = DateTime.UtcNow
        };
        productCreationTrace.ProviderRequests.Add(new ProductCreationProvider 
        { 
            ProviderName = ProviderName.Bloomberg, 
            ProviderRequestId = $"{requestId}.BLO",
            Status = ProductCreationProviderStatus.Sent 
        });

        _mockRepository
            .Setup(x => x.GetByRequestIdAsync(requestId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(productCreationTrace);

        // Act
        var results = await _service.GetProductCreationStatusAsync(requestId);

        // Assert
        results.Should().NotBeNull();
        results.ProviderRequests.Should().NotBeEmpty();
        var result = results.ProviderRequests.First();
        result.RequestId.Should().Be(requestId);
        result.ProviderRequestId.Should().Be($"{requestId}.BLO");
        result.Status.Should().Be(ProductCreationProviderStatus.Sent.ToString());
    }

    [Fact]
    public async Task GetProductCreationStatusAsync_WithNonExistingRequest_ReturnsNull()
    {
        // Arrange
        var requestId = Nanoid.Generate();

        _mockRepository
            .Setup(x => x.GetByRequestIdAsync(requestId, It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProductCreationTrace?)null);

        // Act
        var results = await _service.GetProductCreationStatusAsync(requestId);

        // Assert
        results.Should().BeNull();
    }

    [Fact]
    public async Task SendProductCreationRequestAsync_WithRefinitivProvider_AppliesRefinitivValidation()
    {
        // 1. Arrange with Refinitiv provider but missing mandatory Refinitiv fields
        var dto = new ProductCreationRequest
        {
            RequestType = "ProductCreation",
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductType = "Bond",
                    ProductCode = "ISIN123",
                    ProductName = "Refinitiv Bond"
                    // Missing: Currency, Coupon, MaturityDate
                }
            },
            DefaultProviders = new List<string> { "Refinitiv" }
        };

        // Create a service with the real Refinitiv validator
        var refinitivValidator = new RefinitivRequestValidator();
        var validationService = new ProductCreationRequestValidationService(
            new GenericRequestValidator(),
            providerValidators: [refinitivValidator],
            NullLogger<ProductCreationRequestValidationService>.Instance);

        var serviceWithRefinitiv = new ProductCreationService(
            _mockRepository.Object,
            _mockMessageQueue.Object,
            validationService,
            _mockLogger.Object,
            _fakeHybridCache,
            TimeProvider.System,
            _mockIdGenerator.Object,
            _mockFactory.Object);

        _mockRepository
            .Setup(x => x.CreateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProductCreationTrace m, CancellationToken c) => m);

        // 2. Act & Assert
        var requestId = Nanoid.Generate();
        
        _mockFactory
            .Setup(x => x.CreateTrace(It.IsAny<ProductCreationRequest>(), It.IsAny<string>()))
            .Returns((ProductCreationRequest req, string rid) => new ProductCreationTrace { RequestId = rid, OriginalRequest = req, ProviderRequests = new List<ProductCreationProvider> { new ProductCreationProvider { ProviderName = ProviderName.Refinitiv } } });

        // Should throw because Refinitiv fields are missing even if Generic validation passes
        var ex = await Assert.ThrowsAsync<ValidationException>(() => 
            serviceWithRefinitiv.SendProductCreationRequestAsync(dto, requestId));

        ex.Errors.Should().Contain(e => e.ErrorMessage.Contains("Currency is mandatory for Refinitiv"));
        ex.Errors.Should().Contain(e => e.ErrorMessage.Contains("Coupon is mandatory"));
        ex.Errors.Should().Contain(e => e.ErrorMessage.Contains("Maturity Date is mandatory"));
    }
    [Fact]
    public async Task SendProductCreationRequestAsync_WithPerPayloadProviders_AssignsCorrectly()
    {
        // Arrange
        var dto = new ProductCreationRequest
        {
            RequestType = "ProductCreation",
            DefaultProviders = new List<string> { "Bloomberg" }, // Root: Bloomberg
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductCode = "P1-RootFallback",
                    Providers = new List<string>() // Uses root: Bloomberg
                },
                new ProductPayload
                {
                    ProductCode = "P2-Explicit",
                    Providers = new List<string> { "Refinitiv" } // Uses own: Refinitiv
                }
            }
        };
        
        var requestId = Nanoid.Generate();

        _mockRepository
            .Setup(x => x.CreateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProductCreationTrace msg, CancellationToken ct) => msg);

        _mockRepository
            .Setup(x => x.UpdateAsync(It.IsAny<ProductCreationTrace>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProductCreationTrace msg, CancellationToken ct) => msg);

        _mockMessageQueue
            .Setup(x => x.SendMessageAsync(It.IsAny<ProductCreationMessage>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync("test-job-id");

        _mockFactory
            .Setup(x => x.CreateTrace(It.IsAny<ProductCreationRequest>(), It.IsAny<string>()))
            .Returns((ProductCreationRequest req, string rid) => 
            {
                var msg = new ProductCreationTrace { RequestId = rid, OriginalRequest = req, ProviderRequests = new List<ProductCreationProvider>() };
                msg.ProviderRequests.Add(new ProductCreationProvider { ProviderName = ProviderName.Bloomberg, ProviderRequestId = rid + ".BLO", Status = ProductCreationProviderStatus.Received });
                msg.ProviderRequests.Add(new ProductCreationProvider { ProviderName = ProviderName.Refinitiv, ProviderRequestId = rid + ".REF", Status = ProductCreationProviderStatus.Received });
                return msg;
            });

        _mockFactory
            .Setup(x => x.CreateMessage(It.IsAny<ProductCreationTrace>()))
            .Returns((ProductCreationTrace trace) => new ProductCreationMessage { RequestId = trace.RequestId });

        // Act
        var results = await _service.SendProductCreationRequestAsync(dto, requestId);

        // Assert
        results.Should().NotBeNull();
        results.ProviderRequests.Should().HaveCount(2);
        
        results.ProviderRequests.Any(r => r.Provider == ProviderName.Bloomberg.ToString()).Should().BeTrue();
        results.ProviderRequests.Any(r => r.Provider == ProviderName.Refinitiv.ToString()).Should().BeTrue();
    }
}
