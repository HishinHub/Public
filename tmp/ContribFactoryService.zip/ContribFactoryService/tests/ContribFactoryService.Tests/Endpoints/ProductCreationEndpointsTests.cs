using System.Net;
using System.Net.Http.Json;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Tests.Fixtures;
using FluentAssertions;
using Xunit;
using NanoidDotNet;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ContribFactoryService.Tests.Endpoints;

/// <summary>
/// Integration tests for Product Creation endpoints
/// </summary>
public class ProductCreationEndpointsTests : IClassFixture<WebApiTestFixture>
{
    private readonly WebApiTestFixture _factory;

    private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() }
    };

    public ProductCreationEndpointsTests(WebApiTestFixture factory)
    {
        _factory = factory;
    }

    private async Task<HttpClient> GetClientAsync() => await _factory.CreateAuthenticatedClientAsync();

    [Fact]
    public async Task CreateProductRequest_WithValidData_ReturnsCreated()
    {
        var client = await GetClientAsync();
        var request = new ProductCreationRequest
        {
            RequestType = "ProductCreation",
            Timestamp = DateTime.UtcNow,
            DefaultProviders = new List<string> { "Bloomberg" },
            Payload = new List<ProductPayload>
            {
                new ProductPayload 
                {
                    ProductType = "FinancialProduct",
                    ProductCode = "PROD-2026-TEST",
                    ProductName = "Test Product",
                    Description = "Test Description",
                    Fields = new Dictionary<string, object>
                    {
                        { "customRiskLevel", "low" }
                    }
                }
            }
        };

        var response = await client.PostAsJsonAsync("/api/v1/products", request);

        if (response.StatusCode != HttpStatusCode.Created)
        {
            var body = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"Response Body: {body}");
        }
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        
        var result = await response.Content.ReadFromJsonAsync<ProductCreationApiGroupResponse>(JsonOptions);
        result.Should().NotBeNull();
        result!.ProviderRequests.Should().NotBeEmpty();
        result.ProviderRequests[0].Status.Should().Contain("Received");
    }

    [Fact]
    public async Task CreateProductRequest_WithInvalidData_ReturnsBadRequest()
    {
        var client = await GetClientAsync();
        var request = new ProductCreationRequest
        {
            RequestType = "InvalidType",
            DefaultProviders = new List<string> { "Bloomberg" },
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductCode = ""
                }
            }
        };

        var response = await client.PostAsJsonAsync("/api/v1/products", request);

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task GetProductRequestStatus_WithExistingRequest_ReturnsOk()
    {
        var client = await GetClientAsync();
        var createRequest = new ProductCreationRequest
        {
            RequestType = "ProductCreation",
            DefaultProviders = new List<string> { "Bloomberg" },
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductType = "FinancialProduct",
                    ProductCode = "STATUS-CHECK", 
                    ProductName = "Status Check"
                }
            }
        };

        var createResponse = await client.PostAsJsonAsync("/api/v1/products", createRequest);
        var createdProducts = await createResponse.Content.ReadFromJsonAsync<ProductCreationApiGroupResponse>(JsonOptions);
        var createdProduct = createdProducts!.ProviderRequests[0];

        var response = await client.GetAsync($"/api/v1/products/{createdProduct.RequestId}");

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var result = await response.Content.ReadFromJsonAsync<ProductCreationApiGroupResponse>(JsonOptions);
        result.Should().NotBeNull();
        result!.ProviderRequests.Should().NotBeNull();
        result.ProviderRequests[0].RequestId.Should().Be(createdProduct.RequestId);
    }

    [Fact]
    public async Task GetProductRequestStatus_WithNonExistingRequest_ReturnsNotFound()
    {
        var client = await GetClientAsync();
        var nonExistingId = Nanoid.Generate();

        var response = await client.GetAsync($"/api/v1/products/{nonExistingId}");

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task CreateProductRequest_ForMultipleProviders_ReturnsMultipleCreated()
    {
        var client = await GetClientAsync();
        var request = new ProductCreationRequest
        {
            RequestType = "ProductCreation",
            DefaultProviders = new List<string> { "Bloomberg", "Refinitiv" },
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductType = "FinancialProduct",
                    ProductCode = "MULTI-PROV",
                    ProductName = "Multi Provider Product",
                    Currency = "USD",
                    Coupon = 5.5,
                    MaturityDate = DateTime.UtcNow.AddYears(1)
                }
            }
        };

        var response = await client.PostAsJsonAsync("/api/v1/products", request);

        response.StatusCode.Should().Be(HttpStatusCode.Created);
        
        var result = await response.Content.ReadFromJsonAsync<ProductCreationApiGroupResponse>(JsonOptions);
        result.Should().NotBeNull();
        result!.ProviderRequests.Should().HaveCount(2);
        result.ProviderRequests.Any(r => r.Provider.Contains("Bloomberg")).Should().BeTrue();
        result.ProviderRequests.Any(r => r.Provider.Contains("Refinitiv")).Should().BeTrue();
    }
}
