using System.Net;
using System.Net.Http.Json;
using ContribFactoryService.Domain.ProductCreation;
using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryService.Tests.Fixtures;
using FluentAssertions;
using Xunit;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ContribFactoryService.Tests.Endpoints;

public class DebugTest : IClassFixture<WebApiTestFixture>
{
    private readonly HttpClient _client;
    
    public DebugTest(WebApiTestFixture factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task Debug_CreateProductRequest()
    {
        var request = new ProductCreationRequest
        {
            RequestType = "ProductCreation",
            Timestamp = DateTime.UtcNow,
            DefaultProviders = new List<string> { "Bloomberg" },
            Payload = new List<ProductPayload>
            {
                new ProductPayload 
                {
                    ProductType = "FinancialProduct",
                    ProductCode = "PROD-DEBUG",
                    ProductName = "Debug Product"
                }
            }
        };

        var response = await _client.PostAsJsonAsync("/api/v1/products", request);
        var body = await response.Content.ReadAsStringAsync();
        
        System.IO.File.WriteAllText("c:/HOME/Repos/ContribFactoryService/debug_output.txt", $"Status: {response.StatusCode}\nBody: {body}");
        
        response.StatusCode.Should().Be(HttpStatusCode.Created);
    }
}
