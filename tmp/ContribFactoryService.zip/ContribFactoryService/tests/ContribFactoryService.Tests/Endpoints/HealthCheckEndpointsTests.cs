using System.Net;
using System.Net.Http.Json;
using ContribFactoryService.Tests.Fixtures;
using FluentAssertions;
using Xunit;

namespace ContribFactoryService.Tests.Endpoints;

/// <summary>
/// Integration tests for Health Check endpoints
/// </summary>
public class HealthCheckEndpointsTests : IClassFixture<WebApiTestFixture>
{
    private readonly HttpClient _client;

    public HealthCheckEndpointsTests(WebApiTestFixture factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task HealthCheck_Live_ReturnsHealthy()
    {
        // Act
        var response = await _client.GetAsync("/health/live");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var content = await response.Content.ReadAsStringAsync();
        content.Should().Contain("Healthy");
    }

    [Fact]
    public async Task HealthCheck_Ready_ReturnsHealthy()
    {
        // Act
        var response = await _client.GetAsync("/health/ready");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var content = await response.Content.ReadAsStringAsync();
        content.Should().Contain("Healthy");
    }

    [Fact]
    public async Task HealthCheck_Overall_ReturnsHealthy()
    {
        // Act
        var response = await _client.GetAsync("/health");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var content = await response.Content.ReadAsStringAsync();
        content.Should().Contain("Healthy");
        content.Should().Contain("database");
        content.Should().Contain("self");
    }

    [Fact]
    public async Task HealthCheck_ReturnsJsonContentType()
    {
        // Act
        var response = await _client.GetAsync("/health");

        // Assert
        response.Content.Headers.ContentType?.MediaType.Should().Be("application/json");
    }

    [Fact]
    public async Task HealthCheck_DoesNotRequireAuthentication()
    {
        // Act
        // Create a new client from the factory which doesn't have the auth header set in the constructor
        // Wait, the constructor of HealthCheckEndpointsTests doesn't set auth header on _client anyway,
        // unlike ProductCreationEndpointsTests.
        var response = await _client.GetAsync("/health");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}
