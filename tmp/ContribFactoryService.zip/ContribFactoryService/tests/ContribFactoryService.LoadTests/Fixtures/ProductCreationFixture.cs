using ContribFactoryService.Domain.ProductCreation.ApiRequestResponse;
using NBomber.Contracts;

namespace ContribFactoryService.LoadTests.Fixtures;

public static class ProductCreationFixture
{
    public static ProductCreationRequest CreateRefinitivRequest()
    {
        return new ProductCreationRequest
        {

            DefaultProviders = new List<string> { "Refinitiv" },
            Payload = new List<ProductPayload>
            {
                new ProductPayload
                {
                    ProductType = "Bond",
                    ProductCode = "FR0014003TT0",
                    ProductName = "OAT 0.5% 2032",
                    Currency = "EUR",
                    Coupon = 0.5,
                    MaturityDate = new DateTime(2032, 5, 25),
                    Fields = new Dictionary<string, object>
                    {
                        { "CustomField", "Value" }
                    }
                }
            }
        };
    }
}
