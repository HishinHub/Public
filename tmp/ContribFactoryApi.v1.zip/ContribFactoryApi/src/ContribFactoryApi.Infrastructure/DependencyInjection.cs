using ContribFactoryApi.Application.ProductCreation.Interfaces;
using ContribFactoryApi.Infrastructure.Database;
using ContribFactoryApi.Infrastructure.ProviderBloomberg;
using ContribFactoryApi.Infrastructure.ProviderRefinitiv;
using ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi;
using ContribFactoryApi.Infrastructure.Messaging;
using ContribFactoryApi.Infrastructure.ProviderSix;
using ContribFactoryApi.Infrastructure.Repositories;
using ContribFactoryApi.Infrastructure.Identifiers;
using ContribFactoryApi.Infrastructure.Admin;
using ContribFactoryApi.Infrastructure.Authentication;
using ContribFactoryApi.Infrastructure.Sftp;
using ContribFactoryApi.Infrastructure.Resilience;
using ContribFactoryApi.Infrastructure.AWS.S3;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryApi.Infrastructure;

/// <summary>
/// Dependency injection configuration for Infrastructure layer
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services, 
        IConfiguration configuration)
    {
        services.AddSingleton(TimeProvider.System);
        services.AddIdentifiers();
        
        // Database
        services.AddDbContext<AppDbContext>(options =>
            // options.UseInMemoryDatabase("ProductCreationDb"));
            options.UseSqlServer(
                configuration.GetConnectionString("ProductCreation"),
                sqlOptions => sqlOptions.EnableRetryOnFailure()));

        // Repositories
        services.AddScoped<IProductCreationTraceRepository, ProductCreationTraceRepository>();

        // Provider Services
        services.AddRefinitiv(configuration);
        services.AddSixConnexor(configuration);
        services.AddBloomberg(configuration);

        // Messaging (Channel-based queue + BackgroundWorker)
        services.AddMessaging();

        // Admin
        services.AddAdmin();

        // Authentication
        services.AddJwtAuthentication(configuration);

        // Resilience
        services.AddResilience(configuration);
 
        // AWS
        services.AddAwsS3(configuration);


        return services;
    }
}
