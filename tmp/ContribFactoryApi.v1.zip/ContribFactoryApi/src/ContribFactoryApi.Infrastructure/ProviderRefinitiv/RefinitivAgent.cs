using ContribFactoryApi.Application.ProductCreation.Interfaces;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv;

/// <summary>
/// Refinitiv-specific product creation agent
/// </summary>
public class RefinitivAgent : IProviderAgent
{
    private readonly ILogger<RefinitivAgent> _logger;
    private readonly IRefinitivApiClient _refinitivApiClient;
    private readonly IRefinitivMapper _refinitivMapper;

    public RefinitivAgent(
        ILogger<RefinitivAgent> logger,
        IRefinitivApiClient refinitivApiClient,
        IRefinitivMapper refinitivMapper)
    {
        _logger = logger;
        _refinitivApiClient = refinitivApiClient;
        _refinitivMapper = refinitivMapper;
    }

    public ProviderName Provider => ProviderName.Refinitiv;

    public async Task<SendRequestResponse> SendRequestAsync(
        ProductPayload payload,
        RunContext runContext,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation(
            "[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Refinitiv] Refinitiv: Sending product via payload", 
            runContext.RequestId,
            runContext.ProviderRequestId);

        var refinitivRequest = _refinitivMapper.ToSendRicCreationRequest(payload, runContext);

        _logger.LogInformation(
            "[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Refinitiv] Refinitiv Request: {@RefinitivRequest}", 
            runContext.RequestId,
            runContext.ProviderRequestId,
            refinitivRequest);

        // Call the real Refinitiv API
        var result = await _refinitivApiClient.SendRicCreation(payload.ProductCode, refinitivRequest, runContext);

        if (result != null)
        {
            _logger.LogInformation(
                "[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Refinitiv] Refinitiv Response: JobId={JobId}, Uuid={Uuid}, Msg={Msg}",
                runContext.RequestId,
                runContext.ProviderRequestId,
                result.JobId,
                result.Uuid,
                result.Message);
        }

        return _refinitivMapper.ToProviderResponse(result, payload.ProductCode);
    }

    public async Task<GetStatusResponse> GetStatusAsync(
        RunContext runContext,
        string productCode,
        string? externalRequestId,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[RUN:{RunId}/REQ:{RequestId}][ProdCrea/Refinitiv] Refinitiv: Getting status for {ProductCode} (ExternalRef: {ExternalRequestId})", runContext.RunId, runContext.RequestId, productCode, externalRequestId);

        if (string.IsNullOrEmpty(externalRequestId) || !int.TryParse(externalRequestId, out var jobId))
        {
            _logger.LogWarning("[RUN:{RunId}/REQ:{RequestId}][ProdCrea/Refinitiv] No valid JobId found for status check of {ProductCode}", runContext.RunId, runContext.RequestId, productCode);
            return new GetStatusResponse { Success = false, ErrorMessage = "No valid JobId found for status check", Status = ProductCreationProviderStatus.Failed };
        }

        try
        {
            var result = await _refinitivApiClient.GetRicStatus(jobId);
            return _refinitivMapper.ToProviderResponse(result, productCode);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[RUN:{RunId}/REQ:{RequestId}][ProdCrea/Refinitiv] Exception getting status from Refinitiv", runContext.RunId, runContext.RequestId);
            return new GetStatusResponse { Success = false, ErrorMessage = ex.Message, Status = ProductCreationProviderStatus.Failed };
        }
    }
}
