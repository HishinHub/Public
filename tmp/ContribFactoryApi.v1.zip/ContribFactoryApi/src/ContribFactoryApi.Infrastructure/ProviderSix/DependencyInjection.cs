using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using ContribFactoryApi.Application.ProductCreation.Interfaces;
using ContribFactoryApi.Infrastructure.ProviderSix.SixConnexor;

namespace ContribFactoryApi.Infrastructure.ProviderSix;

public static class DependencyInjection
{
    public static IServiceCollection AddSixConnexor(this IServiceCollection services, IConfiguration configuration)
    {
        SixConnexor.DependencyInjection.AddSixConnexor(services, configuration);
        services.AddSingleton<ISixMapper, SixMapper>();
        services.AddScoped<IProviderAgent, SixAgent>();

        return services;
    }
}
