using ContribFactoryApi.Domain.ProductCreation;

namespace ContribFactoryApi.Application.ProductCreation.ProductCreationRules;

/// <summary>
/// Extension methods for checking provider request status collections
/// </summary>
public static class ProductCreationStatusExtensions
{
    /// <summary>
    /// Checks if all providers in the collection have reached a 'Created' status.
    /// </summary>
    public static bool IsAllCreated(this IEnumerable<ProductCreationProvider> providers)
    {
        return providers.All(p => p.Status == ProductCreationProviderStatus.Created);
    }

    /// <summary>
    /// Checks if all providers in the collection have failed or been rejected.
    /// </summary>
    public static bool IsAllFailed(this IEnumerable<ProductCreationProvider> providers)
    {
        // Any status < 0 (Technical errors) or Rejected (Functional errors)
        return providers.All(p => p.Status == ProductCreationProviderStatus.Rejected || (int)p.Status < 0);
    }

    /// <summary>
    /// Checks if any provider in the collection is currently in progress (sent to or acknowledged by provider).
    /// </summary>
    public static bool IsAnyInProgress(this IEnumerable<ProductCreationProvider> providers)
    {
        return providers.Any(p => p.Status == ProductCreationProviderStatus.Sent || p.Status == ProductCreationProviderStatus.Ack);
    }

    /// <summary>
    /// Filters the collection to include only providers that are not canceled (active providers).
    /// </summary>
    public static IEnumerable<ProductCreationProvider> ActiveProviders(this IEnumerable<ProductCreationProvider> providers)
    {
        return providers.Where(p => p.Status != ProductCreationProviderStatus.Canceled);
    }

    /// <summary>
    /// Updates the ProductCreationTrace status based on the statuses of its providers
    /// </summary>
    public static void ReviewTraceStatus(this ProductCreationTrace trace)
    {
        if (trace?.ProviderRequests == null || trace.ProviderRequests.Count == 0)
        {
            return;
        }

        // Filter out canceled providers
        var activeProviders = trace.ProviderRequests.ActiveProviders().ToList();

        if (activeProviders.Count == 0)
        {
            return;
        }

        // 1. All Created (success)
        if (activeProviders.IsAllCreated())
        {
            trace.Status = ProductCreationTraceStatus.Completed;
            trace.UpdatedAt = DateTime.UtcNow;
            return;
        }

        // 2. All Failed or Rejected
        if (activeProviders.IsAllFailed())
        {
            trace.Status = ProductCreationTraceStatus.ProviderFailed;
            trace.UpdatedAt = DateTime.UtcNow;
            return;
        }

        // 3. Any InProgress (Sent or higher)
        if (activeProviders.IsAnyInProgress())
        {
            trace.Status = ProductCreationTraceStatus.ProviderInCharge;
            trace.UpdatedAt = DateTime.UtcNow;
            return;
        }
    }
}
