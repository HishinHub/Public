using ContribFactoryApi.Application.ProductCreation.ProductCreationOrchestrator;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryApi.Application.ProductCreation.ProductCreationOrchestrator;

/// <summary>
/// Dependency injection configuration for ProductCreationOrchestrator
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddProductCreationOrchestrator(this IServiceCollection services)
    {
        services.AddScoped<ProductCreationService>();
        services.AddSingleton<IProductCreationFactory, ProductCreationFactory>();
        
        return services;
    }
}
