using ContribFactoryApi.Application.ProductCreation.Interfaces;
using ContribFactoryApi.Application.ProductCreation.Validators;
using ContribFactoryApi.Application.ProductCreation.ProductCreationOrchestrator;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryApi.Application.ProductCreation.ProductCreationRules;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Logging;

namespace ContribFactoryApi.Application.ProductCreation.ProductCreationOrchestrator;

/// <summary>
/// Service for handling product creation requests
/// </summary>
public class ProductCreationService
{
    private readonly IProductCreationTraceRepository _repository;
    private readonly IMessageQueueService<ProductCreationMessage> _messageQueueService;
    private readonly ProductCreationRequestValidationService _validationService;
    private readonly ILogger<ProductCreationService> _logger;
    private readonly HybridCache _hybridCache;
    private readonly TimeProvider _timeProvider;
    private readonly IIdGenerator _idGenerator;
    private readonly IProductCreationFactory _productCreationFactory;

    public ProductCreationService(
        IProductCreationTraceRepository repository,
        IMessageQueueService<ProductCreationMessage> messageQueueService,
        ProductCreationRequestValidationService validationService,
        ILogger<ProductCreationService> logger,
        HybridCache hybridCache,
        TimeProvider timeProvider,
        IIdGenerator idGenerator,
        IProductCreationFactory productCreationFactory)
    {
        _repository = repository;
        _messageQueueService = messageQueueService;
        _validationService = validationService;
        _logger = logger;
        _hybridCache = hybridCache;
        _timeProvider = timeProvider;
        _idGenerator = idGenerator;
        _productCreationFactory = productCreationFactory;
    }

    /// <summary>
    /// Processes a product creation request
    /// </summary>
    public async Task<ProductCreationApiGroupResponse> SendProductCreationRequestAsync(
        ProductCreationRequest request, 
        string requestId,
        CancellationToken cancellationToken = default)
    {
        using var activity = Instrumentation.ActivitySource.StartActivity(Instrumentation.Activities.SendProductCreationRequest);
        activity?.SetTag(Instrumentation.Tags.CorrelationId, requestId);

        _logger.LogInformation(
            "[REQ:{RequestId}][ProdCrea] Received product creation request REQ:{RequestId} (Status: Requested)", 
            requestId,
            requestId);

        var now = _timeProvider.GetUtcNow().UtcDateTime;

        // 1. Create message using factory and save to database
        var productCreationTrace = _productCreationFactory.CreateTrace(request, requestId);
        productCreationTrace.Status = ProductCreationTraceStatus.Received;
        await _repository.CreateAsync(productCreationTrace, cancellationToken);

        // 2. Validate the request (generic + per-provider rules)
        await _validationService.ValidateAsync(productCreationTrace, cancellationToken);

        // 3. Validation succeeded
        _logger.LogInformation(
            "[REQ:{RequestId}][ProdCrea] Validation succeeded for request REQ:{RequestId}", 
            requestId,
            requestId);

        // Create provider records
        var createdProviders = _productCreationFactory.CreateProviders(productCreationTrace);

        // Set status and timestamp before final update
        productCreationTrace.Status = ProductCreationTraceStatus.OnGoing;
        productCreationTrace.UpdatedAt = _timeProvider.GetUtcNow().UtcDateTime;

        await _repository.UpdateAsync(productCreationTrace, cancellationToken);


        // Generate responses for each provider record created
        var response = ProductCreationMapper.MapToApiGroup(
            productCreationTrace,
            createdProviders);

        try
        {
            // Create simplified message for dispatching
            var message = _productCreationFactory.CreateMessage(productCreationTrace);

            // Send message to the configured message queue
            var jobId = await _messageQueueService.SendMessageAsync(message, cancellationToken);
            _logger.LogInformation(
                "[REQ:{RequestId}][ProdCrea] Request REQ:{RequestId} message processed by message queue with Job ID {JobId}",
                requestId,
                requestId, 
                jobId);
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex, 
                "[REQ:{RequestId}][ProdCrea] Failed to process message for request REQ:{RequestId} in message queue", 
                requestId,
                requestId);
        }

        return response;
    }

    /// <summary>
    /// Gets the status of all product creations associated with a request ID
    /// </summary>
    public async Task<ProductCreationApiGroupResponse?> GetProductCreationStatusAsync(
        string requestId, 
        CancellationToken cancellationToken = default)
    {
        var cacheKey = $"product_status_REQ:{requestId}";

        // 1. Try to get from cache or retrieve from database if miss
        var response = await _hybridCache.GetOrCreateAsync<ProductCreationApiGroupResponse?>(
            cacheKey,
            async ct => 
            {
                _logger.LogInformation("[REQ:{RequestId}][ProdCrea] Retrieving status for REQ:{RequestId} from database (cache miss)", requestId, requestId);
                var trace = await _repository.GetByRequestIdAsync(requestId, ct);
                
                if (trace == null)
                {
                    _logger.LogWarning("[REQ:{RequestId}][ProdCrea] Product creation message REQ:{RequestId} not found", requestId, requestId);
                    return null;
                }

                return ProductCreationMapper.MapToApiGroup(trace, trace.ProviderRequests);
            },
            options: new HybridCacheEntryOptions
            {
                Expiration = TimeSpan.FromMinutes(1) // Default for non-final
            },
            cancellationToken: cancellationToken);

        if (response != null && response.ProviderRequests.All(r => r.StatusId == (int)ProductCreationProviderStatus.Created || r.StatusId == (int)ProductCreationProviderStatus.Rejected))
        {
            _logger.LogInformation("[REQ:{RequestId}][ProdCrea] All products in request REQ:{RequestId} reached final state, ensuring long-term cache", requestId, requestId);
            // Overwrite with long expiration for final states
            await _hybridCache.SetAsync(cacheKey, response, new HybridCacheEntryOptions { Expiration = TimeSpan.FromDays(7) }, cancellationToken: cancellationToken);
        }

        return response;
    }

    /// <summary>
    /// Gets the status of all providers matching a name for a given request ID
    /// </summary>
    public async Task<ProductCreationApiGroupResponse?> GetProviderStatusByRequestIdAndProviderNameAsync(
        string requestId, 
        ProviderName providerName,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[REQ:{RequestId}][ProdCrea] Retrieving status for {ProviderName}", requestId, providerName);
        
        var trace = await _repository.GetByRequestIdAndProviderNameAsync(requestId, providerName, cancellationToken);
        
        if (trace == null || !trace.ProviderRequests.Any())
        {
            return null;
        }

        return ProductCreationMapper.MapToApiGroup(trace, trace.ProviderRequests);
    }

    /// <summary>
    /// Gets the status of a specific provider request by its unique providerRequestId
    /// </summary>
    public async Task<ProductCreationApiResponse?> GetProviderStatusByProviderRequestIdAsync(
        string providerRequestId,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[ProdCrea] Retrieving status for provider request {ProviderRequestId}", providerRequestId);
        
        var providerRecord = await _repository.GetByProviderRequestIdAsync(providerRequestId, cancellationToken);
        
        if (providerRecord == null)
        {
            return null;
        }

        return ProductCreationMapper.MapToApiStep(providerRecord);
    }
    public async Task<bool> CancelProviderRequestIdAsync(string providerRequestId, CancellationToken cancellationToken = default)
    {
        var provider = await _repository.GetByProviderRequestIdAsync(providerRequestId, cancellationToken);
        if (provider == null || provider.Trace == null)
        {
            return false;
        }

        var trace = provider.Trace;
        var providerToCancel = trace.ProviderRequests.FirstOrDefault(p => p.ProviderRequestId == providerRequestId);
        
        if (providerToCancel == null)
        {
            providerToCancel = provider; // Fallback if for some reason not in collection
        }

        providerToCancel.Status = ProductCreationProviderStatus.Canceled;
        providerToCancel.UpdatedAt = _timeProvider.GetUtcNow().UtcDateTime;

        // Re-evaluate trace status
        trace.ReviewTraceStatus();

        await _repository.UpdateAsync(trace, cancellationToken);
        _logger.LogInformation("[REQ:{RequestId}][ProdCrea] Canceled provider request {ProviderRequestId}", trace.RequestId, providerRequestId);
        
        return true;
    }

    /// <summary>
    /// Cancels all failed provider requests for a given requestId
    /// </summary>
    public async Task<int> CancelFailedProvidersByRequestIdAsync(string requestId, CancellationToken cancellationToken = default)
    {
        var trace = await _repository.GetByRequestIdAsync(requestId, cancellationToken);
        if (trace == null)
        {
            return 0;
        }

        var failedProviders = trace.ProviderRequests
            .Where(p => p.Status == ProductCreationProviderStatus.Rejected || (int)p.Status < 0)
            .ToList();

        if (failedProviders.Count == 0)
        {
            return 0;
        }

        foreach (var provider in failedProviders)
        {
            provider.Status = ProductCreationProviderStatus.Canceled;
            provider.UpdatedAt = _timeProvider.GetUtcNow().UtcDateTime;
        }

        // Re-evaluate trace status
        trace.ReviewTraceStatus();

        await _repository.UpdateAsync(trace, cancellationToken);
        _logger.LogInformation("[REQ:{RequestId}][ProdCrea] Canceled {Count} failed provider requests", requestId, failedProviders.Count);

        return failedProviders.Count;
    }
}
