using ContribFactoryApi.Application.ProductCreation.Interfaces;
using ContribFactoryApi.Application.ProductCreation.ProductCreationRules;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ContribFactoryApi.Application.ProductCreation.ProviderSynchronizer;

/// <summary>
/// Service for synchronizing provider statuses
/// </summary>
public class ProviderSynchronizerService : IProviderSynchronizerService
{
    private readonly IEnumerable<IProviderAgent> _providerAgents;
    private readonly IProductCreationTraceRepository _repository;
    private readonly ProviderSynchronizerOptions _options;
    private readonly ILogger<ProviderSynchronizerService> _logger;
    private readonly IIdGenerator _idGenerator;

    public ProviderSynchronizerService(
        IEnumerable<IProviderAgent> providerAgents,
        IProductCreationTraceRepository repository,
        IOptions<ProviderSynchronizerOptions> options,
        IIdGenerator idGenerator,
        ILogger<ProviderSynchronizerService> logger)
    {
        _providerAgents = providerAgents;
        _repository = repository;
        _options = options.Value;
        _idGenerator = idGenerator;
        _logger = logger;
    }

    public async Task SynchronizeAsync(CancellationToken cancellationToken = default)
    {
        var runId = _idGenerator.NewId();
        _logger.LogInformation("[RUN:{RunId}][ProviderSynchronizer] Starting provider status synchronization", runId);

        // Fetch all non-completed provider records from non-completed messages
        var readyToSyncProviders = await _repository.GetAllReadyToSync(cancellationToken);
        _logger.LogInformation("[RUN:{RunId}][ProviderSynchronizer] Found {Count} incomplete provider records to synchronize", runId, readyToSyncProviders.Count);

        // Use only explicitly configured providers
        var providersToSync = _options.EnabledProviders;

        var enabledProviders = readyToSyncProviders.FilterByEnabledProviders(runId, providersToSync, _logger, out _).ToList();
        _logger.LogInformation("[RUN:{RunId}][ProviderSynchronizer] {Count} provider records are enabled for synchronization", runId, enabledProviders.Count);

        foreach (var providerRequest in enabledProviders)
        {
            var trace = providerRequest.Trace;
            ArgumentNullException.ThrowIfNull(trace);

            var productCode = trace.OriginalRequest.Payload.FirstOrDefault()?.ProductCode;
            ArgumentException.ThrowIfNullOrEmpty(productCode);

            var agent = _providerAgents.FirstOrDefault(a => a.Provider == providerRequest.ProviderName);
            
            // Only sync if we found the agent and it's not already in a terminal state
            if (agent != null && 
                !providerRequest.IsAlreadyProcessed() &&
                providerRequest.Status != ProductCreationProviderStatus.Failed)
            {
                _logger.LogInformation("[RUN:{RunId}/REQ:{RequestId}][ProviderSynchronizer] Syncing status for Request REQ:{RequestId} / provider: {Provider}", runId, trace.RequestId, trace.RequestId, providerRequest.ProviderName);
                
                var runContext = new RunContext
                {
                    RequestId = trace.RequestId,
                    ProviderRequestId = providerRequest.ProviderRequestId,
                    RunId = runId
                };
                
                var response = await agent.GetStatusAsync(runContext, productCode, providerRequest.ExternalRequestId, cancellationToken);
                
                AnalyzeResponse(response, providerRequest, runContext);
                
                // Update the trace status based on all provider statuses
                trace.ReviewTraceStatus();
                
                // Persist changes to database
                await _repository.UpdateAsync(trace, cancellationToken);
                
                _logger.LogInformation("[RUN:{RunId}/REQ:{RequestId}][ProviderSynchronizer] Updated provider {Provider} status to {Status} for message REQ:{RequestId}", runId, trace.RequestId, providerRequest.ProviderName, providerRequest.Status, trace.RequestId);
            }
        }

        _logger.LogInformation("[RUN:{RunId}][ProviderSynchronizer] Finished provider status synchronization", runId);
    }

    private void AnalyzeResponse(GetStatusResponse? response, ProductCreationProvider providerRequest, RunContext runContext)
    {
        // Failed HttpRequest
        if (response == null)
        {
            _logger.LogWarning("[RUN:{RunId}/REQ:{RequestId}][ProviderSynchronizer] GetStatus Request FAILED for provider: {Provider}", 
                runContext.RunId, runContext.RequestId, providerRequest.ProviderName);
            return;
        }

        _logger.LogInformation("[RUN:{RunId}/REQ:{RequestId}][ProviderSynchronizer] Provider {Provider} returned status success: {Success} for Request REQ:{RequestId}", 
            runContext.RunId, runContext.RequestId, providerRequest.ProviderName, response.Success, runContext.RequestId);

        // Update fields if provided
        if (response.ExternalProductCode != null) providerRequest.ExternalProductCode = response.ExternalProductCode;
        if (response.ExternalRequestId != null) providerRequest.ExternalRequestId = response.ExternalRequestId;
        providerRequest.ErrorMessage = response.ErrorMessage;
        
        if (response.Status.HasValue)
        {
            providerRequest.Status = response.Status.Value;
        }
        else
        {
            // Legacy fallback if status is not explicitly set in response
            providerRequest.Status = response.Success ? ProductCreationProviderStatus.Created : ProductCreationProviderStatus.Failed;
        }

        providerRequest.UpdatedAt = DateTime.UtcNow;

        // Log specific states as in legacy code
        if (providerRequest.Status == ProductCreationProviderStatus.Ack)
        {
            _logger.LogWarning("[RUN:{RunId}/REQ:{RequestId}][ProviderSynchronizer] ## CreateRic Request found, but NOT YET SUCCEED for provider: {Provider}", 
                runContext.RunId, runContext.RequestId, providerRequest.ProviderName);
        }
        else if (providerRequest.Status == ProductCreationProviderStatus.Created)
        {
             _logger.LogInformation("[RUN:{RunId}/REQ:{RequestId}][ProviderSynchronizer] ## Provider {Provider} SUCCEED", 
                runContext.RunId, runContext.RequestId, providerRequest.ProviderName);
        }
    }
}
