using System;
using System.Threading;
using System.Threading.Tasks;
using ContribFactoryApi.Application.ProductCreation.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ContribFactoryApi.Application.ProductCreation.ProviderSynchronizer;

/// <summary>
/// Background worker that periodically triggers provider status synchronization
/// </summary>
public class SynchronizationBackgroundService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<SynchronizationBackgroundService> _logger;
    private readonly ProviderSynchronizerOptions _options;

    public SynchronizationBackgroundService(
        IServiceProvider serviceProvider,
        IOptions<ProviderSynchronizerOptions> options,
        ILogger<SynchronizationBackgroundService> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
        _options = options.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Synchronization Background Service is starting.");

        var interval = TimeSpan.FromMinutes(_options.IntervalMinutes);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                _logger.LogInformation("Starting periodic provider synchronization.");

                using var scope = _serviceProvider.CreateScope();
                var synchronizer = scope.ServiceProvider.GetRequiredService<IProviderSynchronizerService>();
                
                await synchronizer.SynchronizeAsync();

                _logger.LogInformation("Periodic provider synchronization finished.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during periodic provider synchronization.");
            }

            // Wait for the next interval
            await Task.Delay(interval, stoppingToken);
        }

        _logger.LogInformation("Synchronization Background Service is stopping.");
    }
}
