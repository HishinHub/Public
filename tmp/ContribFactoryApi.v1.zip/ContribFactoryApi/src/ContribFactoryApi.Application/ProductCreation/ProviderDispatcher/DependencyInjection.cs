using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using ContribFactoryApi.Application.ProductCreation.Interfaces;

namespace ContribFactoryApi.Application.ProductCreation.ProviderDispatcher;

public static class DependencyInjection
{
    public static IServiceCollection AddProviderDispatcher(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<ProviderDispatcherOptions>()
            .Bind(configuration.GetSection(ProviderDispatcherOptions.SectionName))
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddScoped<IProviderDispatcherMapper, ProviderDispatcherMapper>();
        services.AddScoped<IProviderDispatcherService, ProviderDispatcherService>();

        services.AddHostedService<ProviderDispatcherBackgroundService>();
        
        return services;
    }
}
