using System.Diagnostics;
using ContribFactoryApi.Application.ProductCreation.Interfaces;
using ContribFactoryApi.Domain.ProductCreation;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace ContribFactoryApi.Application.ProductCreation.ProviderDispatcher;

/// <summary>
/// Background worker that consumes messages from the in-memory queue and dispatches them to providers
/// </summary>
public class ProviderDispatcherBackgroundService : BackgroundService
{
    private readonly IMessageQueueService<ProductCreationMessage> _messageQueue;
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<ProviderDispatcherBackgroundService> _logger;

    public ProviderDispatcherBackgroundService(
        IMessageQueueService<ProductCreationMessage> messageQueue,
        IServiceProvider serviceProvider,
        ILogger<ProviderDispatcherBackgroundService> logger)
    {
        _messageQueue = messageQueue;
        _serviceProvider = serviceProvider;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Provider Dispatcher Background Service is starting.");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                // Read message from the queue
                var message = await _messageQueue.ReadMessageAsync(stoppingToken);

                var requestId = message?.RequestId ?? "Unknown";
                using var activity = Instrumentation.ActivitySource.StartActivity(Instrumentation.Activities.ProcessProductCreationBackgroundJob);
                activity?.SetTag(Instrumentation.Tags.CorrelationId, requestId);

                try
                {
                    _logger.LogInformation("[REQ:{RequestId}][ProviderDispatcher] Processing message from queue.", requestId);

                    // Scope is needed because IProviderDispatcherService depends on scoped services
                    using var scope = _serviceProvider.CreateScope();
                    var providerDispatcherService = scope.ServiceProvider.GetRequiredService<IProviderDispatcherService>();

                    await providerDispatcherService.DispatchAsync(message!);

                    _logger.LogInformation("[REQ:{RequestId}][ProviderDispatcher] Message processed successfully.", requestId);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "[REQ:{RequestId}][ProviderDispatcher] Error processing background job", requestId);
                    activity?.SetTag(Instrumentation.Tags.OtelStatusCode, "ERROR");
                    activity?.SetTag(Instrumentation.Tags.OtelStatusDescription, ex.Message);
                    
                    // Add a small delay to prevent tight loop in case of persistent errors
                    await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
                }
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Provider Dispatcher Background Service is shutting down normally.");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Fatal error occurred in Provider Dispatcher Background Service loop.");
                
                // Add a small delay to prevent tight loop in case of persistent errors
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }

        _logger.LogInformation("Provider Dispatcher Background Service is stopping.");
    }
}
