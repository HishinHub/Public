-- Reset database for clean state
USE master;
DROP DATABASE [ProductCreation];

-- Query the main product creation traces (batches)
SELECT TOP (1000) [Id]
      ,[RequestId]
      ,[OriginalRequest]
      ,[Status]
      ,[CreatedAt]
      ,[UpdatedAt]
  FROM [ProductCreation].[dbo].[ProductCreationTraces]

-- Query individual provider requests within batches
SELECT TOP (1000) [Id]
      ,[ProviderName]
      ,[ProductCode]
      ,[Status]
      ,[ProviderRequestId]
      ,[ExternalRequestId]
      ,[ExternalProductCode]
      ,[ErrorMessage]
      ,[CreatedAt]
      ,[UpdatedAt]
      ,[ProductCreationTraceId]
  FROM [ProductCreation].[dbo].[ProductCreationProviders]

-- Join traces and providers to see full context
SELECT * FROM ProductCreationTraces TR
  JOIN ProductCreationProviders PR ON TR.Id = PR.ProductCreationTraceId

-- Simulate a successful provider creation (manual update for testing)
UPDATE ProductCreationProviders
    SET Status = 'CREATED',
        UpdatedAt = GETDATE(),
        ExternalProductCode = 'MYPROD123',
        ExternalRequestId = 'REFXXX',
        ErrorMessage = NULL
    WHERE ProviderRequestId = 'REF.7N_gQKFQD_H2A0HiwKY0l'

