using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;

namespace ContribFactoryApi.Application.ProductCreationOrchestrator;

/// <summary>
/// Mapper for translating product creation domain entities directly to API DTOs.
/// </summary>
public static class ProductCreationMapper
{
    /// <summary>
    /// Maps a trace and its providers directly into a ProductCreationApiGroupResponse.
    /// </summary>
    public static ProductCreationApiGroupResponse MapToApiGroup(ProductCreationTrace trace, IEnumerable<ProductCreationProvider> providerRequests)
    {
        return new ProductCreationApiGroupResponse
        {
            RequestId = trace.RequestId,
            CreatedAt = trace.CreatedAt,
            TraceStatus = trace.Status.ToString(),
            TraceStatusId = (int)trace.Status,
            ProviderRequests = providerRequests.Select(p => MapToApiStep(p, trace)).ToList()
        };
    }

    /// <summary>
    /// Maps a single provider record and its trace directly into a ProductCreationApiResponse.
    /// </summary>
    public static ProductCreationApiResponse MapToApiStep(ProductCreationProvider p, ProductCreationTrace? trace = null)
    {
        var effectiveTrace = trace ?? p.Trace;
        return new ProductCreationApiResponse
        {
            RequestId = effectiveTrace.RequestId,
            ProductCode = p.ProductCode,
            ProviderRequestId = p.ProviderRequestId,
            Provider = p.ProviderName.ToString(),
            ProviderId = (int)p.ProviderName,
            Status = p.Status.ToString(),
            StatusId = (int)p.Status,
            ErrorMessage = p.ErrorMessage,
            CreatedAt = p.CreatedAt
        };
    }
}
