using ContribFactoryApi.Application.Interfaces;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using Microsoft.Extensions.Options;
using ContribFactoryApi.Application.ProviderDispatcher;

namespace ContribFactoryApi.Application.ProductCreationOrchestrator;

/// <summary>
/// Factory for creating product creation domain entities
/// </summary>
public interface IProductCreationFactory
{
    /// <summary>
    /// Creates a new ProductCreationTrace with its associated provider records
    /// </summary>
    ProductCreationTrace CreateTrace(ProductCreationRequest request, string requestId);

    /// <summary>
    /// Creates provider records associated with the trace based on configuration and requested providers
    /// </summary>
    List<ProductCreationProvider> CreateProviders(ProductCreationTrace trace);

    /// <summary>
    /// Creates a ProductCreationMessage for background processing.
    /// </summary>
    ProductCreationMessage CreateMessage(ProductCreationTrace trace);
}

/// <summary>
/// Factory for creating product creation domain entities
/// </summary>
public class ProductCreationFactory : IProductCreationFactory
{
    private readonly TimeProvider _timeProvider;
    private readonly IIdGenerator _idGenerator;
    private readonly ProviderDispatcherOptions _dispatcherOptions;

    public ProductCreationFactory(
        TimeProvider timeProvider, 
        IIdGenerator idGenerator, 
        IOptions<ProviderDispatcherOptions> options)
    {
        _timeProvider = timeProvider;
        _idGenerator = idGenerator;
        _dispatcherOptions = options.Value;
    }

    /// <summary>
    /// Creates a new ProductCreationTrace with its associated provider records
    /// </summary>
    public ProductCreationTrace CreateTrace(ProductCreationRequest request, string requestId)
    {
        var now = _timeProvider.GetUtcNow().UtcDateTime;

        var trace = new ProductCreationTrace
        {
            RequestId = requestId,
            OriginalRequest = request,
            Status = ProductCreationTraceStatus.None,
            CreatedAt = now,
            UpdatedAt = now
        };

        return trace;
    }

    /// <summary>
    /// Creates provider records associated with the trace based on configuration and requested providers
    /// </summary>
    public List<ProductCreationProvider> CreateProviders(ProductCreationTrace trace)
    {
        var now = _timeProvider.GetUtcNow().UtcDateTime;
        var request = trace.OriginalRequest;

        var enabledProviders = _dispatcherOptions.EnabledProviders;
        var providerRequests = new List<ProductCreationProvider>();

        foreach (var payload in request.Payload)
        {
            foreach (var pName in payload.GetEffectiveProviders(request))
            {
                var newProviderRequest = new ProductCreationProvider
                {
                    ProductCode = payload.ProductCode,
                    CreatedAt = now,
                    UpdatedAt = now,
                    Status = ProductCreationProviderStatus.Received,
                    ProductPayload = payload,
                    Trace = trace
                };

                if (Enum.TryParse<ProviderName>(pName, true, out var provider))
                {
                    newProviderRequest.ProviderName = provider;
                    newProviderRequest.ProviderRequestId = $"{provider.GetTrigram()}.{_idGenerator.NewId()}";
                    
                    if (!enabledProviders.Contains(provider))
                    {
                        newProviderRequest.Status = ProductCreationProviderStatus.DisabledProvider;
                        newProviderRequest.ErrorMessage = $"Provider {provider} is disabled in configuration";
                    }
                }
                else
                {
                    newProviderRequest.Status = ProductCreationProviderStatus.UnsupportedProvider;
                    newProviderRequest.ErrorMessage = $"Unsupported provider: {pName}";
                }

                providerRequests.Add(newProviderRequest);
            }
        }
        trace.ProviderRequests = providerRequests;

        return providerRequests;
    }

    /// <summary>
    /// Creates a ProductCreationMessage for background processing.
    /// </summary>
    public ProductCreationMessage CreateMessage(ProductCreationTrace trace)
    {
        return new ProductCreationMessage
        {
            RequestId = trace.RequestId,
            CreatedAt = _timeProvider.GetUtcNow().UtcDateTime
        };
    }

}
