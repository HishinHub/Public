using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryApi.Application.Interfaces;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace ContribFactoryApi.Application.ProviderDispatcher;

public interface IProviderDispatcherMapper
{
    void MapToProductCreationProvider(
        string requestId,
        ProductCreationProvider providerRequest,
        SendRequestResponse response,
        StatsContext statsContext);
}

public class ProviderDispatcherMapper : IProviderDispatcherMapper
{
    private readonly ILogger<ProviderDispatcherMapper> _logger;

    public ProviderDispatcherMapper(ILogger<ProviderDispatcherMapper> logger)
    {
        _logger = logger;
    }

    public void MapToProductCreationProvider(
        string requestId,
        ProductCreationProvider providerRequest,
        SendRequestResponse response,
        StatsContext statsContext)
    {
        providerRequest.ExternalRequestId = response.ExternalRequestId;
        providerRequest.ExternalProductCode = response.ExternalProductCode;
        providerRequest.ErrorMessage = response.ErrorMessage;

        if (response.Success)
        {
            providerRequest.Status = ProductCreationProviderStatus.Sent;
            statsContext.SentCount++;

            _logger.LogInformation(
                "[REQ:{RequestId}/{ProviderRequestId}][ProviderDispatcher] Successfully dispatched to {Provider}. ExternalRequestId: {ExternalRequestId}",
                requestId,
                providerRequest.ProviderRequestId,
                providerRequest.ProviderName,
                response.ExternalRequestId);
        }
        else
        {
            providerRequest.Status = ProductCreationProviderStatus.ProviderFailed;
            statsContext.FailedCount++;

            var activity = Activity.Current;
            activity?.SetTag(Instrumentation.Tags.OtelStatusCode, "ERROR");
            activity?.SetTag(Instrumentation.Tags.OtelStatusDescription, response.ErrorMessage);

            _logger.LogWarning(
                "[REQ:{RequestId}/{ProviderRequestId}][ProviderDispatcher] Failed to dispatch to {Provider}: {ErrorMessage}",
                requestId,
                providerRequest.ProviderRequestId,
                providerRequest.ProviderName,
                response.ErrorMessage);
        }

        providerRequest.UpdatedAt = DateTime.UtcNow;

        _logger.LogInformation(
            "[REQ:{RequestId}/{ProviderRequestId}][ProviderDispatcher] Updated provider {Provider} status to {Status}",
            requestId,
            providerRequest.ProviderRequestId,
            providerRequest.ProviderName,
            providerRequest.Status);
    }
}
