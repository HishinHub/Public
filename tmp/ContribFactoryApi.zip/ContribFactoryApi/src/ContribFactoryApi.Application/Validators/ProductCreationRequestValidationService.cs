using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.Extensions.Logging;

namespace ContribFactoryApi.Application.Validators;

/// <summary>
/// Orchestrates validation of a <see cref="ProductCreationRequest"/>
/// </summary>
public class ProductCreationRequestValidationService
{
    private readonly IValidator<ProductCreationRequest> _genericValidator;
    private readonly IEnumerable<IProviderRequestValidator> _providerValidators;
    private readonly ILogger<ProductCreationRequestValidationService> _logger;

    public ProductCreationRequestValidationService(
        IValidator<ProductCreationRequest> genericValidator,
        IEnumerable<IProviderRequestValidator> providerValidators,
        ILogger<ProductCreationRequestValidationService> logger)
    {
        _genericValidator = genericValidator;
        _providerValidators = providerValidators;
        _logger = logger;
    }

    /// <summary>
    /// Validates the request generically and then per-provider.
    /// </summary>
    public async Task ValidateAsync(
        ProductCreationTrace message,
        CancellationToken cancellationToken = default)
    {
        var request = message.OriginalRequest;

        // 1. Generic validation
        var genericResult = await _genericValidator.ValidateAsync(request, cancellationToken);
        if (!genericResult.IsValid)
        {
            _logger.LogWarning(
                "[REQ:{RequestId}][Validation] Generic validation failed for request REQ:{RequestId}: {Errors}",
                message.RequestId, message.RequestId,
                string.Join("; ", genericResult.Errors.Select(e => e.ErrorMessage)));

            throw new ValidationException(genericResult.Errors);
        }

        // 2. Provider-specific validation
        var allProviderErrors = new List<ValidationFailure>();

        foreach (var providerName in request.DefaultProviders)
        {
            if (!Enum.TryParse<ProviderName>(providerName, ignoreCase: true, out var provider))
            {
                continue;
            }

            var providerValidator = _providerValidators
                .FirstOrDefault(v => v.Provider == provider);

            if (providerValidator is null)
            {
                continue;
            }

            var providerResult = await providerValidator.ValidateAsync(request, cancellationToken);
            if (!providerResult.IsValid)
            {
                _logger.LogWarning(
                    "[REQ:{RequestId}][Validation] {Provider} validation failed for request REQ:{RequestId}: {Errors}",
                    message.RequestId, provider, message.RequestId,
                    string.Join("; ", providerResult.Errors.Select(e => e.ErrorMessage)));

                allProviderErrors.AddRange(providerResult.Errors);
            }
        }

        if (allProviderErrors.Count > 0)
        {
            throw new ValidationException(allProviderErrors);
        }

        _logger.LogInformation(
            "[REQ:{RequestId}][Validation] All validations passed for request REQ:{RequestId}",
            message.RequestId, message.RequestId);
    }
}
