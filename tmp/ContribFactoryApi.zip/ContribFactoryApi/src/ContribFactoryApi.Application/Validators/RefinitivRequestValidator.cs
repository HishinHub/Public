using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using FluentValidation;
using FluentValidation.Results;

namespace ContribFactoryApi.Application.Validators;

/// <summary>
/// Validates a <see cref="ProductCreationRequest"/> against Refinitiv-specific rules.
/// </summary>
public class RefinitivRequestValidator : AbstractValidator<ProductCreationRequest>, IProviderRequestValidator
{
    public ProviderName Provider => ProviderName.Refinitiv;

    public RefinitivRequestValidator()
    {
        RuleFor(x => x.Payload)
            .NotEmpty()
            .WithMessage("Payload must not be empty for Refinitiv requests.");

        // Validate the first payload item (RefinitivMapper only processes payload[0])
        RuleFor(x => x.Payload)
            .Custom((payloads, context) =>
            {
                if (payloads == null || payloads.Count == 0) return;

                var payload = payloads[0];

                if (string.IsNullOrWhiteSpace(payload.ProductName))
                    context.AddFailure("Payload[0].ProductName", "Product Name is required for Refinitiv.");

                if (string.IsNullOrWhiteSpace(payload.ProductCode))
                    context.AddFailure("Payload[0].ProductCode", "Product Code (ISIN) is required for Refinitiv.");

                // Currency from direct property
                if (string.IsNullOrWhiteSpace(payload.Currency))
                    context.AddFailure("Payload[0].Currency", "Currency is mandatory for Refinitiv.");

                // Coupon from direct property
                if (!payload.Coupon.HasValue)
                    context.AddFailure("Payload[0].Coupon", "Coupon is mandatory and must be a valid number for Refinitiv.");

                // MaturityDate from direct property
                if (!payload.MaturityDate.HasValue)
                    context.AddFailure("Payload[0].MaturityDate", "Maturity Date is mandatory and must be a valid date for Refinitiv.");
            });
    }

    async Task<ValidationResult> IProviderRequestValidator.ValidateAsync(
        ProductCreationRequest request,
        CancellationToken cancellationToken)
        => await this.ValidateAsync(request, cancellationToken);
}
