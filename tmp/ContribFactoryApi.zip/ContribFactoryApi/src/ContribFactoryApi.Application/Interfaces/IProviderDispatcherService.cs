using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryApi.Domain.ProductCreation;

namespace ContribFactoryApi.Application.Interfaces;

/// <summary>
/// Interface for provider dispatching services
/// </summary>
public interface IProviderDispatcherService
{
    /// <summary>
    /// Dispatches a product creation request to all specified providers in the product request
    /// </summary>
    Task DispatchAsync(
        ProductCreationMessage message,
        CancellationToken cancellationToken = default);
}
