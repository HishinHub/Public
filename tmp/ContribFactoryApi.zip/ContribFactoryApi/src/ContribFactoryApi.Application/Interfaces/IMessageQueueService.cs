using System.Runtime.Serialization;

namespace ContribFactoryApi.Application.Interfaces;

/// <summary>
/// Generic interface for message queue operations
/// </summary>
/// <typeparam name="T">The type of message</typeparam>
public interface IMessageQueueService<T> where T : ISerializable
{
    /// <summary>
    /// Sends a message to the queue
    /// </summary>
    /// <returns>A unique identifier for the queued message</returns>
    Task<string> SendMessageAsync(T message, CancellationToken cancellationToken = default);

    /// <summary>
    /// Reads a message from the queue.
    /// </summary>
    Task<T> ReadMessageAsync(CancellationToken cancellationToken = default);
}
