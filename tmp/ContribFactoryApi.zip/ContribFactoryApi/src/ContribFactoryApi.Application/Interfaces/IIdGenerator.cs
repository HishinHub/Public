namespace ContribFactoryApi.Application.Interfaces;

/// <summary>
/// Interface for generating unique identifiers
/// </summary>
public interface IIdGenerator
{
    /// <summary>
    /// Generates a new unique identifier as a string
    /// </summary>
    /// <returns>A unique identifier string</returns>
    string NewId();
}
