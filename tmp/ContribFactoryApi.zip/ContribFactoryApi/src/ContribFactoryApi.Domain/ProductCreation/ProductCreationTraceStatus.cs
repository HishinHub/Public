namespace ContribFactoryApi.Domain.ProductCreation;

/// <summary>
/// Status for the overall product creation message/batch
/// </summary>
public enum ProductCreationTraceStatus
{
    /// <summary>
    /// No status assigned yet
    /// </summary>
    None = 0,

    /// <summary>
    /// Product request received by the system
    /// </summary>
    Received = 1,
    
    /// <summary>
    /// Product has passed validation
    /// </summary>
    OnGoing = 2,

    /// <summary>
    /// Product is being processed
    /// </summary>
    ProviderInCharge = 3,

    /// <summary>
    /// All product creation steps completed successfully
    /// </summary>
    Completed = 10,

    /// <summary>
    /// Technical error occurred (final state)
    /// </summary>
    ProviderFailed = 50,

    /// <summary>
    /// Technical error occurred (final state)
    /// </summary>
    TechnicalFailed = -1
}
