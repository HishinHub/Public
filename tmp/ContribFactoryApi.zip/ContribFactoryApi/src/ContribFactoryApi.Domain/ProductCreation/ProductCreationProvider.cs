using System;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using System.Text.Json.Serialization;

namespace ContribFactoryApi.Domain.ProductCreation;

/// <summary>
/// Represents the status and details of a product creation for a specific provider
/// </summary>
public class ProductCreationProvider
{
    /// <summary>
    /// Database primary key (autoincrement)
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// The provider
    /// </summary>
    public ProviderName ProviderName { get; set; }

    /// <summary>
    /// The specific product code from the payload this provider record applies to
    /// </summary>
    public string ProductCode { get; set; } = string.Empty;

    /// <summary>
    /// Current status for this provider
    /// </summary>
    public ProductCreationProviderStatus Status { get; set; }

    /// <summary>
    /// The product payload for this provider
    /// </summary>
    public ProductPayload ProductPayload { get; set; } = new();

    /// <summary>
    /// Unique Request ID for this provider (Message.RequestId.Trigram)
    /// </summary>
    public string ProviderRequestId { get; set; } = string.Empty;

    /// <summary>
    /// External Request ID assigned by the provider (if available)
    /// </summary>
    public string? ExternalRequestId { get; set; }

    /// <summary>
    /// External product code or identifier assigned by the provider
    /// </summary>
    public string? ExternalProductCode { get; set; }

    /// <summary>
    /// Error message if the request failed for this provider
    /// </summary>
    public string? ErrorMessage { get; set; }

    /// <summary>
    /// When this provider record was created
    /// </summary>
    public DateTime CreatedAt { get; set; }

    /// <summary>
    /// When this provider record was last updated
    /// </summary>
    public DateTime UpdatedAt { get; set; }

    /// <summary>
    /// Foreign key to the parent ProductCreationTrace
    /// </summary>
    public int ProductCreationTraceId { get; set; }

    /// <summary>
    /// Navigation property to the parent trace (not serialized by System.Text.Json to prevent circular references)
    /// </summary>
    [JsonIgnore]
    public ProductCreationTrace Trace { get; set; } = null!;

    /// <summary>
    /// Indicates whether the provider has reached a final state (Created or Rejected).
    /// </summary>
    public bool IsAlreadyProcessed() => 
        Status is ProductCreationProviderStatus.Created or ProductCreationProviderStatus.Rejected;

    /// <summary>
    /// Indicates whether the provider is disabled (not present in the enabled providers list).
    /// </summary>
    public bool IsDisabled(IEnumerable<ProviderName> enabledProviders) =>
        !enabledProviders.Contains(ProviderName);
}
