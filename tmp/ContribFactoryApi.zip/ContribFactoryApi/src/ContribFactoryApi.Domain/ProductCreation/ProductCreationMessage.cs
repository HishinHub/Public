using System.Runtime.Serialization;

namespace ContribFactoryApi.Domain.ProductCreation;

/// <summary>
/// Domain message representing a product creation request to be dispatched.
/// </summary>
public record ProductCreationMessage : ISerializable
{
    public string RequestId { get; init; } = null!;
    public DateTime CreatedAt { get; init; }

    public ProductCreationMessage() { }

    protected ProductCreationMessage(SerializationInfo info, StreamingContext context)
    {
        RequestId = info.GetString(nameof(RequestId)) ?? string.Empty;
        CreatedAt = info.GetDateTime(nameof(CreatedAt));
    }

    public void GetObjectData(SerializationInfo info, StreamingContext context)
    {
        info.AddValue(nameof(RequestId), RequestId);
        info.AddValue(nameof(CreatedAt), CreatedAt);
    }
}
