namespace ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;

/// <summary>
/// Wraps all provider responses under a single trace-level response.
/// </summary>
public record ProductCreationApiGroupResponse
{
    /// <summary>
    /// The parent request ID shared by all provider entries
    /// </summary>
    public string RequestId { get; init; } = string.Empty;

    /// <summary>
    /// When the product creation trace was created
    /// </summary>
    public DateTime CreatedAt { get; init; }

    /// <summary>
    /// Overall status of the product creation trace/batch formatted as "Status (id)"
    /// </summary>
    public string TraceStatus { get; init; } = string.Empty;

    /// <summary>
    /// Raw integer value of the overall trace status enum
    /// </summary>
    public int TraceStatusId { get; init; }

    /// <summary>
    /// Individual provider-level responses
    /// </summary>
    public List<ProductCreationApiResponse> ProviderRequests { get; init; } = [];

}
