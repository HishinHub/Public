namespace ContribFactoryApi.Domain.ProductCreation;

public class StatsContext
{
    public int SentCount { get; set; }
    public int FailedCount { get; set; }
}
