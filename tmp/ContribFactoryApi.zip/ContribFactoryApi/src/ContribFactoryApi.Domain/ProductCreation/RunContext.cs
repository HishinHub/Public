namespace ContribFactoryApi.Domain.ProductCreation;

/// <summary>
/// Contains the execution context details for a provider request
/// </summary>
public record RunContext
{
    public string RequestId { get; init; } = string.Empty;
    public string ProviderRequestId { get; init; } = string.Empty;
    public string RunId { get; init; } = string.Empty;
}
