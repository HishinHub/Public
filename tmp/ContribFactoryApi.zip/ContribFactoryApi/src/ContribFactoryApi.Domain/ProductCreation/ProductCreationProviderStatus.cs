namespace ContribFactoryApi.Domain.ProductCreation;

/// <summary>
/// Status for a specific provider in the product creation workflow
/// </summary>
public enum ProductCreationProviderStatus
{
    /// <summary>
    /// No status assigned yet
    /// </summary>
    None = 0,

    /// <summary>
    /// No status assigned yet
    /// </summary>
    Received = 1,

    /// <summary>
    /// Product information sent to provider
    /// </summary>
    Sent = 2,
    
    /// <summary>
    /// Provider acknowledgment received
    /// </summary>
    Ack = 3,

    /// <summary>
    /// Product successfully created (final state)
    /// </summary>
    Created = 10,
    
    /// <summary>
    /// Product rejected due to functional errors (final state)
    /// </summary>
    Rejected = 50,

    /// <summary>
    /// Product canceled (final state)
    /// </summary>
    Canceled = 51,

    /// <summary>
    /// Technical error occurred (final state)
    /// </summary>
    Failed = -1,

    /// <summary>
    /// Technical error occurred (final state)
    /// </summary>
    ProviderFailed = -2,

    /// <summary>
    /// Unsupported provider excluded (final state)
    /// </summary>
    UnsupportedProvider = -3,

    /// <summary>
    /// Disabled provider excluded (final state)
    /// </summary>
    DisabledProvider = -4,
}
