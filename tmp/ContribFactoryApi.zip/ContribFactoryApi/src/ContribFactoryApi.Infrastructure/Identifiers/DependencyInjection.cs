using ContribFactoryApi.Application.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryApi.Infrastructure.Identifiers;

public static class DependencyInjection
{
    public static IServiceCollection AddIdentifiers(this IServiceCollection services)
    {
        // Register Guid as the default IIdGenerator
        services.AddSingleton<IIdGenerator, GuidGenerator>();
        
        return services;
    }
}
