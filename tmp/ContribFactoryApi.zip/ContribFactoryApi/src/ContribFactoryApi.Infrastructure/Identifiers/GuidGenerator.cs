using System;
using ContribFactoryApi.Application.Interfaces;

namespace ContribFactoryApi.Infrastructure.Identifiers;

/// <summary>
/// Generator for GUID identifiers (returned as string)
/// </summary>
public class GuidGenerator : IIdGenerator
{
    public string NewId() => Guid.NewGuid().ToString();

    /// <summary>
    /// Static helper for cases where Guid type is specifically needed
    /// </summary>
    public static Guid NewGuid() => Guid.NewGuid();
}
