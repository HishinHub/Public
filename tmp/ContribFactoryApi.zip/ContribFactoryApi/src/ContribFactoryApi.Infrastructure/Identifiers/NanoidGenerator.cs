using System;
using NanoidDotNet;
using ContribFactoryApi.Application.Interfaces;

namespace ContribFactoryApi.Infrastructure.Identifiers;

/// <summary>
/// Generator for NanoID identifiers
/// </summary>
public class NanoidGenerator : IIdGenerator
{
    public string NewId() => Nanoid.Generate();
}
