using System.ComponentModel.DataAnnotations;

namespace ContribFactoryApi.Infrastructure.OpenTelemetry;

public class OpenTelemetryOptions
{
    public const string SectionName = "OpenTelemetry";

    /// <summary>
    /// OTLP gRPC endpoint (e.g. http://localhost:18889 for Aspire dashboard).
    /// When null or empty, OTLP export is disabled.
    /// </summary>
    public string? Endpoint { get; set; }

    /// <summary>
    /// Whether OTLP export is active.
    /// </summary>
    public bool IsEnabled => !string.IsNullOrWhiteSpace(Endpoint);
}
