using ContribFactoryApi.Application;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OpenTelemetry.Exporter;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using Serilog;
using Serilog.Enrichers.Span;

namespace ContribFactoryApi.Infrastructure.OpenTelemetry;

public static class DependencyInjection
{
    /// <summary>
    /// Registers OpenTelemetry tracing + metrics (OTel SDK) and configures the Serilog OTLP sink,
    /// all pointing to the same endpoint from <see cref="OpenTelemetryOptions"/>.
    /// </summary>
    public static IServiceCollection AddOpenTelemetryInstrumentation(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<OpenTelemetryOptions>(
            configuration.GetSection(OpenTelemetryOptions.SectionName));

        var otelOptions = configuration
            .GetSection(OpenTelemetryOptions.SectionName)
            .Get<OpenTelemetryOptions>() ?? new OpenTelemetryOptions();

        var resourceBuilder = ResourceBuilder
            .CreateDefault()
            .AddService(Instrumentation.WebApiServiceName);

        services.AddOpenTelemetry()
            .WithTracing(tracing =>
            {
                tracing
                    .SetResourceBuilder(resourceBuilder)
                    .AddSource(Instrumentation.ServiceName)
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddEntityFrameworkCoreInstrumentation();

                if (otelOptions.IsEnabled)
                    tracing.AddOtlpExporter(o =>
                    {
                        o.Endpoint = new Uri(otelOptions.Endpoint!);
                        o.Protocol = OtlpExportProtocol.Grpc;
                    });
            })
            .WithMetrics(metrics =>
            {
                metrics
                    .SetResourceBuilder(resourceBuilder)
                    .AddMeter(Instrumentation.ServiceName)
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddRuntimeInstrumentation();

                if (otelOptions.IsEnabled)
                    metrics.AddOtlpExporter(o =>
                    {
                        o.Endpoint = new Uri(otelOptions.Endpoint!);
                        o.Protocol = OtlpExportProtocol.Grpc;
                    });
            });

        return services;
    }

    /// <summary>
    /// Configures the Serilog host to include the OTLP sink using the same
    /// <see cref="OpenTelemetryOptions"/> endpoint.
    /// Call this inside <c>builder.Host.UseSerilog()</c>.
    /// </summary>
    public static LoggerConfiguration AddOpenTelemetrySink(
        this LoggerConfiguration loggerConfiguration,
        OpenTelemetryOptions otelOptions)
    {
        loggerConfiguration.Enrich.WithSpan();

        if (otelOptions.IsEnabled)
        {
            loggerConfiguration.WriteTo.OpenTelemetry(options =>
            {
                options.Endpoint = otelOptions.Endpoint!;
                options.Protocol = Serilog.Sinks.OpenTelemetry.OtlpProtocol.Grpc;
                options.ResourceAttributes = new Dictionary<string, object>
                {
                    ["service.name"] = Instrumentation.WebApiServiceName
                };
            });
        }

        return loggerConfiguration;
    }
}
