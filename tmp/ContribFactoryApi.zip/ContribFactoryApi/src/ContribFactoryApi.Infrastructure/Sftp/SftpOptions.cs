using System.ComponentModel.DataAnnotations;
using ContribFactoryApi.Infrastructure.Authentication;

namespace ContribFactoryApi.Infrastructure.Sftp
{
    public class SftpOptions
    {
        public const string SectionName = "Sftp";

        [Required]
        public string Host { get; set; } = string.Empty;
        
        [Range(1, 65535)]
        public int Port { get; set; } = 22;
        
        [Required]
        public string User { get; set; } = string.Empty;
        
        [Required]
        public string Password { get; set; } = string.Empty;
        
        public string SshHostKey { get; set; } = string.Empty;

        public ProxyOptions Proxy { get; set; } = new();
    }
}

