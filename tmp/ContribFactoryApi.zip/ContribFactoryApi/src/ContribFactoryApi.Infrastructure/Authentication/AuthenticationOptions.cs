using System.ComponentModel.DataAnnotations;

namespace ContribFactoryApi.Infrastructure.Authentication;

/// <summary>
/// Root authentication configuration options
/// </summary>
public class AuthenticationOptions
{
    public const string SectionName = "Authentication";

    /// <summary>JWT settings for OAuth2 token issuance and validation</summary>
    public JwtOptions Jwt { get; set; } = new();

    /// <summary>Proxy settings for external communication</summary>
    public ProxyOptions Proxy { get; set; } = new();

    /// <summary>Service account credentials</summary>
    public SvcAccountOptions SvcAccount { get; set; } = new();

    /// <summary>Identity settings for credentials validation</summary>
    public IdentityOptions Identity { get; set; } = new();
}

/// <summary>
/// JWT token options
/// </summary>
public class JwtOptions
{
    public const string SectionName = $"{AuthenticationOptions.SectionName}:Jwt";

    /// <summary>Signing key – keep this secret and at least 32 characters long</summary>
    [Required(AllowEmptyStrings = false)]
    public string SecretKey { get; set; } = null!;

    /// <summary>Token issuer (iss claim)</summary>
    public string Issuer { get; set; } = "ContribFactoryApi";

    /// <summary>Token audience (aud claim)</summary>
    public string Audience { get; set; } = null!;

    /// <summary>Token lifetime in minutes (default 60)</summary>
    public int ExpirationMinutes { get; set; } = 60;
}

/// <summary>
/// Proxy settings
/// </summary>
public class ProxyOptions
{
    public const string SectionName = $"{AuthenticationOptions.SectionName}:Proxy";

    public string Host { get; set; } = string.Empty;
    public int Port { get; set; }
    public string User { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

/// <summary>
/// Service account credentials
/// </summary>
public class SvcAccountOptions
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

/// <summary>
/// Identity configuration options
/// </summary>
public class IdentityOptions
{
    public const string SectionName = $"{AuthenticationOptions.SectionName}:Identity";

    /// <summary>The identity client secret used for authentication</summary>
    [Required(AllowEmptyStrings = false)]
    public string ClientSecret { get; set; } = string.Empty;

    /// <summary>The expected client ID for authentication</summary>
    public string ClientId { get; set; } = "contribfactory-client";
}
