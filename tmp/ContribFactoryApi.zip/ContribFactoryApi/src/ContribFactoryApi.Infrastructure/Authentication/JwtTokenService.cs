using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace ContribFactoryApi.Infrastructure.Authentication;

/// <summary>
/// Request model for the token endpoint
/// </summary>
public record TokenRequest(string ClientId, string ClientSecret);

/// <summary>
/// Response returned by the token endpoint
/// </summary>
public record TokenResponse(string AccessToken, string TokenType, int ExpiresIn);

/// <summary>
/// Service that validates client credentials and issues JWT tokens (OAuth2 client_credentials grant)
/// </summary>
public class JwtTokenService
{
    private readonly IOptions<AuthenticationOptions> _options;

    public JwtTokenService(IOptions<AuthenticationOptions> options)
    {
        _options = options;
    }

    private AuthenticationOptions Options => _options.Value;

    /// <summary>
    /// Validates the client credentials and issues a JWT if they are correct.
    /// Returns null when the credentials are invalid.
    /// </summary>
    public TokenResponse? IssueToken(TokenRequest request)
    {
        // Now using values directly from the configured Identity section
        if (request.ClientId != Options.Identity.ClientId || request.ClientSecret != Options.Identity.ClientSecret)
        {
            return null;
        }

        return CreateToken(request.ClientId);
    }

    private TokenResponse CreateToken(string clientId)
    {
        var jwt = Options.Jwt;
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.SecretKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var now = DateTime.UtcNow;
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, clientId),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64),
            new Claim("client_id", clientId)
        };

        var token = new JwtSecurityToken(
            issuer: jwt.Issuer,
            audience: jwt.Audience,
            claims: claims,
            notBefore: now,
            expires: now.AddMinutes(jwt.ExpirationMinutes),
            signingCredentials: credentials);

        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
        return new TokenResponse(tokenString, "Bearer", jwt.ExpirationMinutes * 60);
    }
}
