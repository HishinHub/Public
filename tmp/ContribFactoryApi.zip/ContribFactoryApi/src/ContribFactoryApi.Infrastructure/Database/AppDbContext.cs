using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace ContribFactoryApi.Infrastructure.Database;

/// <summary>
/// Application database context
/// </summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<ProductCreationTrace> ProductCreationTraces => Set<ProductCreationTrace>();
    public DbSet<ProductCreationProvider> ProductCreationProviders => Set<ProductCreationProvider>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<ProductCreationTrace>(entity =>
        {
            entity.ToTable("ProductCreationTraces");
            
            entity.HasKey(e => e.Id);
            
            entity.HasIndex(e => e.RequestId)
                .IsUnique();
            
            entity.Property(e => e.RequestId)
                .IsRequired()
                .HasMaxLength(50);
            
            entity.Property(e => e.OriginalRequest)
                .IsRequired()
                .HasConversion(
                    v => JsonSerializer.Serialize<ProductCreationRequest>(v, (JsonSerializerOptions?)null),
                    v => JsonSerializer.Deserialize<ProductCreationRequest>(v, (JsonSerializerOptions?)null)!);
            
            entity.Property(e => e.Status)
                .IsRequired()
                .HasConversion(
                    v => v.ToString().ToUpper(),
                    v => (ProductCreationTraceStatus)Enum.Parse(typeof(ProductCreationTraceStatus), v, ignoreCase: true));

            entity.Property(e => e.CreatedAt)
                .IsRequired();

            entity.Property(e => e.UpdatedAt)
                .IsRequired();

            entity.HasMany(e => e.ProviderRequests)
                .WithOne(p => p.Trace)
                .HasForeignKey(p => p.ProductCreationTraceId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ProductCreationProvider>(entity =>
        {
            entity.ToTable("ProductCreationProviders");
            entity.HasKey(e => e.Id);
            
            entity.HasIndex(p => p.ProviderRequestId)
                .IsUnique();
                
            entity.Property(e => e.ProviderName)
                .IsRequired()
                .HasConversion(
                    v => v.ToString().ToUpper(),
                    v => (ProviderName)Enum.Parse(typeof(ProviderName), v, ignoreCase: true));
            
            entity.Property(e => e.Status)
                .IsRequired()
                .HasConversion(
                    v => v.ToString().ToUpper(),
                    v => (ProductCreationProviderStatus)Enum.Parse(typeof(ProductCreationProviderStatus), v, ignoreCase: true));
                        entity.Property(e => e.ProductPayload)
                .IsRequired()
                .HasConversion(
                    v => JsonSerializer.Serialize<ProductPayload>(v, (JsonSerializerOptions?)null),
                    v => JsonSerializer.Deserialize<ProductPayload>(v, (JsonSerializerOptions?)null)!);
            entity.Property(e => e.ProviderRequestId).IsRequired().HasMaxLength(100);
            entity.Property(e => e.ExternalRequestId).HasMaxLength(200);
            entity.Property(e => e.ExternalProductCode).HasMaxLength(200);
            entity.Property(e => e.CreatedAt).IsRequired();
            entity.Property(e => e.UpdatedAt).IsRequired();
            entity.Property(e => e.ErrorMessage).HasMaxLength(2000);
        });
    }
}
