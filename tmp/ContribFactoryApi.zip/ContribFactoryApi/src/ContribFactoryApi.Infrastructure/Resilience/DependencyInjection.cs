using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using ContribFactoryApi.Domain;

namespace ContribFactoryApi.Infrastructure.Resilience;


public static class DependencyInjection
{
    public static IServiceCollection AddResilience(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<ResilienceOptions>()
            .BindConfiguration(ResilienceOptions.SectionName)
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddResiliencePipeline(ApplicationContext.Resilience.RetryPipelineName, (builder, context) =>


        {
            var options = context.ServiceProvider.GetRequiredService<IOptions<ResilienceOptions>>().Value;

            builder.AddRetry(new RetryStrategyOptions
            {
                Name = ApplicationContext.Resilience.RetryPipelineName,

                ShouldHandle = new PredicateBuilder().Handle<Exception>(),
                MaxRetryAttempts = options.Retry.MaxRetryAttempts,
                Delay = TimeSpan.FromSeconds(options.Retry.DelaySeconds),

                BackoffType = DelayBackoffType.Exponential
            });
        });

        return services;
    }



}



