using System.ComponentModel.DataAnnotations;

namespace ContribFactoryApi.Infrastructure.Resilience;

public class ResilienceOptions
{
    public const string SectionName = "Resilience";

    [Required]
    public RetryOptions Retry { get; set; } = new();

    [Required]
    public RateLimitOptions RateLimit { get; set; } = new();
}

public class RetryOptions
{
    [Required]
    [Range(0, 10)]
    public int MaxRetryAttempts { get; set; } = 3;

    [Required]
    [Range(1, 60)]
    public int DelaySeconds { get; set; } = 2;
}

public class RateLimitOptions
{
    [Required]
    [Range(1, 1000)]
    public int PermitLimit { get; set; } = 10;

    [Required]
    [Range(1, 3600)]
    public int WindowSeconds { get; set; } = 1;

    [Required]
    [Range(0, 1000)]
    public int QueueLimit { get; set; } = 0;
}

