using ContribFactoryApi.Application.Interfaces;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi;
using Microsoft.Extensions.Options;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv;

/// <summary>
/// Interface for Refinitiv-specific request and response mapping
/// </summary>
public interface IRefinitivMapper
{
    /// <summary>
    /// Converts a ProductPayload to a SendRicCreationRequest
    /// </summary>
    SendRicCreationRequest ToSendRicCreationRequest(ProductPayload payload, RunContext runContext);

    /// <summary>
    /// Maps a CreateRicResponse from the Refinitiv API to a generic ProviderResponse
    /// </summary>
    SendRequestResponse ToProviderResponse(CreateRicResponse? result, string productCode);

    /// <summary>
    /// Maps a RicStatusResponse from the Refinitiv API to a generic ProviderResponse
    /// </summary>
    GetStatusResponse ToProviderResponse(RicStatusResponse? result, string productCode);
}

/// <summary>
/// Mapper for Refinitiv-specific requests and responses
/// </summary>
public class RefinitivMapper : IRefinitivMapper
{
    private readonly RefinitivApiOptions _options;

    public RefinitivMapper(IOptions<RefinitivApiOptions> options)
    {
        _options = options.Value;
    }

    /// <summary>
    /// Converts a ProductPayload to a SendRicCreationRequest
    /// </summary>
    /// <param name="payload">The product payload for this provider</param>
    /// <param name="runContext">The execution context</param>
    /// <returns>A SendRicCreationRequest containing the mapped fields</returns>
    public SendRicCreationRequest ToSendRicCreationRequest(ProductPayload payload, RunContext runContext)
    {
        return new SendRicCreationRequest
        {
            ProductName = payload.ProductName,
            ProductCode = BuildRic(payload.ProductCode),
            Currency = payload.Currency ?? string.Empty,
            Coupon = payload.Coupon,
            MaturityDate = payload.MaturityDate
        };
    }

    private string BuildRic(string productCode)
    {
        if (string.IsNullOrWhiteSpace(productCode)) return string.Empty;
        return $"{productCode}{_options.RicExtension}";
    }

    /// <summary>
    /// Maps a CreateRicResponse from the Refinitiv API to a generic ProviderResponse
    /// </summary>
    public SendRequestResponse ToProviderResponse(CreateRicResponse? result, string productCode)
    {
        if (result == null)
        {
            return new SendRequestResponse
            {
                ErrorMessage = "Refinitiv API call returned null",
                Success = false,
            };
        }

        bool isSuccess = result.JobId > 0;

        return new SendRequestResponse
        {
            Success = isSuccess,
            ExternalRequestId = result.JobId.ToString(),
            ErrorMessage = isSuccess ? null : (result.Message ?? "Failed to get JobId from Refinitiv")
        };
    }

    /// <summary>
    /// Maps a RicStatusResponse from the Refinitiv API to a generic ProviderResponse
    /// </summary>
    public GetStatusResponse ToProviderResponse(RicStatusResponse? result, string productCode)
    {
        if (result == null)
        {
            return new GetStatusResponse
            {
                ErrorMessage = "Refinitiv API call returned null",
                Success = false,
                Status = ProductCreationProviderStatus.Failed
            };
        }

        var ric = BuildRic(productCode);
        
        // FailedRics / FunctionalReject
        if (result.FailedRics != null && result.FailedRics.Any(x => x.Contains(ric)))
        {
            var failedString = result.FailedRics.First(x => x.Contains(ric));
            return new GetStatusResponse
            {
                Success = false,
                Status = ProductCreationProviderStatus.Rejected,
                ErrorMessage = failedString,
                ExternalRequestId = result.JobId.ToString()
            };
        }

        // SuccessRics / SUCCEED
        if (result.SuccessRics != null && result.SuccessRics.Any(x => x.Contains(ric)))
        {
            return new GetStatusResponse
            {
                Success = true,
                Status = ProductCreationProviderStatus.Created,
                ExternalRequestId = result.JobId.ToString()
            };
        }

        // Default to Ack (not yet finished)
        return new GetStatusResponse
        {
            Success = true,
            Status = ProductCreationProviderStatus.Ack,
            ExternalRequestId = result.JobId.ToString()
        };
    }
}
