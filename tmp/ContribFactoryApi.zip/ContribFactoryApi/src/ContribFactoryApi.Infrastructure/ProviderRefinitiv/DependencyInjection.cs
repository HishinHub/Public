using ContribFactoryApi.Application.Interfaces;
using ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv;

public static class DependencyInjection
{
    public static IServiceCollection AddRefinitiv(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddRefinitivApi(configuration);
        services.AddSingleton<IRefinitivMapper, RefinitivMapper>();
        services.AddScoped<IProviderAgent, RefinitivAgent>();

        return services;
    }
}
