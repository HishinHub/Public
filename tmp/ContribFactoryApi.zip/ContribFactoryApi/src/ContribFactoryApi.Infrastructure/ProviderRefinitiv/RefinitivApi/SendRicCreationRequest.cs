using System;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi;

using ContribFactoryApi.Domain.ProductCreation;

/// <summary>
/// Represents the message for Refinitiv provider
/// </summary>
public record SendRicCreationRequest
{
    public DateTime? MaturityDate { get; init; }
    public double? Coupon { get; init; }
    public string ProductName { get; init; } = string.Empty;
    public string Currency { get; init; } = string.Empty;
    public string ProductCode { get; init; } = string.Empty;
}
