using System.Text.Json.Serialization;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi
{
    public class RefinitivAccessToken
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; }

        [JsonPropertyName("token_type")]
        public string TokenType { get; set; }

        [JsonPropertyName("expires_in")]
        public string ExpiresIn { get; set; }

        [JsonPropertyName("scope")]
        public string Scope { get; set; }
    }

    public class RicStatusResponse : CreateRicResponse
    {
        [JsonPropertyName("success_RICS")]
        public string[] SuccessRics { get; set; }

        [JsonPropertyName("failed_RICS")]
        public string[] FailedRics { get; set; }
    }

    public class CreateRicResponse
    {
        [JsonPropertyName("rsp")]
        public string Rsp { get; set; }

        [JsonPropertyName("uuid")]
        public string Uuid { get; set; }

        [JsonPropertyName("job_id")]
        public int JobId { get; set; }

        [JsonPropertyName("msg")]
        public string Message { get; set; }
    }

    public class CreateRicErrorResponse
    {
        [JsonPropertyName("error")]
        public string Error { get; set; }

        [JsonPropertyName("message")]
        public string Message { get; set; }
    }

    public class RicRequest
    {
        [JsonPropertyName("msg_type")]
        public string MsgType { get; set; }

        [JsonPropertyName("action")]
        public string Action { get; set; }

        [JsonPropertyName("CSLN")]
        public string Csln { get; set; }

        [JsonPropertyName("profile_name")]
        public string ProfileName { get; set; }

        [JsonPropertyName("uuid")]
        public string Uuid { get; set; }
    }

    public class CreateRicRequest : RicRequest
    {
        [JsonPropertyName("RICs")]
        public HashSet<Ric> Rics { get; set; }
    }

    public class GetRicStatusRequest : RicRequest
    {
        [JsonPropertyName("job_id")]
        public int JobId { get; set; }
    }

    public class Ric
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("FIDs")]
        public HashSet<Fid> Fids { get; set; }
    }

    public class Fid
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }
        [JsonPropertyName("value")]
        public string Value { get; set; }
    }
}
