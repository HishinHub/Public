using Microsoft.Extensions.Logging;
using System.Web;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi
{
    public class LoggingHandler : DelegatingHandler
    {
        private readonly ILogger logger;

        public LoggingHandler(ILogger logger)
        {
            this.logger = logger;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // Log the request
            var content = await request.Content?.ReadAsStringAsync()! ?? string.Empty;
            content = RemoveQueryStringPassword(content);
            logger.LogInformation($"Request: \n{request.ToString()}\n{content}");

            // Send the request to the inner handler.
            var response = await base.SendAsync(request, cancellationToken);

            // Log the response
            logger.LogInformation($"Response: \n{response.ToString()}\n{await response.Content?.ReadAsStringAsync()! ?? string.Empty}");

            return response;
        }

        private string RemoveQueryStringPassword(string queryString) 
        {
            string result = queryString;
            if (queryString.Contains("&password="))
            {
                var queryParams = HttpUtility.ParseQueryString(queryString);
                queryParams["password"] = string.Empty;
                result = queryParams.ToString()!;
            }
            return result;
        }
    }
}
