using System;
using System.Collections.Generic;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi
{
    public static class RefinitivContext
    {
        public const string UserAgent = "ContribFactoryApi/ProductCreator";

        public class RefinitivRequest
        {
            public const string MsgType = "BR";
            public const string ActionSearch = "search";
            public const string ActionAdd = "add";
        }

        public const string CouponNumberFormat = "F4";
        public const string MaturityDateFormat = "dd-MMM-yyyy";

        public static readonly string StaticFidCtbtr1 = "CA-CIB";
        public static readonly string StaticFidCtbLoc1 = "PAR";

        public class Fids
        {
            public const string DiplayName = "3";
            public const string Currency = "15";
            public const string MaturityDate = "68";
            public const string CouponRate = "69";
            public const string OfficialCode = "78";

            public const string BondType = "104";
            public const string BkgdRef = "967";
            public const string Ctbtr1 = "831";
            public const string CtbLoc1 = "836";
            public const string CtbtrBkgd = "968";
        }

        public static readonly Dictionary<string, string> FailedRicErrorCodes = new Dictionary<string, string>
        {
            { "3000", "Invalid file extension or invalid file content" },
            { "3001", "Invalid action type" },
            { "3002", "Duplicate filename" },
            { "3003", "Client Site Location Number not found in LSEG Database" },
            { "3004", "Profile not found on LSEG Database" },
            { "3005", "Invalid timestamp format in file name" },
            { "3006", "RIC creation limit reached" },
            { "3007", "FIDs are not valid for one or more instruments" },
            { "3008", "Duplicate FID/value pair" },
            { "3009", "Invalid FID value" },
            { "3010", "RIC duplicates present in request" },
            { "3011", "RIC(s) already exists" },
            { "3012", "RIC(s) deletion failed because RIC does not exist" },
            { "3013", "Invalid RIC name" },
            { "3014", "Invalid RIC name Insert Header 12" },
            { "3015", "Invalid RIC name" },
            { "3016", "Contributor ID does not exist" },
            { "3017", "No valid RICs in request" },
            { "3018", "Recon EXL not live" },
            { "3020", "RIC creation in CAFE staging tables failed, RICs cannot be processed" },
            { "3021", "Contributor profile unable to delete RIC" },
            { "3023", "Unexpected delay, please resubmit request after 20 minutes" }
        };

        public const int DisplayNameMaxSize = 16;

        public static readonly Dictionary<string, string> ShortDisplayNames = new Dictionary<string, string>
        {
            {"1Y USD 11.35% REVERSE CONVERTIBLE on SILVER", "1Y USD REVC SILVER"},
            {"2 years WTI Oil Bull Note", "2Y WTI Bull Note"},
            {"3y Basket Digit in USD", "3Y Basket USD"},
            {"4Y BULLISH USD NOTE LINKED TO GOLD", "4Y Bull USD Gold"},
            {"5Y EUR BASKET NOTE ON COMMODITIES 100% CAPITAL PROTECTED", "5Y EUR Basket"},
            {"AIRBAG", "AIRB"},
            {"ALTERNATIVE CMS NOTE (ACN)", "Alt.CMS.Note"},
            {"Alternative CMS Note (ACN)", "Alt.CMS.Note"},
            {"BASKET LINKED NOTE", "Basket.LNK.Note"},
            {"Cap Floater Callable", "Cap.Fltr.Call"},
            {"CHANNEL ALTERNATIVE CMS", "Channel.Alt.CMS"},
            {"CMS Callable", "CMS.Callable"},
            {"CMS LINKED", "CMS.LINKED"},
            {"CMS Linked", "CMS.Linked"},
            {"CMS SPREAD", "CMS.SPREAD"},
            {"CMS Spread", "CMS.Spread"},
            {"CMS Spread Callable", "CMS.Sprd.Call"},
            {"CMS Spread Range Accrual", "CMS.Sprd.RA"},
            {"CMS SPREAD RANGE ACCRUAL", "CMS.SPRD.RA"},
            {"Callable / Puttable Range Note", "Call/Putt Range"},
            {"Callable Dual Rangers Accrual", "Dual.Ranger.Acc"},
            {"Callable Ladder Note", "Call.Ladd.Note"},
            {"Credit Linked Note - Hybrid", "Credit.LNK.Hyb"},
            {"Dual Range Accrual Note", "Dual.RA.Note"},
            {"EQUITY LINE", "EQ.LINE"},
            {"FLIP / FLOP CALLABLE", "Flip/Flop Call"},
            {"FIXED RATE", "FXD.RATE"},
            {"FIXED RATE PUTTABLE", "FXD.RATE.PUTT"},
            {"FIXED RATE STEP-UP", "FXD.RATE.STEPUP"},
            {"FX LINKED", "FX.LINKED"},
            {"FX LINKED - BASKET", "FX.LNKD.BASKET"},
            {"FX LINKED - DUAL CCY", "FX.LNKD.DUAL.CCY"},
            {"FX LINKED - RANGE NOTE", "FX.LNKD.RANGE"},
            {"FX LINKED - TARN", "FX.LNKD.TARN"},
            {"Floating Rate", "Fl.Rte"},
            {"Floating Rate Step-up Callable", "Fl.Rte.Step.Call"},
            {"Flip / Flop Callable", "Flip/Flop Call"},
            {"Fixed Rate", "Fxd.Rte"},
            {"Fixed Rate Callable", "FXD.RAT.CALL"},
            {"Fixed Rate Step-up", "FXD.RAT.STEPUP"},
            {"Fixed Rate Step-up Callable", "FXD.RTE.STP.CALL"},
            {"GOLD LINKED NOTE", "Gld.Lnkd"},
            {"INFLATION LINKED", "INFL.LNKD"},
            {"IRD + EQUITY", "IRD + EQUITY"},
            {"IRD + Equity", "IRD + Equity"},
            {"IRD + FX", "IRD + FX"},
            {"IRD + Inflation", "IRD + Infltn"},
            {"Leveraged Reverse Floater Multi-Callable", "Lev.RevFltr.MC"},
            {"LOCK UP STEEPENER", "Lockup Steepnr"},
            {"MT0212", "MT0212"},
            {"Power Reverse Dual Currency Note", "PR.Dual.Curr"},
            {"Power Reverse Flipper Callable", "PR.Flip.Call"},
            {"Power Reverse Multi-Callable", "PR.Multi-Call"},
            {"Power Reverse Non-Callable", "PR.Non-Call"},
            {"RANGE ACCRUAL FIXED RATE", "RA.FXD.RATE"},
            {"RANGE ACCRUAL FLOATING RATE CALLABLE", "RA.FLT.RTE.CALL"},
            {"Range Accrual Fixed Rate", "RA.Fxd.Rate"},
            {"Range Accrual Fixed Rate Callable", "RA.FXD.RTE.CALL"},
            {"Range Accrual Fixed Rate Step-Up Callable", "RA.FXD.STP.CALL"},
            {"Range Accrual Floating Rate Callable", "RA.FLT.RTE.CALL"},
            {"Range Accrual Short Index", "RA.Short.Index"},
            {"Range Accrual Step Up", "RA.Step.Up"},
            {"Ratchet", "Ratchet"},
            {"Reverse Floater", "Rvs.Floater"},
            {"Reverse Floater Accrual Callable", "RevFltr Acc Call"},
            {"Reverse Floater Callable", "RevFltr Callable"},
            {"SNOW BALL", "SNOW BALL"},
            {"Snow Ball", "Snow Ball"},
            {"Snowrange", "Snowrange"},
            {"Step-Up Reverse Floater Callable", "STP-UP RevFltr Call"},
            {"Super Ball", "Super Ball"},
            {"Switchable note", "Switch.Note"},
            {"TARGET REDEMPTION NOTE", "TR.Note"},
            {"Target Redemption Note", "Tgt.Rdm.Note"},
            {"Thunderball", "Thunderball"},
            {"USD 6M Wedding Cake Gold", "USD6M Wedd Gold"},
            {"VOLATILITY BOND", "VOL.Bond"},
            {"Volatility Bond", "VOL.Bond"},
            {"WTI LINKED NOTE", "WTI.Lnkd.Note"},
            {"Zero Coupon Callable", "ZC.Call"},
            {"Zero Coupon Note", "Zero.Cpn"}
        };
    }
}
