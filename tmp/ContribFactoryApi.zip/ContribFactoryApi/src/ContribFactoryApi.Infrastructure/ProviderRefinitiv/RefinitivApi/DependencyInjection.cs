using ContribFactoryApi.Infrastructure.Database;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Net;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddRefinitivApi(this IServiceCollection services, IConfiguration configuration)
        {
            var sectionProxy = configuration.GetSection(ProxyOptions.SectionName);
            var sectionSvcAccount = configuration.GetSection(SvcAccountOptions.SectionName);
            services.AddOptions<RefinitivApiOptions>()
                .BindConfiguration(RefinitivApiOptions.SectionName)
                .PostConfigure(options =>
                {
                    sectionProxy.Bind(options.Proxy);
                    sectionSvcAccount.Bind(options.SvcAccount);
                })
                .ValidateDataAnnotations()
                .ValidateOnStart();

            services.AddTransient<IRefinitivHttpRequestBuilder, RefinitivHttpRequestBuilder>();
            
            services.AddTransient<LoggingHandler>(sp => 
                new LoggingHandler(sp.GetRequiredService<ILogger<RefinitivApiClient>>()));

            services.AddHttpClient<IRefinitivApiClient, RefinitivApiClient>()
                .ConfigurePrimaryHttpMessageHandler(sp => {
                    var options = sp.GetRequiredService<IOptions<RefinitivApiOptions>>().Value;
                    var proxy = new WebProxy(options.Proxy.Host, options.Proxy.Port)
                    {
                        Credentials = new NetworkCredential(options.SvcAccount.Username, options.SvcAccount.Password)
                    };
                    return new HttpClientHandler {
                        Proxy = proxy,
                        UseProxy = true
                    };
                })
                .AddHttpMessageHandler<LoggingHandler>();

            return services;
        }
    }
}
