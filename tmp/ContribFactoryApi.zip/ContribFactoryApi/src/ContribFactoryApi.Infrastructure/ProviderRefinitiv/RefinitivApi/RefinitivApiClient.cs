using System.Net;
using System.Text.Json;
using ContribFactoryApi.Domain.ProductCreation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi
{
    public class RefinitivApiClient(
        HttpClient client,
        ILogger<RefinitivApiClient> _logger, 
        IOptions<RefinitivApiOptions> options, 
        IRefinitivHttpRequestBuilder builder
        ) : IRefinitivApiClient
    {
        private async Task<RefinitivAccessToken> GetAcessToken()
        {
            _logger.LogInformation("Attempting to get AccessToken from Refinitiv");

            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, options.Value.AuthUrl);
                builder.AddAuthorization(request, options.Value.Username);
                builder.AddAuthenticateContent(request, options.Value.Username, options.Value.Password);

                var response = await client.SendAsync(request);
                var content = await response.Content.ReadAsStringAsync();
                response.EnsureSuccessStatusCode();

                RefinitivAccessToken tokenResult = JsonSerializer.Deserialize<RefinitivAccessToken>(content)!;

                _logger.LogInformation($"Get AccessToken from Refintiv SUCCEED");

                return tokenResult;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Could not get AccessToken from Refintiv");
                throw (ex);
            }
        }

        public async Task<CreateRicResponse> SendRicCreation(string ric, SendRicCreationRequest request, RunContext runContext)
        {
            try
            {
                var token = await GetAcessToken();
                if (token == null) throw new Exception("Authentication token received from Refinitiv is null");

                var httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, options.Value.ApiUrl);
                builder.AddRequestHeaders(httpRequestMessage, token.AccessToken);
                builder.AddCreateRicRefinitivRequest(httpRequestMessage, ric, request);

                HttpResponseMessage result = await client.SendAsync(httpRequestMessage);
                string responseBody = await result.Content.ReadAsStringAsync();

                if (result.IsSuccessStatusCode)
                {
                    _logger.LogInformation("[REQ:{RequestId}/{ProviderRequestId}] ## Refinitiv CreateRic Request SUCCEED: {ResponseBody}", runContext.RequestId, runContext.ProviderRequestId, responseBody);
                    var response = JsonSerializer.Deserialize<CreateRicResponse>(responseBody);
                    return response;
                }
                else
                {
                    _logger.LogError("[REQ:{RequestId}/{ProviderRequestId}] ## Refinitiv CreateRic Request FAILED: {StatusCode} - {ResponseBody}", runContext.RequestId, runContext.ProviderRequestId, result.StatusCode, responseBody);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[REQ:{RequestId}/{ProviderRequestId}] Unexpected Failed on CreateRic", runContext.RequestId, runContext.ProviderRequestId);
                return null;
            }
        }

        public async Task<RicStatusResponse> GetRicStatus(int jobId)
        {
            try
            {
                var token = await GetAcessToken();

                var request = new HttpRequestMessage(HttpMethod.Post, options.Value.ApiUrl);
                builder.AddRequestHeaders(request,token.AccessToken);
                builder.AddSearchRefinitivRequest(request, jobId);

                HttpResponseMessage result = await client.SendAsync(request);
                string responseBody = await result.Content.ReadAsStringAsync();

                if (!result.IsSuccessStatusCode)
                {
                    _logger.LogError($"## Refinitiv GetStatus Request FAILED");
                    return null;
                }

                _logger.LogInformation($"## Refinitiv GetStatus Request SUCCEED");
                var response = JsonSerializer.Deserialize<RicStatusResponse>(responseBody);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Unexpected Failed on RicStatus");
                return null;
            }
        }

    }

    public interface IRefinitivApiClient
    {
        Task<CreateRicResponse> SendRicCreation(string ric, SendRicCreationRequest request, RunContext runContext);
        Task<RicStatusResponse> GetRicStatus(int jobId);
    }
}
