using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Infrastructure.ProviderRefinitiv.RefinitivApi;
using FluentValidation;

namespace ContribFactoryApi.Infrastructure.ProviderRefinitiv;

/// <summary>
/// Validator for SendRicCreationRequest
/// </summary>
public class RefinitivValidator : AbstractValidator<SendRicCreationRequest>
{
    public RefinitivValidator()
    {
        RuleFor(x => x.ProductName)
            .NotEmpty()
            .WithMessage("Product name (InsLabel) is required for Refinitiv");

        RuleFor(x => x.Currency)
            .NotEmpty()
            .Length(3)
            .WithMessage("Currency (InsCurrency) must be a 3-character ISO code");

        RuleFor(x => x.ProductCode)
            .NotEmpty()
            .WithMessage("Product code (InsCodeIsin) is required for Refinitiv");

        RuleFor(x => x.MaturityDate)
            .NotEmpty()
            .WithMessage("Maturity date (InsDtMaturity) is required for Refinitiv");

        RuleFor(x => x.Coupon)
            .GreaterThanOrEqualTo(0)
            .When(x => x.Coupon.HasValue)
            .WithMessage("Coupon must be non-negative");
    }
}
