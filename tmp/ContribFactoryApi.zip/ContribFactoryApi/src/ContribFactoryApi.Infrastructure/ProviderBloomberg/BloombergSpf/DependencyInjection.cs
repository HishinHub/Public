using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using ContribFactoryApi.Infrastructure.Sftp;

namespace ContribFactoryApi.Infrastructure.ProviderBloomberg.BloombergSpf
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddBloombergSpf(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddOptions<BloombergSpfOptions>()
                .BindConfiguration(BloombergSpfOptions.SectionName)
                .ValidateDataAnnotations()
                .ValidateOnStart();

            // Stubs for SFTP Bloomberg
            services.AddScoped<ProductCreatorDbContext>();
            services.AddScoped<IInstrumentServiceProxy, StubService>();
            services.AddScoped<IEspmServiceProxy, StubService>();
            services.AddScoped<IRequestWriter, StubService>();

            services.AddScoped<BloombergSpfBuilder>();
            services.AddScoped<IBloombergSpfClient, BloombergSpfClient>();

            // SFTP for Bloomberg
            services.AddSftp(configuration, $"{BloombergSpfOptions.SectionName}:{SftpOptions.SectionName}");


            return services;
        }
    }
}
