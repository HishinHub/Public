namespace ContribFactoryApi.Infrastructure.ProviderBloomberg.BloombergSpf
{
    public static class BloombergSpfContext
    {
        public const string InvestorTermSheetType = "InvestorTermSheet";
        public const string RequestFileExtension = ".xml";
        public const string RequestPackageExtension = ".zip";
        public const string BloombergReferenceDateFormat = "yyyyMMddHHmmss";

        public static class SftpConfig
        {
            public const string SenderCompanyBloombergId = "CMPY";
            public const string LocalZipDir = "C:\\Temp\\[ISIN_CODE]";
            public const string FtpReqDir = "/requests";
        }
    }
}
