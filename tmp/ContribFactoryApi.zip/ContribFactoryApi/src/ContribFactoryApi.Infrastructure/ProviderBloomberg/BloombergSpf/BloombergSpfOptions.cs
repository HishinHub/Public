using System.ComponentModel.DataAnnotations;

namespace ContribFactoryApi.Infrastructure.ProviderBloomberg.BloombergSpf;

public class BloombergSpfOptions
{
    public const string SectionName = "BloombergSpf";

    public ContribFactoryApi.Infrastructure.Sftp.SftpOptions Sftp { get; set; } = new();
}
