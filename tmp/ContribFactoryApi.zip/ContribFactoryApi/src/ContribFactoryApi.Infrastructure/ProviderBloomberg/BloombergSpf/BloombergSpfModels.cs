using System;
using System.Collections.Generic;
using System.Xml.Linq;
using ContribFactoryApi.Domain.ProductCreation;
namespace ContribFactoryApi.Infrastructure.ProviderBloomberg.BloombergSpf
{
    public class SpfRequest
    {
        public CreateProductRequest Instrument { get; set; } = null!;
        public XElement RequestDocument { get; set; } = null!;
        public List<Termsheet> TermSheets { get; set; } = new();
    }

    public class Termsheet
    {
        public string Name { get; set; } = string.Empty;
        public byte[] Content { get; set; } = Array.Empty<byte>();
    }

    public interface IBloombergSpfClient
    {
        Task<BloombergRequestStatus> CreateProductAsync(CreateProductRequest request, RunContext runContext, CancellationToken cancellationToken = default);
    }

    public class BloombergRequestStatus
    {
        public bool Success { get; set; }
        public bool IsSent { get; set; }
        public string BloombergRef { get; set; } = string.Empty;
        public string IsinCode { get; set; } = string.Empty;
        public string? Message { get; set; }
        public string? BloombergId { get; set; } // Compatibility with existing agent Expectation
    }

    public class Ctborder
    {
        public int OrderId { get; set; }
        public string BloombergReference { get; set; } = string.Empty;
        public CreateProductRequest Instrument { get; set; } = new();
    }



    public class BloombergSpfResult
    {
        public bool Success { get; set; }
        public string? ErrorMessage { get; set; }
        public Ctborder? CtbOrder { get; set; }

        public static BloombergSpfResult CreateSuccess() => new() { Success = true };
        public static BloombergSpfResult CreateTermsheetError(string msg) => new() { Success = false, ErrorMessage = msg };
        public static BloombergSpfResult CreateEspmError(string msg) => new() { Success = false, ErrorMessage = msg };
        public static BloombergSpfResult CreateDuplicatedCtbOrderError(string msg) => new() { Success = false, ErrorMessage = msg };
        public static BloombergSpfResult CreateExternalReferenceError(string msg) => new() { Success = false, ErrorMessage = msg };
        public static BloombergSpfResult CreateSendSftpError(string msg) => new() { Success = false, ErrorMessage = msg };
        public static BloombergSpfResult CreateUnknownError(string msg) => new() { Success = false, ErrorMessage = msg };
    }
}
