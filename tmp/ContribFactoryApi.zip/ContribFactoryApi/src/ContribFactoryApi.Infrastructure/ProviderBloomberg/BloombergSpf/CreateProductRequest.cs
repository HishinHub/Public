namespace ContribFactoryApi.Infrastructure.ProviderBloomberg.BloombergSpf;

/// <summary>
/// Represents the message for Bloomberg provider
/// </summary>
public record CreateProductRequest
{
    public string RequestId { get; init; } = string.Empty;
    public string ProviderRequestId { get; init; } = string.Empty;

    public string ProductCode { get; init; } = string.Empty;
    public string ProductName { get; init; } = string.Empty;
    public DateTime? MaturityDate { get; init; }

    public string InsId { get; init; } = string.Empty;
    public string InsCodeIsin { get; init; } = string.Empty;
    public string InfinityPdId { get; init; } = string.Empty;
}
