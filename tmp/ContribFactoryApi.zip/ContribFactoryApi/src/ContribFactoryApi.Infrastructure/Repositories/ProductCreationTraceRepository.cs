using ContribFactoryApi.Application.Interfaces;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Infrastructure.Database;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ContribFactoryApi.Infrastructure.Repositories;

/// <summary>
/// Repository implementation for ProductCreationTrace entities
/// </summary>
public class ProductCreationTraceRepository : IProductCreationTraceRepository
{
    private readonly AppDbContext _context;
    private readonly ILogger<ProductCreationTraceRepository> _logger;

    public ProductCreationTraceRepository(AppDbContext context, ILogger<ProductCreationTraceRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ProductCreationTrace> CreateAsync(ProductCreationTrace request, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[REQ:{RequestId}][ProdCrea] Creating product creation message. {Count} providers", request.RequestId, request.ProviderRequests.Count);
        _logger.LogInformation("[REQ:{RequestId}][ProdCrea/StatusUpdate] Message Status: {Status}", request.RequestId, request.Status);

        _context.ProductCreationTraces.Add(request);
        await _context.SaveChangesAsync(cancellationToken);

        return request;
    }

    public async Task<ProductCreationTrace?> GetByRequestIdAsync(string requestId, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[REQ:{RequestId}][ProdCrea] Fetching product creation message by request ID", requestId);

        return await _context.ProductCreationTraces
            .Include(m => m.ProviderRequests)
            .FirstOrDefaultAsync(m => m.RequestId == requestId, cancellationToken);
    }

    public async Task<ProductCreationProvider?> GetByProviderRequestIdAsync(string providerRequestId, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[ProdCrea] Fetching product creation provider by provider request ID: {ProviderRequestId}", providerRequestId);

        return await _context.Set<ProductCreationProvider>()
            .Include(p => p.Trace)
                .ThenInclude(t => t.ProviderRequests)
            .FirstOrDefaultAsync(p => p.ProviderRequestId == providerRequestId, cancellationToken);
    }

    public async Task<ProductCreationTrace?> GetByRequestIdAndProviderNameAsync(string requestId, ProviderName providerName, CancellationToken cancellationToken = default)
    {
         _logger.LogInformation("[REQ:{RequestId}][ProdCrea] Fetching trace with provider filtered by {ProviderName}", requestId, providerName);

        return await _context.ProductCreationTraces
            .Include(t => t.ProviderRequests.Where(p => p.ProviderName == providerName))
            .FirstOrDefaultAsync(t => t.RequestId == requestId, cancellationToken);
    }

    public async Task<IReadOnlyList<ProductCreationProvider>> GetAllReadyToSync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[ProdCrea/Sync] Fetching all Ready to Sync product providers from DB");

        return await _context.Set<ProductCreationProvider>()
            .Include(p => p.Trace)
                .ThenInclude(t => t.ProviderRequests)
            .Where(p => p.Status == ProductCreationProviderStatus.Sent
                        || p.Status == ProductCreationProviderStatus.Ack)
            .ToListAsync(cancellationToken);
    }

    public async Task<ProductCreationTrace> UpdateAsync(ProductCreationTrace request, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[REQ:{RequestId}][ProdCrea/StatusUpdate] Message Status: {Status}", request.RequestId, request.Status);

        _context.ProductCreationTraces.Update(request);
        await _context.SaveChangesAsync(cancellationToken);

        return request;
    }

    public async Task<string> GetDatabaseVersionAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            using var command = _context.Database.GetDbConnection().CreateCommand();
            command.CommandText = "SELECT @@VERSION";
            await _context.Database.OpenConnectionAsync(cancellationToken);
            var version = (string?)await command.ExecuteScalarAsync(cancellationToken);
            return version ?? "Unknown Version";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve database version");
            throw;
        }
    }
}
