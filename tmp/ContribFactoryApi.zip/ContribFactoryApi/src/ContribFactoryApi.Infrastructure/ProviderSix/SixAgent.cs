using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryApi.Application.Interfaces;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Infrastructure.Identifiers;
using Microsoft.Extensions.Logging;
using ContribFactoryApi.Infrastructure.ProviderSix.SixConnexor;

namespace ContribFactoryApi.Infrastructure.ProviderSix;

/// <summary>
/// Six-specific product creation agent
/// </summary>
public class SixAgent : IProviderAgent
{
    private readonly ILogger<SixAgent> _logger;
    private readonly IIdGenerator _idGenerator;
    private readonly ISixConnexorClient _sixConnexorClient;
    private readonly ISixMapper _sixMapper;

    public SixAgent(
        ISixConnexorClient sixConnexorClient,
        ILogger<SixAgent> logger,
        IIdGenerator idGenerator,
        ISixMapper sixMapper)
    {
        _sixConnexorClient = sixConnexorClient;
        _logger = logger;
        _idGenerator = idGenerator;
        _sixMapper = sixMapper;
    }

    public ProviderName Provider => ProviderName.Six;

    public async Task<SendRequestResponse> SendRequestAsync(
        ProductPayload payload,
        RunContext runContext,
        CancellationToken cancellationToken = default)
    {
        var sixRequest = _sixMapper.ToProviderSixRequest(payload, runContext.RequestId, runContext.ProviderRequestId);
        
        if (string.IsNullOrEmpty(sixRequest.ProductCode))
        {
            return new SendRequestResponse 
            { 
                Success = false, 
                ErrorMessage = "No SIX payload found in request" 
            };
        }

        _logger.LogInformation(
            "[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Six] SIX: Sending product {ProductCode}", 
            runContext.RequestId,
            runContext.ProviderRequestId,
            sixRequest.ProductCode);

         _logger.LogInformation(
            "[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Six] SIX Payload: Name={ProductName}, MaturityDate={MaturityDate}", 
            runContext.RequestId,
            runContext.ProviderRequestId,
            sixRequest.ProductName,
            sixRequest.MaturityDate);

        // Real SIX-specific logic
        var result = await _sixConnexorClient.CreateProductAsync(sixRequest, cancellationToken);
        
        return new SendRequestResponse
        {
            Success = result.Success,
            ExternalRequestId = result.SixId,
            ExternalProductCode = result.SixId,
            ErrorMessage = result.Message
        };
    }

    public async Task<GetStatusResponse> GetStatusAsync(
        RunContext runContext,
        string productCode,
        string? externalRequestId,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[RUN:{RunId}/REQ:{RequestId}][ProdCrea/Six] SIX: Getting status for {ProductCode} (ExternalRef: {ExternalRequestId})", runContext.RunId, runContext.RequestId, productCode, externalRequestId);
        
        // Empty for now as requested
        return await Task.FromResult(new GetStatusResponse { Success = true, ExternalProductCode = productCode });
    }
}
