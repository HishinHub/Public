using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Domain.ProductCreation.ApiRequestResponse;
using ContribFactoryApi.Infrastructure.ProviderSix.SixConnexor;

namespace ContribFactoryApi.Infrastructure.ProviderSix;

/// <summary>
/// Interface for Six-specific request and response mapping
/// </summary>
public interface ISixMapper
{
    /// <summary>
    /// Converts a ProductPayload to a ProviderSixRequest
    /// </summary>
    ProviderSixRequest ToProviderSixRequest(ProductPayload payload, string requestId, string providerRequestId);
}

/// <summary>
/// Mapper for converting a ProductPayload to a ProviderSixRequest
/// </summary>
public class SixMapper : ISixMapper
{
    /// <summary>
    /// Converts a ProductPayload to a ProviderSixRequest
    /// </summary>
    /// <param name="payload">The product payload for this provider</param>
    /// <param name="requestId">The request ID</param>
    /// <param name="providerRequestId">The provider request ID</param>
    /// <returns>A ProviderSixRequest containing the mapped fields</returns>
    public ProviderSixRequest ToProviderSixRequest(ProductPayload payload, string requestId, string providerRequestId)
    {
        return new ProviderSixRequest
        {
            RequestId = requestId,
            ProviderRequestId = providerRequestId,
            
            ProductCode = payload.ProductCode,
            ProductName = payload.ProductName,
            MaturityDate = payload.MaturityDate
        };
    }
}
