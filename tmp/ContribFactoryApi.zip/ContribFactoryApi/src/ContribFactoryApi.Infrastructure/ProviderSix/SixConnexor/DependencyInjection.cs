using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ContribFactoryApi.Infrastructure.ProviderSix.SixConnexor;

public static class DependencyInjection
{
    public static IServiceCollection AddSixConnexor(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<SixConnexorOptions>()
            .BindConfiguration(SixConnexorOptions.SectionName)
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddTransient<ISixHttpRequestBuilder, SixHttpRequestBuilder>();

        services.AddHttpClient<ISixConnexorClient, SixConnexorClient>();

        return services;
    }
}
