using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ContribFactoryApi.Domain.ProductCreation;

namespace ContribFactoryApi.Infrastructure.ProviderSix.SixConnexor;

public interface ISixConnexorClient
{
    Task<SixResponse> CreateProductAsync(ProviderSixRequest request, CancellationToken cancellationToken = default);
}

public class SixConnexorClient : ISixConnexorClient
{
    private readonly HttpClient _httpClient;
    private readonly SixConnexorOptions _options;
    private readonly ISixHttpRequestBuilder _requestBuilder;
    private readonly ILogger<SixConnexorClient> _logger;

    public SixConnexorClient(
        HttpClient httpClient,
        IOptions<SixConnexorOptions> options,
        ISixHttpRequestBuilder requestBuilder,
        ILogger<SixConnexorClient> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _requestBuilder = requestBuilder;
        _logger = logger;
    }

    private async Task<string> GetAccessTokenAsync(ProviderSixRequest request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Six] Refreshing SIX Access Token", request.RequestId, request.ProviderRequestId);

        using var httpRequest = new HttpRequestMessage(HttpMethod.Post, _options.AuthUrl);
        _requestBuilder.AddAuthenticateContent(httpRequest, _options.ClientId, _options.ClientSecret);

        var response = await _httpClient.SendAsync(httpRequest, cancellationToken);
        response.EnsureSuccessStatusCode();

        var result = await response.Content.ReadFromJsonAsync<SixTokenResponse>((JsonSerializerOptions?)null, cancellationToken);
        
        if (result == null || string.IsNullOrEmpty(result.AccessToken))
        {
            throw new InvalidOperationException("Failed to retrieve access token from SIX.");
        }

        return result.AccessToken;
    }

    public async Task<SixResponse> CreateProductAsync(ProviderSixRequest request, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Six] Calling SIX API at {ApiUrl} for product {ProductCode}", request.RequestId, request.ProviderRequestId, _options.ApiUrl, request.ProductCode);

        try
        {
            var token = await GetAccessTokenAsync(request, cancellationToken);
            
            using var httpRequest = new HttpRequestMessage(HttpMethod.Post, $"{_options.ApiUrl}/products");
            _requestBuilder.AddRequestHeaders(httpRequest, token);
            _requestBuilder.AddCreateProductRequest(httpRequest, request);

            var response = await _httpClient.SendAsync(httpRequest, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<SixResponse>((JsonSerializerOptions?)null, cancellationToken);
                _logger.LogInformation("[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Six] SIX API SUCCEED for product {ProductCode}", request.RequestId, request.ProviderRequestId, request.ProductCode);
                return result ?? new SixResponse { Success = false, Message = "Failed to deserialize SIX response" };
            }

            var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogError("[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Six] SIX API returned error: {StatusCode} - {Error}", request.RequestId, request.ProviderRequestId, response.StatusCode, errorContent);

            return new SixResponse 
            { 
                Success = false, 
                Message = $"SIX API Error: {response.StatusCode}" 
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[REQ:{RequestId}/{ProviderRequestId}][ProdCrea/Six] Exception during SIX API call", request.RequestId, request.ProviderRequestId);
            return new SixResponse { Success = false, Message = ex.Message };
        }
    }
}
