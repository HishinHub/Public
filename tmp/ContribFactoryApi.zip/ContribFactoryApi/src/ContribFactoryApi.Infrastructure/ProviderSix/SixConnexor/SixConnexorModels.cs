using System.Text.Json.Serialization;

namespace ContribFactoryApi.Infrastructure.ProviderSix.SixConnexor;

public class SixTokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = null!;
    
    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; set; }
}

public class SixResponse
{
    public bool Success { get; set; }
    public string? SixId { get; set; }
    public string? Message { get; set; }
}
