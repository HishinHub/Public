using Microsoft.OpenApi.Models;
using Microsoft.OpenApi.Any;
using Swashbuckle.AspNetCore.SwaggerGen;
using ContribFactoryApi.Domain.ProductCreation;

namespace ContribFactoryApi.Infrastructure.Swagger;

/// <summary>
/// A Swagger operation filter that applies maxLength constraints to specific parameters by name.
/// </summary>
public class ParameterLengthOperationFilter : IOperationFilter
{
    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        if (operation.Parameters == null) return;

        foreach (var parameter in operation.Parameters)
        {
            if (parameter.Name == "requestId")
            {
                parameter.Schema.MaxLength = 36;
                parameter.Schema.Format = "nanoid";
            }
            else if (parameter.Name == "providerRequestId")
            {
                parameter.Schema.MaxLength = 40;
                parameter.Schema.Format = "nanoid";
            }
            else if (parameter.Name == "providerName")
            {
                parameter.Schema.MaxLength = 9;
                
                // Add enum values for providerName path parameter
                parameter.Schema.Enum = Enum.GetValues<ProviderName>()
                    .Where(p => p != ProviderName.Unknown)
                    .Select(p => new OpenApiString(p.ToString()))
                    .Cast<IOpenApiAny>()
                    .ToList();
            }
        }
    }
}
