using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using ContribFactoryApi.Infrastructure.Authentication;

namespace ContribFactoryApi.Infrastructure.Swagger;

public static class DependencyInjection
{
    public static IServiceCollection AddSwaggerConfiguration(this IServiceCollection services)
    {
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "ContribFactory Api",
                Version = "v1",
                Description = "This API serves as a centralized gateway for orchestrating the asynchronous creation of financial products across external provider platforms (Bloomberg, Refinitiv, and Six).",
                Contact = new OpenApiContact
                {
                    Name = "ContribFactory Support",
                    Email = "support@mail.com",
                    Url = new Uri("https://contribfactory.com")
                }
            });

            options.AddSwaggerJwtSecurity();
            options.DocumentFilter<GroupOrderFilter>();
            options.SchemaFilter<ProblemDetailsSchemaFilter>();
            options.OperationFilter<CommonErrorResponseFilter>();
            options.OperationFilter<ParameterLengthOperationFilter>();

            // Include XML comments for swagger documentation (WebApi, Infrastructure, Domain)
            var webApiXmlFile = "ContribFactoryApi.WebApi.xml";
            var webApiXmlPath = Path.Combine(AppContext.BaseDirectory, webApiXmlFile);
            if (File.Exists(webApiXmlPath))
            {
                options.IncludeXmlComments(webApiXmlPath);
            }

            var infrastructureXmlFile = "ContribFactoryApi.Infrastructure.xml";
            var infrastructureXmlPath = Path.Combine(AppContext.BaseDirectory, infrastructureXmlFile);
            if (File.Exists(infrastructureXmlPath))
            {
                options.IncludeXmlComments(infrastructureXmlPath);
            }

            var domainXmlFile = "ContribFactoryApi.Domain.xml";
            var domainXmlPath = Path.Combine(AppContext.BaseDirectory, domainXmlFile);
            if (File.Exists(domainXmlPath))
            {
                options.IncludeXmlComments(domainXmlPath);
            }
        });

        return services;
    }
}
