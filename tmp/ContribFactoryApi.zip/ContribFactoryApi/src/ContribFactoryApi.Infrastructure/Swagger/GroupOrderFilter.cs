using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

public class GroupOrderFilter : IDocumentFilter
{
    public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
    {
        swaggerDoc.Tags =
        [
            new() { Name = "Product Creation", Description = "Endpoints for orchestrating and monitoring the creation of financial products across multiple external providers (Bloomberg, Refinitiv, and Six)." },
            new() { Name = "Referentials Data", Description = "Endpoints for retrieving reference lists, lookup tables, and status definitions used throughout the service." },
            new() { Name = "Admin", Description = "Diagnostic and maintenance endpoints for system integrity checks and manual batch interventions." },
            new() { Name = "Health", Description = "Infrastructure endpoints for liveness, readiness, and overall system health monitoring." },
        ];
    }
}
