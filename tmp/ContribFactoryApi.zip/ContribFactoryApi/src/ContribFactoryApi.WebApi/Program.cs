using Asp.Versioning;
using ContribFactoryApi.Application;
using ContribFactoryApi.Infrastructure;
using ContribFactoryApi.Infrastructure.Database;
using ContribFactoryApi.WebApi.Endpoints;
using ContribFactoryApi.WebApi.ExceptionHandler;
using ContribFactoryApi.Application.ProviderSynchronizer;
using Serilog;
using ContribFactoryApi.Infrastructure.OpenTelemetry;
using ContribFactoryApi.Infrastructure.Authentication;
using ContribFactoryApi.Infrastructure.ApiVersioning;
using ContribFactoryApi.Infrastructure.Swagger;

if (Log.Logger.GetType().Name == "SilentLogger")
{
    Log.Logger = new LoggerConfiguration()
        .WriteTo.Console()
        .CreateBootstrapLogger();
}

try
{
    Log.Information("STARTING ContribFactory Api");
    var builder = WebApplication.CreateBuilder(args);

    // Bind and resolve OTel options once (used by Serilog sink + OTel SDK below)
    var otelOptions = builder.Configuration
        .GetSection(OpenTelemetryOptions.SectionName)
        .Get<OpenTelemetryOptions>() ?? new OpenTelemetryOptions();

    // Use Serilog as the logging provider for the host
    builder.Host.UseSerilog((context, loggerConfiguration) =>
        loggerConfiguration
            .ReadFrom.Configuration(context.Configuration)
            .AddOpenTelemetrySink(otelOptions), preserveStaticLogger: true);

    // Add services to the container
    builder.Services.AddApplication(builder.Configuration);
    builder.Services.AddInfrastructure(builder.Configuration);

    // Add OpenTelemetry (traces, metrics, OTLP export to Aspire)
    builder.Services.AddOpenTelemetryInstrumentation(builder.Configuration);

    // Add HybridCache
#pragma warning disable EXTEXP0018
    builder.Services.AddHybridCache();
#pragma warning restore EXTEXP0018

    builder.Services.AddApiVersioningConfiguration();

    // Resilience
    builder.Services.AddHttpClient("ResilientClient")
        .AddStandardResilienceHandler();

    builder.Services.AddApiRateLimiting();



    // Health Checks
    builder.Services.AddHealthChecks()
        .AddDbContextCheck<AppDbContext>("database", tags: new[] { "ready", "live" })
        .AddCheck("self", () => Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Healthy(), tags: new[] { "live" });

    // Swagger/OpenAPI
    builder.Services.AddSwaggerConfiguration();

    // CORS (if needed)
    builder.Services.AddCors(options =>
    {
        options.AddDefaultPolicy(policy =>
        {
            policy.AllowAnyOrigin()
                  .AllowAnyMethod()
                  .AllowAnyHeader();
        });
    });

    // Problem Details
    builder.Services.AddProblemDetails();

    var app = builder.Build();

    // Ensure database is created
    using (var scope = app.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        var context = services.GetRequiredService<AppDbContext>();
        context.Database.EnsureCreated();
    }

    // Configure the HTTP request pipeline
    app.UseMiddleware<GlobalExceptionHandler>();

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "Contrib Factory Api v1");
        });
        
    }

    app.UseHttpsRedirection();
    app.UseCors();
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseRateLimiter();


    // Map endpoints
    app.MapAuthEndpoints();
    if (app.Environment.IsDevelopment())
    {
        app.MapAdminEndpoints();
    }
    app.MapHealthCheckEndpoints();
    app.MapReferentialsEndpoints();

    app.MapProductCreationEndpoints();



    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "ContribFactory Api terminated unexpectedly");
    throw;
}
finally
{
    Log.CloseAndFlush();
}

// Make the implicit Program class public for testing
public partial class Program { }
