using System.Threading.RateLimiting;
using ContribFactoryApi.Domain;
using ContribFactoryApi.Infrastructure.Resilience;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;

namespace ContribFactoryApi.WebApi.Endpoints;

public static class RateLimitConfiguration
{
    public static IServiceCollection AddApiRateLimiting(this IServiceCollection services)
    {
        services.AddRateLimiter(options =>
        {
            options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

            options.AddPolicy<string>(ApplicationContext.Resilience.FixedRateLimitingPolicy, httpContext =>
            {
                var resilienceOptions = httpContext.RequestServices.GetRequiredService<IOptions<ResilienceOptions>>().Value;

                return RateLimitPartition.GetFixedWindowLimiter(
                    partitionKey: "global",
                    factory: _ => new FixedWindowRateLimiterOptions
                    {
                        PermitLimit = resilienceOptions.RateLimit.PermitLimit,
                        Window = TimeSpan.FromSeconds(resilienceOptions.RateLimit.WindowSeconds),
                        QueueLimit = resilienceOptions.RateLimit.QueueLimit,
                        QueueProcessingOrder = QueueProcessingOrder.OldestFirst
                    });
            });
        });

        return services;
    }
}
