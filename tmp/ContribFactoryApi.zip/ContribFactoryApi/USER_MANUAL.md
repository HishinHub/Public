# User Manual - ContribFactoryApi API

This manual provides a comprehensive overview of the ContribFactoryApi API, including endpoints, data contracts, validation rules, and error handling.

## Table of Contents
1. [API Endpoints](#api-endpoints)
2. [Data Contracts](#data-contracts)
    - [Input (Request)](#input-request)
    - [Output (Response)](#output-response)
3. [Data Validation, Requirements, and Rules](#data-validation-requirements-and-rules)
4. [Error Messages](#error-messages)

---

## API Endpoints

The API is versioned. The current base URL for the product creation API is `api/v1/products`.

### Product Creation
| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/v1/products` | Submits a product creation request to specified providers. |
| `GET` | `/api/v1/products/{requestId}` | Retrieves the current status and details of a product creation request. |
| `GET` | `/api/v1/products/{requestId}/realtime` | Server-Sent Events (SSE) stream for real-time status updates. |

### Health & Monitoring
| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/health` | Overall health check of all components. |
| `GET` | `/health/live` | Liveness probe (is the app running?). |
| `GET` | `/health/ready` | Readiness probe (is the app ready to accept traffic?). |

### Developer Tools (api/tests)
| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/api/tests/db-connection` | Tests connection to the database. |
| `POST` | `/api/tests/cancel-provider/{providerRequestId}` | Cancels a specific provider request. |
| `POST` | `/api/tests/cancel-failed-providers/{requestId}` | Cancels all failed/rejected provider requests for a requestId. |

---

## Data Contracts

### Input (Request)

#### `ProductCreationRequest`
This is the root object for submitting product creation requests.

| Property | Type | Default | Description |
| --- | --- | --- | --- |
| `requestType` | `string` | `"ProductCreation"` | The type of request. Must be "ProductCreation". |
| `timestamp` | `DateTime` | `Now` | The UTC timestamp of the request. |
| `defaultProviders` | `List<string>` | `[]` | List of default providers if not specified in individual payloads. |
| `payload` | `List<ProductPayload>` | `[]` | List of products to be created. |

#### `ProductPayload`
| Property | Type | Mandatory | Description |
| --- | --- | --- | --- |
| `productType` | `string` | No | Type of product. |
| `providers` | `List<string>` | No* | Providers for this specific product. Falls back to `defaultProviders`. |
| `productCode` | `string` | **Yes** | ISIN or equivalent unique identifier. |
| `productName` | `string` | Yes (Refinitiv) | Human-readable name of the product. |
| `description` | `string` | No | Detailed description. |
| `currency` | `string` | Yes (Refinitiv) | ISO 4217 code (e.g., "EUR"). |
| `coupon` | `double` | Yes (Refinitiv) | Annual coupon rate (e.g., 0.5 for 0.5%). |
| `maturityDate` | `DateTime` | Yes (Refinitiv) | Bond maturity date. |
| `fields` | `Dictionary` | No | Arbitrary extension bag for provider-specific fields. |

\* *Each item in the payload MUST have at least one provider specified (either at the payload level or root level).*

#### Example Request
```json
{
  "requestType": "ProductCreation",
  "timestamp": "2024-03-20T10:00:00Z",
  "defaultProviders": ["Bloomberg", "Refinitiv"],
  "payload": [
    {
      "productCode": "XS1234567890",
      "productName": "Example Bond 2024",
      "currency": "EUR",
      "coupon": 3.5,
      "maturityDate": "2024-12-31T23:59:59Z",
      "providers": ["Six"]
    },
    {
      "productCode": "US9876543210",
      "productName": "US Gov Bond",
      "currency": "USD",
      "coupon": 4.0,
      "maturityDate": "2025-06-30T00:00:00Z"
    }
  ]
}
```

### Output (Response)

#### `ProductCreationApiGroupResponse` (Grouped Response)
| Property | Type | Description |
| --- | --- | --- |
| `requestId` | `string` | The unique ID for the entire trace/request. |
| `createdAt` | `DateTime` | When the request was received. |
| `providerRequests` | `List` | Individual status for each provider targeted. |

#### `ProductCreationApiResponse` (Individual Provider Response)
| Property | Type | Description |
| --- | --- | --- |
| `requestId` | `string` | The unique ID of the request. |
| `productCode` | `string` | The code of the product. |
| `providerRequestId` | `string` | The ID returned by the provider (if available). |
| `provider` | `string` | Human-readable provider name, e.g., "Bloomberg (1)". |
| `providerId` | `int` | Raw integer ID of the provider. |
| `status` | `string` | Human-readable status, e.g., "Sent (2)". |
| `statusId` | `int` | Raw integer ID of the status. |
| `errorMessage` | `string?` | Description of the error if any. |
| `createdAt` | `DateTime` | When this specific provider entry was created. |

#### Example Response
```json
{
  "requestId": "550e8400-e29b-41d4-a716-446655440000",
  "createdAt": "2024-03-20T10:00:01Z",
  "providerRequests": [
    {
      "requestId": "550e8400-e29b-41d4-a716-446655440000.1",
      "productCode": "XS1234567890",
      "providerRequestId": "BBG-001",
      "provider": "Bloomberg",
      "providerId": 1,
      "status": "Sent",
      "statusId": 2,
      "errorMessage": null,
      "createdAt": "2024-03-20T10:00:02Z"
    }
  ]
}
```

---

## Data Validation, Requirements, and Rules

The service applies strict validation rules before processing requests.

### Generic Validation Rules
1.  **Request Type**: Must be exactly `"ProductCreation"`.
2.  **Payload**: Must not be empty.
3.  **Supported Providers**: Only `Bloomberg`, `Refinitiv`, and `Six` are supported.
4.  **Provider Assignment**: Every product in the payload must have at least one effective provider (either specifically assigned or inherited from `defaultProviders`).
5.  **Unique Product per Provider**: You cannot request the same `ProductCode` for the same `Provider` more than once in a single request.
6.  **Product Code**: `productCode` must not be empty for any payload item.

### Provider-Specific Rules (Refinitiv)
When a request targets the **Refinitiv** provider, the following additional fields are **Mandatory**:
- `productName`
- `productCode` (ISIN)
- `currency`
- `coupon`
- `maturityDate`

---

## Error Messages

The API follows the `Problem Details for HTTP APIs` (RFC 7807) standard for errors.

| HTTP Status | Error Title | Description / Error Message Examples |
| --- | --- | --- |
| `400` | `Validation Error` | One or more validation rules failed. |
| | | *Example:* "Each payload must have at least one provider specified" |
| | | *Example:* "Invalid provider in root. Supported values are: Bloomberg, Refinitiv, Six" |
| | | *Example:* "Duplicate (ProductCode, Provider) pairs detected: 'XS123' for provider 'Bloomberg'" |
| `400` | `Bad Request` | Incorrect formatting or invalid arguments. |
| `404` | `Resource Not Found` | No product creation message found with the provided ID. |
| `500` | `Internal Server Error` | An unexpected technical error occurred. |

### Status Codes (Enum Values)

#### Individual Provider Status (`statusId`)
The `statusId` field in the response corresponds to the following internal provider states:

| Value | Name | Description |
| --- | --- | --- |
| `1` | `Received` | Request received and stored. |
| `2` | `Sent` | Request dispatched to the provider. |
| `3` | `Ack` | Provider has acknowledged receipt. |
| `4` | `Created` | **(Final)** Product successfully created. |
| `9` | `Canceled` | **(Final)** Request was manually canceled. |
| `10` | `Rejected` | **(Final)** Provider rejected the request (functional error). |
| `-1` | `Failed` | **(Final)** Technical failure during processing. |
| `-2` | `ProviderFailed` | **(Final)** Provider returned a technical error. |
| `-3` | `UnsupportedProvider`| **(Final)** Provider is not supported. |
| `-4` | `DisabledProvider` | **(Final)** Provider is currently disabled. |

#### Root Request (Trace) Status
The overall request status transitions as follows:

| Value | Name | Description |
| --- | --- | --- |
| `1` | `Received` | Initial state upon receipt. |
| `2` | `Validated` | Request passed validation rules. |
| `3` | `InProgress` | At least one provider has acknowledged or processed the request. |
| `4` | `Completed` | All non-canceled providers have successfully created the product. |
| `-1` | `TechnicalFailed`| A root-level technical error occurred. |
