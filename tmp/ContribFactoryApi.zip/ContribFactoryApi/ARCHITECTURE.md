# ARCHITECTURE

@startuml
!theme plain
skinparam actorStyle awesome
actor USER as "User Client"

package "Product Creation Ecosystem" {
    package "Web API Layer" as WebAPI {
        component Endpoints as "Endpoints (with Resilience)"
        component Authentication as "Authentication (CACIB Identity ?)"
        component Validation as "Product Validation"
    }
    package "Application Layer" {
        component BusinessService as "Orchestrator"
    }
    package "Infrastructure Layer" {
        component DbRepo as "Database Repository"
        component SqsMgr as "Hangfire Job Client"
        component HybridCache as "HybridCache (L1/L2 Cache)"
    }
    database SQLServer as "SQL Server Database"
}

queue SQS as "Hangfire Queue\n(SQL Server Storage)"

package "Background Processing" {
    component JobRunner as "Background Job Runner"
    component Dispatcher as "Providers Dispatcher"
    component SyncStatus as "Status Synchronizer"
}

package "Hangfire Scheduler" {
    component Scheduler as "Recurring Job Service"
}

package "External Providers" {
    component Bloomberg
    component Refinitiv
    component Six
}

USER -right-> Endpoints : **(1)** HTTPS (JWT)
Endpoints -> Authentication
Authentication -> Validation
Validation --> BusinessService : **(2)**
BusinessService --> DbRepo
BusinessService --> SqsMgr : **(3)**
BusinessService -right-> HybridCache : **(Poll Optimization)**

DbRepo --> SQLServer
SqsMgr -down-> SQS : **(4)** Enqueue Job

SQS -down-> JobRunner : **(5)** Trigger
JobRunner -> Dispatcher
JobRunner -down-> SyncStatus
Scheduler -up-> SyncStatus
Dispatcher -down-> Bloomberg : **(6)**
Dispatcher -down-> Refinitiv
Dispatcher -down-> Six

Bloomberg -down-> SyncStatus : **(7)** Update Status
Refinitiv -down-> SyncStatus : Update Status
Six -down-> SyncStatus : Update Status

SyncStatus -> DbRepo : **(8)**
USER <-right- Endpoints : **(9)** Poll Status (Optimized via HybridCache)
@enduml


# STATUS WORKFLOW

@startuml
[*] --> Requested : Initial submission

Requested --> Validated : Product validation success
Requested --> ProviderRejected : Functional error

Validated --> ProviderSent : Product sent to provider

ProviderSent --> ProviderAck : Provider received confirmation

ProviderAck --> ProviderCreated : Product created successfully
ProviderAck --> ProviderRejected : Functional error

ProviderCreated --> [*]
Failed --> [*]
ProviderRejected --> [*]

state Failed #LightCoral {
}

note right of Requested
  Initial submission
end note

note right of Validated
  Product validation success
end note

note right of ProviderSent
  Product sent to provider
end note

note right of ProviderAck
  Provider received confirmation
end note

note right of ProviderCreated
  Product created successfully
end note

note right of Failed
  Technical error occur
end note

note right of ProviderRejected
  Functional error
end note

@enduml
