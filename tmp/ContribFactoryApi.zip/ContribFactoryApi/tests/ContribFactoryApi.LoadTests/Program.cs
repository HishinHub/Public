using System.Text;
using System.Text.Json;
using ContribFactoryApi.LoadTests.Fixtures;
using NBomber.Contracts.Stats;
using NBomber.CSharp;
using Serilog;
using Serilog.Events;

var httpClient = new HttpClient();

var scenario = Scenario.Create("product_creation_scenario", async context =>
{
    var request = ProductCreationFixture.CreateRefinitivRequest();

    var json = JsonSerializer.Serialize(request);
    var content = new StringContent(json, Encoding.UTF8, "application/json");

    try 
    {
        var response = await httpClient.PostAsync("https://localhost:61497/api/v1/products", content);
        
        return response.IsSuccessStatusCode
            ? Response.Ok()
            : Response.Fail();
    }
    catch (Exception ex)
    {
        return Response.Fail(ex);
    }
})
.WithWarmUpDuration(TimeSpan.FromSeconds(10))
.WithLoadSimulations(
    Simulation.Inject(rate: 10, interval: TimeSpan.FromSeconds(1), during: TimeSpan.FromSeconds(30))
);

NBomberRunner
    .RegisterScenarios(scenario)
    .WithReportFormats(ReportFormat.Html)
    .Run();
