using ContribFactoryApi.Infrastructure.Database;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using ContribFactoryApi.Domain.ProductCreation;
using ContribFactoryApi.Application.ProviderDispatcher;
using ContribFactoryApi.Infrastructure.Authentication;
using Microsoft.Extensions.Options;
using System.Net.Http.Json;

namespace ContribFactoryApi.Tests.Fixtures;

/// <summary>
/// Test fixture for integration tests
/// </summary>
public class WebApiTestFixture : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureServices(services =>
        {
            // Remove the real database context
            var descriptor = services.SingleOrDefault(
                d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));

            if (descriptor != null)
            {
                services.Remove(descriptor);
            }

            // Add in-memory database for testing
            services.AddDbContext<AppDbContext>(options =>
            {
                options.UseInMemoryDatabase("TestDatabase");
            });

            // Enable all providers for testing
            services.Configure<ProviderDispatcherOptions>(options =>
            {
                options.EnabledProviders = [ProviderName.Bloomberg, ProviderName.Refinitiv, ProviderName.Six];
            });

            // Configure JWT for testing with known credentials
            services.Configure<AuthenticationOptions>(options =>
            {
                options.Jwt = new JwtOptions
                {
                    SecretKey = "TEST_SECRET_KEY_CHANGE_IN_PRODUCTION_MIN32CH",
                    Issuer = "ContribFactoryApi",
                    Audience = "ContribFactoryApi.Clients",
                    ExpirationMinutes = 60
                };
                options.Identity = new IdentityOptions
                {
                    ClientId = "contribfactory",
                    ClientSecret = "contribfactory"
                };
            });

            // IMPORTANT: Also override the separate JwtOptions configuration 
            // used by the AddOptions<JwtBearerOptions> configuration block.
            services.Configure<JwtOptions>(options =>
            {
                options.SecretKey = "TEST_SECRET_KEY_CHANGE_IN_PRODUCTION_MIN32CH";
                options.Issuer = "ContribFactoryApi";
                options.Audience = "ContribFactoryApi.Clients";
                options.ExpirationMinutes = 60;
            });

            // Build the service provider
            var sp = services.BuildServiceProvider();

            // Create a scope to obtain a reference to the database context
            using var scope = sp.CreateScope();
            var scopedServices = scope.ServiceProvider;
            var db = scopedServices.GetRequiredService<AppDbContext>();

            // Ensure the database is created
            db.Database.EnsureCreated();
        });
    }

    /// <summary>
    /// Creates an HttpClient pre-configured with a valid JWT token.
    /// </summary>
    public async Task<HttpClient> CreateAuthenticatedClientAsync()
    {
        var client = CreateClient();

        // Request a token via the token endpoint
        // NOTE: Using the hardcoded 'contribfactory-client' required by the simplified JwtTokenService
        var tokenResponse = await client.PostAsJsonAsync("/api/auth/token", new
        {
            clientId = "contribfactory",
            clientSecret = "contribfactory"
        });

        tokenResponse.EnsureSuccessStatusCode();
        var token = await tokenResponse.Content.ReadFromJsonAsync<TokenResponse>();

        client.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token!.AccessToken);

        return client;
    }
}
